#!/usr/bin/python
# coding=utf-8
import os , xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , base64 , cookielib , zlib
if 64 - 64: i11iIiiIii
OO0o = xbmcaddon . Addon ( id = 'plugin.video.vtvplus.vn' )
Oo0Ooo = int ( sys . argv [ 1 ] )
O0O0OO0O0O0 = xbmc . translatePath ( OO0o . getAddonInfo ( 'profile' ) ) . decode ( "utf-8" )
iiiii = xbmc . translatePath ( os . path . join ( O0O0OO0O0O0 , "cookie.txt" ) )
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( "[B]Star Movies HD[/B]" , "http://vtvplus.vn/star-movies-hd-live-18.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/18.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]Star World HD[/B]" , "http://vtvplus.vn/star-world-hd-live-44.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/44.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]HBO HD[/B]" , "http://vtvplus.vn/hbo-hd-live-22.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/22.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]NatGeo Wild HD[/B]" , "http://vtvplus.vn/natgeo-wild-hd-live-48.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/48.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]National Geographic HD[/B]" , "http://vtvplus.vn/national-geographic-hd-live-46.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/46.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]HTVC Thuần Việt HD[/B]" , "http://vtvplus.vn/htvc-thuan-viet-hd-live-30.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/30.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]SCTV Hài HD[/B]" , "http://vtvplus.vn/sctv-hai-hd-live-36.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/36.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]SCTV Thể thao HD[/B]" , "http://vtvplus.vn/sctv-the-thao-hd-live-8.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/8.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]VTV3 HD[/B]" , "http://vtvplus.vn/vtv3-hd-live-1.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/1.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]VTVcab 16 - Bóng Đá TV HD[/B]" , "http://vtvplus.vn/vtvcab-16-bong-da-tv-hd-live-11.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/11.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]VTVcab 3 - Thể Thao TV HD[/B]" , "http://vtvplus.vn/vtvcab-3-the-thao-tv-hd-live-12.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/12.jpg&a=t&w=291&h=163" )
 i1I11i ( "[B]HTVC+ HD Yeah1[/B]" , "http://vtvplus.vn/htvc-hd-yeah1-live-41.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/41.jpg&a=t&w=291&h=163" )
 i1I11i ( "Cinemax" , "http://vtvplus.vn/cinemax-live-74.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/74.jpg&a=t&w=291&h=163" )
 i1I11i ( "Fox Sports" , "http://vtvplus.vn/fox-sports-live-16.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/16.jpg&a=t&w=291&h=163" )
 i1I11i ( "Star Sport" , "http://vtvplus.vn/star-sport-live-75.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/75.jpg&a=t&w=291&h=163" )
 i1I11i ( "MTV Phụ đề tiếng Việt" , "http://vtvplus.vn/mtv-phu-de-tieng-viet-live-55.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/55.jpg&a=t&w=291&h=163" )
 i1I11i ( "Yan TV" , "http://vtvplus.vn/yan-tv-live-31.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/31.jpg&a=t&w=291&h=163" )
 i1I11i ( "Yeah1TV" , "http://vtvplus.vn/yeah1tv-live-63.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/63.jpg&a=t&w=291&h=163" )
 i1I11i ( "HTV Thể thao" , "http://vtvplus.vn/htv-the-thao-live-13.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/13.jpg&a=t&w=291&h=163" )
 i1I11i ( "HTV3" , "http://vtvplus.vn/htv3-live-39.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/39.jpg&a=t&w=291&h=163" )
 i1I11i ( "HTV4" , "http://vtvplus.vn/htv4-live-42.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/42.jpg&a=t&w=291&h=163" )
 i1I11i ( "HTV7" , "http://vtvplus.vn/htv7-live-37.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/37.jpg&a=t&w=291&h=163" )
 i1I11i ( "HTV9" , "http://vtvplus.vn/htv9-live-38.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/38.jpg&a=t&w=291&h=163" )
 i1I11i ( "HTVC FBNC" , "http://vtvplus.vn/htvc-fbnc-live-43.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/43.jpg&a=t&w=291&h=163" )
 i1I11i ( "SCTV1" , "http://vtvplus.vn/sctv1-live-35.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/35.jpg&a=t&w=291&h=163" )
 i1I11i ( "SCTV13" , "http://vtvplus.vn/sctv13-live-33.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/33.jpg&a=t&w=291&h=163" )
 i1I11i ( "SCTV15" , "http://vtvplus.vn/sctv15-live-10.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/10.jpg&a=t&w=291&h=163" )
 i1I11i ( "SCTV17" , "http://vtvplus.vn/sctv17-live-28.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/28.jpg&a=t&w=291&h=163" )
 i1I11i ( "SCTV3" , "http://vtvplus.vn/sctv3-live-34.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/34.jpg&a=t&w=291&h=163" )
 i1I11i ( "SCTV6" , "http://vtvplus.vn/sctv6-live-32.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/32.jpg&a=t&w=291&h=163" )
 i1I11i ( "TH Vĩnh Long" , "http://vtvplus.vn/th-vinh-long-live-53.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/53.jpg&a=t&w=291&h=163" )
 i1I11i ( "Thể Thao TV SD" , "http://vtvplus.vn/the-thao-tv-sd-live-15.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/15.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTC9 - Let's Việt" , "http://vtvplus.vn/vtc9-lets-viet-live-29.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/29.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTV1" , "http://vtvplus.vn/vtv1-live-2.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/2.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTV2" , "http://vtvplus.vn/vtv2-live-3.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/3.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTV3 SD" , "http://vtvplus.vn/vtv3-sd-live-87.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/87.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTV4" , "http://vtvplus.vn/vtv4-live-4.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/4.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTV6 SD" , "http://vtvplus.vn/vtv6-sd-live-88.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/88.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTV9" , "http://vtvplus.vn/vtv9-live-6.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/6.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 1 - Giải trí TV" , "http://vtvplus.vn/vtvcab-1-giai-tri-tv-live-56.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/56.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 10 - O2 TV" , "http://vtvplus.vn/vtvcab-10-o2-tv-live-62.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/62.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 15 - Invest TV" , "http://vtvplus.vn/vtvcab-15-invest-tv-live-14.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/14.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 2 - Phim Việt" , "http://vtvplus.vn/vtvcab-2-phim-viet-live-20.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/20.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 5 - Echannel" , "http://vtvplus.vn/vtvcab-5-echannel-live-21.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/21.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 6 - HayTV Kênh phim truyện" , "http://vtvplus.vn/vtvcab-6-haytv-kenh-phim-truyen-live-23.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/23.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 7 - D Dramas" , "http://vtvplus.vn/vtvcab-7-d-dramas-live-19.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/19.jpg&a=t&w=291&h=163" )
 i1I11i ( "VTVcab 8 - Bibi" , "http://vtvplus.vn/vtvcab-8-bibi-live-59.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/59.jpg&a=t&w=291&h=163" )
 i1I11i ( "Xúc xắc lúc lắc" , "http://vtvplus.vn/xuc-xac-luc-lac-live-5.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/uploads/images/xucxacluclac.png&a=t&w=291&h=163" )
 i1I11i ( "ANTV" , "http://vtvplus.vn/antv-live-52.html" , "playvideo" , "http://vtvplus.vn/vtv/thumb.php?src=https://api.vtvplus.vn/pro/files/channel/52.jpg&a=t&w=291&h=163" )
 try :
  OoOoOO00 = xbmc . translatePath ( OO0o . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
  #OoOoOO00 = xbmc . translatePath ( os . path . join ( OoOoOO00 , "temp.jpg" ) )
  #urllib . urlretrieve ( 'http://echipstore.net/images/vtvplus.jpg' , OoOoOO00 )
  #I11i = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , OoOoOO00 )
  #O0O = xbmcgui . WindowDialog ( )
  #O0O . addControl ( I11i )
  #O0O . doModal ( )
 finally :
  pass
  if 78 - 78: i11ii11iIi11i . oOoO0oo0OOOo + IiiI / Iii1ii1II11i
def iI111iI ( url , title ) :
 IiII = urllib2 . urlopen ( 'https://docs.google.com/feeds/download/documents/export/Export?id=1gLFT_b_M22ei_AudXq8i1yHb-kyAThALr_K0uumkz7E&exportFormat=txt' )
 if 28 - 28: Ii11111i * iiI1i1
 i1I1ii1II1iII = IiII . read ( )
 IiII . close ( )
 oooO0oo0oOOOO = { 'host' : 'vtvplus.vn' , 'Accept-Encoding' : 'gzip, deflate' , 'Connection' : 'keep-alive' , 'Cookie' : O0oO ( "abc" , i1I1ii1II1iII ) }
 o0oO0 = urllib2 . Request ( url , headers = oooO0oo0oOOOO )
 IiII = urllib2 . urlopen ( o0oO0 )
 oo00 = IiII . read ( )
 IiII . close ( )
 if "gzip" in IiII . info ( ) . getheader ( 'Content-Encoding' ) :
  oo00 = zlib . decompress ( oo00 , 16 + zlib . MAX_WBITS )
 o00 = re . compile ( "reLoad\('(.+?)'\);" ) . findall ( oo00 )
 if o00 :
  Oo0oO0ooo = xbmcgui . ListItem ( title )
  Oo0oO0ooo . setInfo ( 'video' , { 'Title' : title } )
  Oo0oO0ooo . setProperty ( "IsPlayable" , "true" )
  Oo0oO0ooo . setPath ( o00 [ 0 ] . split ( "," ) [ 0 ] )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , Oo0oO0ooo )
  if 56 - 56: ooO00oOoo - O0OOo
  if 8 - 8: Oooo0000 * i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
  if 71 - 71: O00OoOoo00
  if 31 - 31: iI1OoOooOOOO + Ii11111i
  if 22 - 22: oo * iIIi1iI1II111 / ooO00oOoo
  if 64 - 64: oo % i11ii11iIi11i % oOooOoO0Oo0O
  if 3 - 3: OOO0O + iIIi1iI1II111
  if 42 - 42: i1IIi11111i / i11ii11iIi11i + i11iIiiIii - oo
  if 78 - 78: Ii11111i
  if 18 - 18: iIIi1iI1II111 - OOO0O / OOO0O + iI1OoOooOOOO % iI1OoOooOOOO - oo0ooO0oOOOOo
  if 62 - 62: OOO0O - oo0ooO0oOOOOo - iiI1i1 % i11ii11iIi11i / Oooo0000
  if 77 - 77: oOoO0oo0OOOo - oOoO0oo0OOOo . IiiI / ooO00oOoo
  if 14 - 14: I11i1i11i1I % iIIi1iI1II111
  if 41 - 41: i11ii11iIi11i + O00OoOoo00 + i1IIi11111i - oo0ooO0oOOOOo
  if 77 - 77: Iii1ii1II11i . oo0ooO0oOOOOo % iI1OoOooOOOO
  if 42 - 42: Oooo0000 - i11ii11iIi11i / i11iIiiIii + i1IIi11111i + Ii11111i
  if 17 - 17: Oooo0000 . Iii1ii1II11i . O0OOo
  if 3 - 3: iiI1i1 . Iii1ii1II11i . IiiI / oo
  if 38 - 38: oOoO0oo0OOOo % i11iIiiIii . iI1OoOooOOOO - i1IIi11111i + oo
  if 66 - 66: oOooOoO0Oo0O * oOooOoO0Oo0O . i1IIi11111i . i11ii11iIi11i - i1IIi11111i
  if 77 - 77: I11i1i11i1I - ii11i
  if 82 - 82: i11iIiiIii . i1IIi11111i / Iii1ii1II11i * iIIi1iI1II111 % Oooo0000 % ii11i
  if 78 - 78: ii11i - oo * Ii11111i + ooO00oOoo + OOO0O + OOO0O
  if 11 - 11: OOO0O - Ii11111i % iI1OoOooOOOO % OOO0O / iiI1i1 - Ii11111i
def o0o0oOOOo0oo ( ) :
 o0oo0o0O00OO = xbmcgui . Dialog ( )
 if o0oo0o0O00OO . yesno ( "VTV Plus" , "Bạn cần tài khoản VTV Plus VIP để xem các kênh truyền hình của VTV Plus. Nếu chưa có tài khoản" , "Vui lòng đăng ký và nạp tiền tại" , "www.vtvplus.vn" , "Thoát" , "Đăng nhập" ) :
  i1I1ii1II1iII = ""
  o0oO = ""
  if ( os . path . exists ( iiiii ) ) :
   with open ( iiiii , "r" ) as I1i1iii :
    i1I1ii1II1iII = I1i1iii . read ( )
   o0oO = i1I1ii1II1iII . split ( "vtv_user=" ) [ 1 ] . split ( "; " ) [ 0 ]
  i1iiI11I = xbmc . Keyboard ( o0oO . split ( "-" ) [ 0 ] . replace ( "_aaa_" , "@" ) , 'VTV Plus - Nhập Username' )
  i1iiI11I . doModal ( )
  if i1iiI11I . isConfirmed ( ) :
   iiii = i1iiI11I . getText ( )
  i1iiI11I = xbmc . Keyboard ( urllib . unquote ( o0oO . split ( "-" ) [ 1 ] ) , 'VTV Plus - Nhập Mật khẩu' )
  i1iiI11I . doModal ( )
  if i1iiI11I . isConfirmed ( ) :
   oO0o0O0OOOoo0 = i1iiI11I . getText ( )
  if not IiIiiI ( iiii , oO0o0O0OOOoo0 ) :
   o0o0oOOOo0oo ( )
   if 31 - 31: oo . oo - ooO00oOoo / Ii11111i + iI1OoOooOOOO * IiiI
def IiIiiI ( username , password ) :
 O0ooOooooO = 'http://www.vtvplus.vn/index.php?option=com_vtv&task=user.login'
 o00O = { 'username' : username , 'password' : password , 'save' : "1" }
 oooO0oo0oOOOO = { 'host' : 'www.vtvplus.vn' , 'Accept-Encoding' : 'gzip, deflate' , 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8' , 'Connection' : 'keep-alive' }
 OOO0OOO00oo = urllib . urlencode ( o00O )
 o0oO0 = urllib2 . Request ( O0ooOooooO , headers = oooO0oo0oOOOO , data = OOO0OOO00oo )
 IiII = urllib2 . urlopen ( o0oO0 )
 oo00 = IiII . read ( )
 if "thành công" in oo00 :
  o0oo0o0O00OO = xbmcgui . Dialog ( )
  o0oo0o0O00OO . ok ( "VTV Plus" , "Đăng nhập thành công" , "Vui lòng chọn kênh yêu thích để xem" )
  Iii111II = os . path . dirname ( iiiii )
  if not os . path . exists ( Iii111II ) :
   os . makedirs ( Iii111II )
  with open ( iiiii , "w" ) as I1i1iii :
   I1i1iii . write ( IiII . headers . get ( "Set-Cookie" ) )
  IiII . close ( )
  return True
 else :
  IiII . close ( )
  return False
  if 9 - 9: Ii11111i
def i11 ( url ) :
 o0oO0 = urllib2 . Request ( url )
 O0oo0OO0oOOOo = urllib2 . urlopen ( o0oO0 )
 i1i1i11IIi = O0oo0OO0oOOOo . read ( )
 O0oo0OO0oOOOo . close ( )
 i1i1i11IIi = '' . join ( i1i1i11IIi . splitlines ( ) ) . replace ( '\'' , '"' )
 i1i1i11IIi = i1i1i11IIi . replace ( '\n' , '' )
 i1i1i11IIi = i1i1i11IIi . replace ( '\t' , '' )
 i1i1i11IIi = re . sub ( '  +' , ' ' , i1i1i11IIi )
 i1i1i11IIi = i1i1i11IIi . replace ( '> <' , '><' )
 return i1i1i11IIi
 if 33 - 33: ooO00oOoo + i1IIi11111i * Ii11111i - Iii1ii1II11i / Oooo0000 % oo
def i1I11i ( name , url , mode , iconimage ) :
 II1i1IiiIIi11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 iI1Ii11iII1 = True
 Oo0O0O0ooO0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 Oo0O0O0ooO0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Oo0O0O0ooO0O . setProperty ( "IsPlayable" , "true" )
 iI1Ii11iII1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i1IiiIIi11 , listitem = Oo0O0O0ooO0O )
 return iI1Ii11iII1
 if 15 - 15: O0OOo + iiI1i1 - oOooOoO0Oo0O / i1IIi11111i
def O0oO ( k , e ) :
 oo000OO00Oo = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for O0OOO0OOoO0O in range ( len ( e ) ) :
  O00Oo000ooO0 = k [ O0OOO0OOoO0O % len ( k ) ]
  OoO0O00 = chr ( ( 256 + ord ( e [ O0OOO0OOoO0O ] ) - ord ( O00Oo000ooO0 ) ) % 256 )
  oo000OO00Oo . append ( OoO0O00 )
 return "" . join ( oo000OO00Oo )
 if 5 - 5: Iii1ii1II11i / ooO00oOoo . oo - iIIi1iI1II111 / oo0ooO0oOOOOo
def ooOooo000oOO ( parameters ) :
 Oo0oOOo = { }
 if 58 - 58: oOoO0oo0OOOo * i1IIi11111i * O0OOo / i1IIi11111i
 if parameters :
  oO0o0OOOO = parameters [ 1 : ] . split ( "&" )
  for O0O0OoOO0 in oO0o0OOOO :
   iiiI1I11i1 = O0O0OoOO0 . split ( '=' )
   if ( len ( iiiI1I11i1 ) ) == 2 :
    Oo0oOOo [ iiiI1I11i1 [ 0 ] ] = iiiI1I11i1 [ 1 ]
 return Oo0oOOo
 if 49 - 49: IiiI % iI1OoOooOOOO . iI1OoOooOOOO . I11i1i11i1I * iI1OoOooOOOO
O0oOO0 = xbmc . translatePath ( OO0o . getAddonInfo ( 'profile' ) )
if 68 - 68: O00OoOoo00 % i11ii11iIi11i . oo0ooO0oOOOOo . O0OOo
if os . path . exists ( O0oOO0 ) == False :
 os . mkdir ( O0oOO0 )
o0 = os . path . join ( O0oOO0 , 'visitor' )
if 91 - 91: ii11i + O00OoOoo00
if os . path . exists ( o0 ) == False :
 from random import randint
 i1i = open ( o0 , "w" )
 i1i . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 i1i . close ( )
 if 46 - 46: O00OoOoo00 % I11i1i11i1I + Ii11111i . iiI1i1 . Ii11111i
oO00o0 = xbmc . translatePath ( "special://userdata" )
oO00o0 = xbmc . translatePath ( os . path . join ( oO00o0 , "uaip" ) )
if not os . path . exists ( oO00o0 ) :
 OOoo0O = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 Oo0ooOo0o = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in OOoo0O for b in Oo0ooOo0o ) :
  Ii1i1 = i11 ( O0oO ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  O0OOO0OOoO0O = Ii1i1 . replace ( '"' , '' ) . split ( ',' )
  II1i1IiiIIi11 = OOoo0O . split ( ";" )
  with open ( oO00o0 , "w" ) as I1i1iii :
   I1i1iii . write ( OOoo0O + ";" + O0OOO0OOoO0O [ 0 ] )
  o00O = { 'entry.436422879' : II1i1IiiIIi11 [ 0 ] , 'entry.1845442180' : II1i1IiiIIi11 [ 1 ] , 'entry.972740559' : II1i1IiiIIi11 [ 2 ] , 'entry.1836504487' : II1i1IiiIIi11 [ 3 ] , 'entry.1101915442' : O0OOO0OOoO0O [ 0 ] , 'entry.1574658585' : O0OOO0OOoO0O [ 1 ] , 'entry.1805295152' : O0OOO0OOoO0O [ 2 ] , 'entry.512145242' : O0OOO0OOoO0O [ 3 ] , 'entry.773640853' : O0OOO0OOoO0O [ 4 ] , 'entry.319359888' : O0OOO0OOoO0O [ 5 ] , 'entry.122876449' : O0OOO0OOoO0O [ 6 ] , 'entry.1791949570' : O0OOO0OOoO0O [ 7 ] , 'entry.1970011699' : O0OOO0OOoO0O [ 8 ] , 'entry.422390183' : O0OOO0OOoO0O [ 9 ] , 'entry.2030601071' : O0OOO0OOoO0O [ 10 ] }
  OOO0OOO00oo = urllib . urlencode ( o00O )
  i1I1ii1II1iII = O0oO ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  o0oO0 = urllib2 . Request ( i1I1ii1II1iII , OOO0OOO00oo )
  o0oO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  o0oO0 . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  o0oO0 . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  O0oo0OO0oOOOo = urllib2 . urlopen ( o0oO0 )
  if 15 - 15: oOoO0oo0OOOo
def Ii ( utm_url ) :
 ooo0O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  o0oO0 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : ooo0O }
 )
  O0oo0OO0oOOOo = urllib2 . urlopen ( o0oO0 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return O0oo0OO0oOOOo
 if 75 - 75: ooO00oOoo % ooO00oOoo . O00OoOoo00
def III1iII1I1ii ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  oOOo0 = "1.0"
  oo00O00oO = open ( o0 ) . read ( )
  iIiIIIi = "VTVPlus"
  ooo00OOOooO = "UA-52209804-2"
  O00OOOoOoo0O = "www.viettv24.com"
  O000OOo00oo = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   oo0OOo = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iIiIIIi ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oo00O00oO , "1" , "1" , "2" ] )
   if 64 - 64: I11i1i11i1I
   if 22 - 22: Iii1ii1II11i + oo % O0OOo
   if 9 - 9: oOooOoO0Oo0O
   if 62 - 62: i1IIi11111i / Ii11111i + oo / Ii11111i . oOoO0oo0OOOo
   if 68 - 68: i11iIiiIii % O0OOo + i11iIiiIii
  else :
   if group == "None" :
    oo0OOo = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iIiIIIi + "/" + name ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oo00O00oO , "1" , "1" , "2" ] )
    if 31 - 31: oOoO0oo0OOOo . IiiI
    if 1 - 1: Iii1ii1II11i / ooO00oOoo % OOO0O * oo0ooO0oOOOOo . i11iIiiIii
    if 2 - 2: O0OOo * I11i1i11i1I - ii11i + IiiI . Oooo0000 % OOO0O
    if 92 - 92: OOO0O
    if 25 - 25: Iii1ii1II11i - IiiI / oOooOoO0Oo0O / ooO00oOoo
   else :
    oo0OOo = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iIiIIIi + "/" + group + "/" + name ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oo00O00oO , "1" , "1" , "2" ] )
    if 12 - 12: IiiI * OOO0O % i11ii11iIi11i % ii11i
    if 20 - 20: i1IIi11111i % oo / oo + oo
    if 45 - 45: Oooo0000 - oo0ooO0oOOOOo - oOooOoO0Oo0O - Ii11111i . oOoO0oo0OOOo / iIIi1iI1II111
    if 51 - 51: iIIi1iI1II111 + OOO0O
    if 8 - 8: Oooo0000 * iiI1i1 - oo - Ii11111i * i1IIi11111i % IiiI
    if 48 - 48: iIIi1iI1II111
  print "============================ POSTING ANALYTICS ============================"
  Ii ( oo0OOo )
  if 11 - 11: I11i1i11i1I + oOooOoO0Oo0O - Ii11111i / ooO00oOoo + Iii1ii1II11i . oOoO0oo0OOOo
  if not group == "None" :
   i1Iii1i1I = O000OOo00oo + "?" + "utmwv=" + oOOo0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( O00OOOoOoo0O ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + iIiIIIi + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( iIiIIIi ) + "&utmac=" + ooo00OOOooO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , oo00O00oO , "1" , "2" ] )
   if 91 - 91: O0OOo + IiiI . i1IIi11111i * O0OOo + IiiI * Iii1ii1II11i
   if 80 - 80: OOO0O % i1IIi11111i % Oooo0000 - Iii1ii1II11i + Iii1ii1II11i
   if 19 - 19: iiI1i1 * i11ii11iIi11i
   if 14 - 14: OOO0O
   if 11 - 11: oo0ooO0oOOOOo * IiiI . ii11i % oOooOoO0Oo0O + OOO0O
   if 78 - 78: Ii11111i . i1IIi11111i + Ii11111i / I11i1i11i1I / Ii11111i
   if 54 - 54: iiI1i1 % OOO0O
   if 37 - 37: iiI1i1 * Iii1ii1II11i / iI1OoOooOOOO - OOO0O % oOoO0oo0OOOo . Oooo0000
   try :
    print "============================ POSTING TRACK EVENT ============================"
    Ii ( i1Iii1i1I )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 88 - 88: OOO0O . oOoO0oo0OOOo * oOoO0oo0OOOo % O00OoOoo00
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 15 - 15: i11ii11iIi11i * IiiI + i11iIiiIii
I1Ii = ooOooo000oOO ( sys . argv [ 2 ] )
O0oo00o0O = I1Ii . get ( 'mode' )
i1I1I = I1Ii . get ( 'url' )
iiI1I = I1Ii . get ( 'name' )
IiIiiIIiI = I1Ii . get ( 'requestdata' )
if type ( i1I1I ) == type ( str ( ) ) :
 i1I1I = urllib . unquote_plus ( i1I1I )
if type ( IiIiiIIiI ) == type ( str ( ) ) :
 IiIiiIIiI = urllib . unquote_plus ( IiIiiIIiI )
 if 67 - 67: iI1OoOooOOOO
I1IIII1i = str ( sys . argv [ 1 ] )
if O0oo00o0O == 'playvideo' :
 III1iII1I1ii ( "Play" , iiI1I + "/" + i1I1I )
 I1I11i = xbmcgui . DialogProgress ( )
 I1I11i . create ( 'VTV Plus' , 'Loading stream. Please wait...' )
 Ii1I1I1i1Ii = urllib . unquote_plus ( iiI1I )
 iI111iI ( i1I1I , Ii1I1I1i1Ii )
 I1I11i . close ( )
 del I1I11i
 if 5 - 5: O00OoOoo00 . ooO00oOoo
else :
 III1iII1I1ii ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( I1IIII1i ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
