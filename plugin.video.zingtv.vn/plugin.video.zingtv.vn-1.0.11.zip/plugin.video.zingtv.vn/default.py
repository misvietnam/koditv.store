#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.zingtv.vn'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = ""
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Tìm kiếm' , '' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 i1I11i ( 'Thiếu nhi' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9ZIW8&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'TV Show' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0CE&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Phim Truyền Hình' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0DW&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Hài kịch' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0D6&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Âm nhạc' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0DC&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Video Games' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9ZIU8&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Hoạt hình' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0DO&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Giáo dục' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0D7&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Thể thao' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0DI&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 i1I11i ( 'Tin tức - Sự kiện' , 'http://m.tv.zing.vn/ajax?f=genreProgram&s=new&id=IWZ9Z0CF&page=1&count=50' , 'indexprogram' , 'http://static.mp3.zdn.vn/skins/tv/images/zingtv-logo.png' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 IiI1ii1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #IiI1ii1 = xbmc . translatePath ( os . path . join ( IiI1ii1 , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/zingtv.jpg' , IiI1ii1 )
 #oooOOooo = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiI1ii1 )
 #o0oo0oo0OO00 = xbmcgui . WindowDialog ( )
 #o0oo0oo0OO00 . addControl ( oooOOooo )
 #o0oo0oo0OO00 . doModal ( )
 if 20 - 20: i111iII
 oOOo = xbmc . getSkinDir ( )
 if oOOo == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 25 - 25: O0 + OoOoOoO0o0OO * Ooo0OO0oOO * Ii * o0o - OOO0o0o
def Ii1iI ( url ) :
 Oo = I1Ii11I1Ii1i ( url )
 Ooo = re . compile ( '<a class="content-items" href="(.+?)"><span class="video-img"><img alt="(.+?)" src="(.+?)" [^>]*>(.+?)<h4>(.+?)</h4>' ) . findall ( Oo )
 for o0oOoO00o , i1 , oOOoo00O0O , i1111 , i11 in reversed ( Ooo ) :
  I11 ( "[" + i11 + "] - " + i1 , "http://tv.zing.vn" + o0oOoO00o , 'loadvideo' , oOOoo00O0O )
 if ( len ( Ooo ) == 50 ) :
  Oo0o0000o0o0 = int ( re . compile ( '&page=(.+?)&' ) . findall ( url ) [ 0 ] )
  url = url . replace ( "&page=" + str ( Oo0o0000o0o0 ) , "&page=" + str ( Oo0o0000o0o0 + 1 ) )
  i1I11i ( "Next >>" , url , 'indexvideo' , "" )
 oOOo = xbmc . getSkinDir ( )
 if oOOo == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 86 - 86: iiiii11iII1 % O0o
def oO0 ( url ) :
 Oo = I1Ii11I1Ii1i ( url )
 Ooo = re . compile ( '<a class="content-items" href="(.+?)"><img class="program-img" alt="(.+?)" src="(.+?)" [^>]*>' ) . findall ( Oo )
 for o0oOoO00o , i1 , oOOoo00O0O in Ooo :
  i1I11i ( "[B]" + i1 + "[/B]" , "http://m.tv.zing.vn" + o0oOoO00o , 'indexseries' , oOOoo00O0O )
 if ( len ( Ooo ) == 50 ) :
  Oo0o0000o0o0 = int ( re . compile ( '&page=(.+?)&' ) . findall ( url ) [ 0 ] )
  url = url . replace ( "&page=" + str ( Oo0o0000o0o0 ) , "&page=" + str ( Oo0o0000o0o0 + 1 ) )
  i1I11i ( "Next >>" , url , 'indexprogram' , "" )
 oOOo = xbmc . getSkinDir ( )
 if oOOo == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 32 - 32: I1i1I - OoOoo0 % Oooo000o % Oooo000o
def iiI11 ( url ) :
 Oo = I1Ii11I1Ii1i ( url )
 OOooO = re . compile ( '<h3>(.+?)</h3>' ) . findall ( Oo ) [ 0 ]
 OOoO00o = re . compile ( '<input type="hidden" id="_objectId" objectType="tv_program" value="(.+?)">' ) . findall ( Oo ) [ 0 ]
 II111iiii = "http://m.tv.zing.vn/ajax?f=loadSuggest&type=tv_program&id=&page=1&count=100"
 II = I1Ii11I1Ii1i ( II111iiii . replace ( "id=" , "id=" + OOoO00o ) )
 Ooo = re . compile ( '<a href="(.+?)" [^>]*><img [^>]* src="(.+?)" alt="(.+?)">(.+?)<span>(.+?)</span></a>' ) . findall ( II )
 if 63 - 63: i111iII % III
 for o0oOoO00o , oOOoo00O0O , i1 , o0oOo0Ooo0O , OO00O0O0O00Oo in Ooo :
  OOoO00o = o0oOoO00o . split ( "/" ) [ - 1 ] . split ( "." ) [ 0 ]
  o0oOoO00o = "http://m.tv.zing.vn/ajax?f=loadMediaSeries&id=&page=1&count=50"
  i1I11i ( "[B]" + i1 + "[/B] (" + OO00O0O0O00Oo + ")" , o0oOoO00o . replace ( "id=" , "id=" + OOoO00o ) , 'indexvideo' , oOOoo00O0O )
 oOOo = xbmc . getSkinDir ( )
 if oOOo == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 25 - 25: O0 % oo00oOOo - oo00oOOo . oo00oOOo
def Ii1 ( ) :
 try :
  oOOoO0 = xbmc . Keyboard ( '' , 'Enter search text' )
  oOOoO0 . doModal ( )
  if ( oOOoO0 . isConfirmed ( ) ) :
   O0OoO000O0OO = urllib . quote_plus ( oOOoO0 . getText ( ) )
  iiI1IiI = 'http://m.tv.zing.vn/ajax?f=searchProgram&s=date&page=1&count=50&q=' + O0OoO000O0OO + '/'
  oO0 ( iiI1IiI )
 except : pass
 if 13 - 13: OOo . i11iIiiIii - ii11i - i111iII
def ii1I ( url , name ) :
 name = urllib . unquote_plus ( name ) . decode ( "utf-8" )
 OooO0 = re . compile ( '/(\w+).html' ) . findall ( url ) [ 0 ]
 OooO0 = OooO0 . replace ( "I" , "1" ) . replace ( "W" , "2" ) . replace ( "O" , "3" ) . replace ( "U" , "4" ) . replace ( "Z" , "5" )
 Oo = I1Ii11I1Ii1i ( "http://api.tv.zing.vn/2.0/media/info?media_id=%s&api_key=9955b1816f11fd848db46c60adcdf866&proxy" % ( int ( OooO0 , 16 ) - 307843200 ) )
 II11iiii1Ii = re . compile ( '"Video720": "(.+?)"' ) . findall ( Oo )
 OO0oOoo = ""
 if len ( II11iiii1Ii ) == 0 :
  II11iiii1Ii = re . compile ( '"Video480": "(.+?)"' ) . findall ( Oo )
  if len ( II11iiii1Ii ) == 0 :
   II11iiii1Ii = re . compile ( '"file_url": "(.+?)"' ) . findall ( Oo )
  OO0oOoo = "http://" + II11iiii1Ii [ 0 ] . split ( "?" ) [ 0 ]
 else :
  OO0oOoo = "http://" + II11iiii1Ii [ 0 ] . split ( "?" ) [ 0 ]
  if 68 - 68: o0o + Ii . ii11i - O0o % ii11i - OoOoo0
 oOOO00o = xbmcgui . ListItem ( name )
 oOOO00o . setInfo ( 'video' , { 'Title' : name } )
 oOOO00o . setProperty ( "IsPlayable" , "true" )
 oOOO00o . setPath ( OO0oOoo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOO00o )
 if 97 - 97: o0o % o0o + oo00oOOo * iiiii11iII1
def I1Ii11I1Ii1i ( url ) :
 o0o00o0 = urllib2 . Request ( url . replace ( "&proxy" , "" ) )
 if "&proxy" in url :
  iIi1ii1I1 = urllib2 . urlopen ( 'https://docs.google.com/spreadsheets/d/1X0197S9P7vn7UsUReZUBc8oK6IgjM99FYdX4lcwp68o/export?format=tsv' )
  o0 = iIi1ii1I1 . read ( ) . decode ( 'utf-8-sig' )
  iIi1ii1I1 . close ( )
  o0o00o0 . set_proxy ( o0 . split ( "\n" ) [ 0 ] , "http" )
 o0o00o0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 o0o00o0 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 I11II1i = urllib2 . urlopen ( o0o00o0 )
 Oo = I11II1i . read ( )
 I11II1i . close ( )
 Oo = '' . join ( Oo . splitlines ( ) ) . replace ( '\'' , '"' )
 Oo = Oo . replace ( '\n' , '' )
 Oo = Oo . replace ( '\t' , '' )
 Oo = re . sub ( '  +' , ' ' , Oo )
 Oo = Oo . replace ( '> <' , '><' )
 return Oo
 if 23 - 23: OoOoOoO0o0OO / O0 + o0o + o0o / oo00oOOo
def iiI1 ( k , e ) :
 i11Iiii = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for iI in range ( len ( e ) ) :
  I1i1I1II = k [ iI % len ( k ) ]
  i1IiIiiI = chr ( ( 256 + ord ( e [ iI ] ) - ord ( I1i1I1II ) ) % 256 )
  i11Iiii . append ( i1IiIiiI )
 return "" . join ( i11Iiii )
 if 31 - 31: OOO0o0o . OOO0o0o - O0 / OOO + OoOoo0 * Oooo000o
def I11 ( name , url , mode , iconimage ) :
 O0ooOooooO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 o00O = True
 OOO0OOO00oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OOO0OOO00oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOO0OOO00oo . setProperty ( "IsPlayable" , "true" )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOooooO , listitem = OOO0OOO00oo )
 return o00O
 if 31 - 31: oo00oOOo - Ii . I1i1I % i111iII - iIIi1iI1II111
def i1I11i ( name , url , mode , iconimage ) :
 O0ooOooooO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 o00O = True
 OOO0OOO00oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOO0OOO00oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOooooO , listitem = OOO0OOO00oo , isFolder = True )
 return o00O
 if 4 - 4: oo00oOOo / OoOoo0 . iiiii11iII1
def O0oo0OO0oOOOo ( parameters ) :
 i1i1i11IIi = { }
 if 33 - 33: O0 + Ii * OOO - OOo / Ooo0OO0oOO % OOO0o0o
 if parameters :
  II1i1IiiIIi11 = parameters [ 1 : ] . split ( "&" )
  for iI1Ii11iII1 in II1i1IiiIIi11 :
   Oo0O0O0ooO0O = iI1Ii11iII1 . split ( '=' )
   if ( len ( Oo0O0O0ooO0O ) ) == 2 :
    i1i1i11IIi [ Oo0O0O0ooO0O [ 0 ] ] = Oo0O0O0ooO0O [ 1 ]
 return i1i1i11IIi
 if 15 - 15: OoOoOoO0o0OO + i111iII - oOooOoO0Oo0O / Ii
oo000OO00Oo = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 51 - 51: O0o * O0 + o0o + OOO
if os . path . exists ( oo000OO00Oo ) == False :
 os . mkdir ( oo000OO00Oo )
o0O0O00 = os . path . join ( oo000OO00Oo , 'visitor' )
if 86 - 86: o0o / O0o % i11iIiiIii
if os . path . exists ( o0O0O00 ) == False :
 from random import randint
 I11IiI1I11i1i = open ( o0O0O00 , "w" )
 I11IiI1I11i1i . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 I11IiI1I11i1i . close ( )
 if 38 - 38: O0
Oo0O = xbmc . translatePath ( "special://userdata" )
Oo0O = xbmc . translatePath ( os . path . join ( Oo0O , "uaip" ) )
if not os . path . exists ( Oo0O ) :
 IIi = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 i11iIIIIIi1 = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in IIi for b in i11iIIIIIi1 ) :
  iiII1i1 = I1Ii11I1Ii1i ( iiI1 ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  iI = iiII1i1 . replace ( '"' , '' ) . split ( ',' )
  O0ooOooooO = IIi . split ( ";" )
  with open ( Oo0O , "w" ) as o00oOO0o :
   o00oOO0o . write ( IIi + ";" + iI [ 0 ] )
  OOO00O = { 'entry.436422879' : O0ooOooooO [ 0 ] , 'entry.1845442180' : O0ooOooooO [ 1 ] , 'entry.972740559' : O0ooOooooO [ 2 ] , 'entry.1836504487' : O0ooOooooO [ 3 ] , 'entry.1101915442' : iI [ 0 ] , 'entry.1574658585' : iI [ 1 ] , 'entry.1805295152' : iI [ 2 ] , 'entry.512145242' : iI [ 3 ] , 'entry.773640853' : iI [ 4 ] , 'entry.319359888' : iI [ 5 ] , 'entry.122876449' : iI [ 6 ] , 'entry.1791949570' : iI [ 7 ] , 'entry.1970011699' : iI [ 8 ] , 'entry.422390183' : iI [ 9 ] , 'entry.2030601071' : iI [ 10 ] }
  OOoOO0oo0ooO = urllib . urlencode ( OOO00O )
  o0 = iiI1 ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  o0o00o0 = urllib2 . Request ( o0 , OOoOO0oo0ooO )
  o0o00o0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  o0o00o0 . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  o0o00o0 . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  I11II1i = urllib2 . urlopen ( o0o00o0 )
  if 98 - 98: iiiii11iII1 * iiiii11iII1 / iiiii11iII1 + o0o
def ii111111I1iII ( utm_url ) :
 O00ooo0O0 = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  o0o00o0 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : O00ooo0O0 }
 )
  I11II1i = urllib2 . urlopen ( o0o00o0 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return I11II1i
 if 23 - 23: iiiii11iII1
def oo0oOo ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  o000O0o = "1.0"
  iI1iII1 = open ( o0O0O00 ) . read ( )
  oO0OOoo0OO = "ZingTV"
  O0ii1ii1ii = "UA-52209804-2"
  oooooOoo0ooo = "www.viettv24.com"
  I1I1IiI1 = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   III1iII1I1ii = I1I1IiI1 + "?" + "utmwv=" + o000O0o + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oO0OOoo0OO ) + "&utmac=" + O0ii1ii1ii + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iI1iII1 , "1" , "1" , "2" ] )
   if 61 - 61: oo00oOOo
   if 64 - 64: OoOoo0 / i111iII - iIIi1iI1II111 - o0o
   if 86 - 86: o0o % i111iII / Oooo000o / i111iII
   if 42 - 42: OOO
   if 67 - 67: I1i1I . iiiii11iII1 . iIIi1iI1II111
  else :
   if group == "None" :
    III1iII1I1ii = I1I1IiI1 + "?" + "utmwv=" + o000O0o + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oO0OOoo0OO + "/" + name ) + "&utmac=" + O0ii1ii1ii + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iI1iII1 , "1" , "1" , "2" ] )
    if 10 - 10: OoOoOoO0o0OO % OoOoOoO0o0OO - ii11i / Ii + OOO0o0o
    if 87 - 87: Ooo0OO0oOO * OoOoOoO0o0OO + Ii / ii11i / iiiii11iII1
    if 37 - 37: iiiii11iII1 - OoOoo0 * Ooo0OO0oOO % i11iIiiIii - I1i1I
    if 83 - 83: o0o / Oooo000o
    if 34 - 34: O0o
   else :
    III1iII1I1ii = I1I1IiI1 + "?" + "utmwv=" + o000O0o + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oO0OOoo0OO + "/" + group + "/" + name ) + "&utmac=" + O0ii1ii1ii + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iI1iII1 , "1" , "1" , "2" ] )
    if 57 - 57: Ooo0OO0oOO . o0o . III
    if 42 - 42: o0o + OoOoOoO0o0OO % iIIi1iI1II111
    if 6 - 6: Ooo0OO0oOO
    if 68 - 68: i111iII - OOO
    if 28 - 28: OOO . Ii / Ii + OOo . OoOoOoO0o0OO
    if 1 - 1: ii11i / oo00oOOo
  print "============================ POSTING ANALYTICS ============================"
  ii111111I1iII ( III1iII1I1ii )
  if 33 - 33: o0o
  if not group == "None" :
   iI11i1ii11 = I1I1IiI1 + "?" + "utmwv=" + o000O0o + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( oooooOoo0ooo ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + oO0OOoo0OO + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( oO0OOoo0OO ) + "&utmac=" + O0ii1ii1ii + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , iI1iII1 , "1" , "2" ] )
   if 58 - 58: OOO % i11iIiiIii . iiiii11iII1 / Ooo0OO0oOO
   if 84 - 84: iiiii11iII1 . OoOoOoO0o0OO / OOo - Oooo000o / oOooOoO0Oo0O / O0
   if 12 - 12: Oooo000o * iiiii11iII1 % III % ii11i
   if 20 - 20: Ii % OOO0o0o / OOO0o0o + OOO0o0o
   if 45 - 45: Ooo0OO0oOO - O0o - oOooOoO0Oo0O - OOO . oo00oOOo / iIIi1iI1II111
   if 51 - 51: iIIi1iI1II111 + iiiii11iII1
   if 8 - 8: Ooo0OO0oOO * i111iII - OOO0o0o - OOO * Ii % Oooo000o
   if 48 - 48: iIIi1iI1II111
   try :
    print "============================ POSTING TRACK EVENT ============================"
    ii111111I1iII ( iI11i1ii11 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 11 - 11: o0o + oOooOoO0Oo0O - OOO / O0 + OOo . oo00oOOo
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 41 - 41: OOO0o0o - iIIi1iI1II111 - iIIi1iI1II111
oO00OOoO00 = O0oo0OO0oOOOo ( sys . argv [ 2 ] )
IiI111111IIII = oO00OOoO00 . get ( 'mode' )
iiI1IiI = oO00OOoO00 . get ( 'url' )
i1Ii = oO00OOoO00 . get ( 'name' )
if type ( iiI1IiI ) == type ( str ( ) ) :
 iiI1IiI = urllib . unquote_plus ( iiI1IiI )
if type ( i1Ii ) == type ( str ( ) ) :
 i1Ii = urllib . unquote_plus ( i1Ii )
 if 14 - 14: iiiii11iII1
I1iI1iIi111i = str ( sys . argv [ 1 ] )
if IiI111111IIII == 'indexvideo' :
 oo0oOo ( "Browse" , i1Ii )
 Ii1iI ( iiI1IiI )
elif IiI111111IIII == 'indexprogram' :
 oo0oOo ( "Browse" , i1Ii )
 oO0 ( iiI1IiI )
elif IiI111111IIII == 'indexseries' :
 oo0oOo ( "Browse" , i1Ii )
 iiI11 ( iiI1IiI )
elif IiI111111IIII == 'search' :
 oo0oOo ( "None" , "Search" )
 Ii1 ( )
elif IiI111111IIII == 'loadvideo' :
 oo0oOo ( "Play" , i1Ii + "/" + iiI1IiI )
 iiIi1IIi1I = xbmcgui . DialogProgress ( )
 iiIi1IIi1I . create ( 'Zing TV' , 'Loading video. Please wait...' )
 ii1I ( iiI1IiI , i1Ii )
 iiIi1IIi1I . close ( )
 del iiIi1IIi1I
else :
 oo0oOo ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( I1iI1iIi111i ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
