import os, re, sys, gzip, urllib, urllib2, string, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
from StringIO import StringIO

try:
	import json
except:
	import simplejson as json

addon = xbmcaddon.Addon('plugin.video.sctv')
profile = xbmc.translatePath(addon.getAddonInfo('profile'))
mysettings = xbmcaddon.Addon(id='plugin.video.sctv')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
datafile = xbmc.translatePath(os.path.join(home, 'data.json'))

data = json.loads(open(datafile,"r").read())

mode=None

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
							
	return param

params=get_params()

try: 	chn=urllib.unquote_plus(params["chn"])
except: pass
try: 	src=urllib.unquote_plus(params["src"])
except: pass
try: 	mode=int(params["mode"])
except: pass

def construct_menu(namex):
	name = data['directories'][namex]['title']
	lmode = '2'
	iconimage = ''
	desc = data['directories'][namex]['desc']

	menu_items = data['directories'][namex]['content']
	for menu_item in menu_items:
		#type == channel
		if (menu_item['type'] == "chn"):
			add_chn_link (menu_item['id'])
		#type == directory
		if (menu_item['type'] == "dir"):
			add_dir_link (menu_item['id'])
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	return

def add_chn_link (namex):
	ok = True
	title = data['channels'][namex]['title']
	name = title
	iconimage = data['channels'][namex]['logo']
	desc = data['channels'][namex]['desc']
	ref = data['channels'][namex]['src']['referer']
	stream_name = data['channels'][namex]['src']['playpath']
	src = data['channels'][namex]['src']['id']

	if (iconimage == ''):
		iconimage = 'default.png'
	if (mysettings.getSetting('descriptions')=='true' and desc != ''):
		if mysettings.getSetting('descriptions_on_right') == 'false':
			name = desc+"    "+name
		else:
			name = name+"    "+desc

	give_url = sys.argv[0]+"?mode=1&chn="+namex+"&src="+src
	liz = xbmcgui.ListItem( name, iconImage=xbmc.translatePath(os.path.join(home, 'resources', 'logos', iconimage)), thumbnailImage=xbmc.translatePath(os.path.join(home, 'resources', 'logos', iconimage)))
	liz.setInfo(type="Video", infoLabels={"Title": name})
	liz.setProperty("Fanart_Image",fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=give_url,listitem=liz)

def add_dir_link (namex):
	name = '['+data['directories'][namex]['title']+']'
	desc = data['directories'][namex]['desc']
	iconimage = data['directories'][namex]['logo']
	if (iconimage == ''):
		iconimage = 'default.png'
	if (mysettings.getSetting('descriptions')=='true' and desc != ''):
		if mysettings.getSetting('descriptions_on_right') == 'false':
			name = desc+"    "+name
		else:
			name = name+"    "+desc
	li = xbmcgui.ListItem( name, iconImage=xbmc.translatePath(os.path.join(home, 'resources', 'logos', iconimage)), thumbnailImage=xbmc.translatePath(os.path.join(home, 'resources', 'logos', iconimage)))
	li.setInfo(type="Video", infoLabels={"Title": name})
	li.setProperty("Fanart_Image",fanart)
	give_url = sys.argv[0]+"?mode=2&chn="+namex
	return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=give_url, listitem=li, isFolder=True)


def play_link(chn, src):
	item = xbmcgui.ListItem(chn)

	videoUrl = data['sources'][src]['url']
	playpath = data['channels'][chn]['src']['playpath']
	if (playpath != ''):
		videoUrl = videoUrl+"/"+playpath

	url_protocol = videoUrl.split(':')[0]
	if (url_protocol == "http"):
		full_url = videoUrl
	elif (url_protocol in ["rtmp", "rtmpe"]):
		swfUrl = data['sources'][src]['swfurl']
		pageUrl = data['sources'][src]['pageurl']
		if (data['channels'][chn]['src']['referer'] != ''):
			pageUrl = pageUrl+"/"+data['channels'][chn]['src']['referer']
		flashVer = 'LNX_11,2,202,233'
		token = data['sources'][src]['token']
		app = data['sources'][src]['app']

		full_url = videoUrl+' swfVfy=1 live=1 token='+token+' playpath='+playpath+' flashVer='+flashVer+' pageUrl='+pageUrl+' tcUrl='+videoUrl+' swfUrl='+swfUrl
	xbmc.Player().play(full_url, item)
	return

def Init():
	construct_menu("root")


if mode==None:
	Init()
elif mode==1:
	play_link(chn, src)
elif mode==2:
	construct_menu(chn)
