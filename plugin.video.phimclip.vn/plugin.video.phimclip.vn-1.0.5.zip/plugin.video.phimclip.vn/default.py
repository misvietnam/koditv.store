#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.phimclip.vn'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://m.phim.clip.vn"
ooo0OO = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
ooo0OO = xbmc . translatePath ( os . path . join ( ooo0OO , "icon.png" ) )
if 18 - 18: II111iiii . OOO0O / II1Ii / oo * OoO0O00
def IIiIiII11i ( ) :
 o0oOOo0O0Ooo ( 'Search' , '' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 o0oOOo0O0Ooo ( 'Phim lẻ' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=1' , 'indexajax' , 'http://echipstore.net/addonicons/Movies.jpg' )
 o0oOOo0O0Ooo ( 'Phim lẻ theo Quốc gia' , 'http://m.phim.clip.vn' , 'moviesbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 o0oOOo0O0Ooo ( 'Phim lẻ theo Thể loại' , 'http://m.phim.clip.vn' , 'moviesbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 o0oOOo0O0Ooo ( 'Phim bộ' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=2' , 'indexajax' , 'http://echipstore.net/addonicons/Series.jpg' )
 o0oOOo0O0Ooo ( 'Phim bộ theo Quốc gia' , 'http://m.phim.clip.vn' , 'seriesbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 o0oOOo0O0Ooo ( 'Phim bộ theo Thế loại' , 'http://m.phim.clip.vn' , 'seriesbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 o0oOOo0O0Ooo ( 'Tuyển tập' , 'http://m.phim.clip.vn/collections?p=1' , 'indexcollection' , 'http://echipstore.net/addonicons/Cinema.jpg' )
 o0oOOo0O0Ooo ( 'Phim chiếu rạp' , 'http://m.phim.clip.vn/cinema?p=1' , 'index' , 'http://echipstore.net/addonicons/Cinema.jpg' )
 if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11i / Ii1I
 IiiIII111iI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #IiiIII111iI = xbmc . translatePath ( os . path . join ( IiiIII111iI , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/clipvn.jpg' , IiiIII111iI )
 #IiII = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiiIII111iI )
 #iI1Ii11111iIi = xbmcgui . WindowDialog ( )
 #iI1Ii11111iIi . addControl ( IiII )
 #iI1Ii11111iIi . doModal ( )
 if 41 - 41: I1II1
def Ooo0OO0oOO ( m ) :
 o0oOOo0O0Ooo ( 'Việt Nam' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=viet-nam' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Hàn Quốc' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=han-quoc' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Trung Quốc' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=trung-quoc' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Hồng Kông' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=hong-kong' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Đài Loan' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=dai-loan' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Thái Lan' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=thai-lan' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Philippines' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=philippines' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Malaysia' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=malaysia' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Anh' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=anh' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Mỹ' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=my' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Nga' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=nga' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Ý' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=y' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Pháp' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=phap' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Đức' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=duc' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Nhật' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=nhat' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Ấn Độ' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=an-do' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Tây Ban Nha' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=tay-ban-nha' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Canada' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=ca-na-da' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Úc' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=uc' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Na Uy' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=na-uy' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Kazakhstan' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=kazakhstan' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Venezuela' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=venezuela' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Nam Phi' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=nam-phi' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Mexico' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=mexico' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Hà Lan' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=ha-lan' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'New Zealand' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=new-zealand' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Đan Mạch' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=dan-mach' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Áo' , 'http://m.phim.clip.vn/browse?m=%s&p=1&c=ao' % m , 'indexajax' , 'icon' )
 if 86 - 86: oO0o
def IIII ( m ) :
 o0oOOo0O0Ooo ( 'Hài hước' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=hai-huoc' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Võ thuật' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=vo-thuat' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Hoạt hình' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=hoat-hinh' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Hành động' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=hanh-dong' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Tình cảm lãng mạn' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=tinh-cam-lang-man' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Kinh dị - Bí ẩn' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=kinh-di-bi-an' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Phiêu lưu' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=phieu-luu' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Khoa học viễn tưởng' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=khoa-hoc-vien-tuong' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Hình sự' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=hinh-su' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Thần thoại' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=than-thoai' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Lịch sử - Tiểu sử' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=lich-su-tieu-su' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Cổ trang' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=co-trang' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Gia đình' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=gia-dinh' % m , 'indexajax' , 'icon' )
 o0oOOo0O0Ooo ( 'Tâm lý' , 'http://m.phim.clip.vn/film/ajaxLoadMoreFilm?p=1&m=%s&g=tam-ly' % m , 'indexajax' , 'icon' )
 if 59 - 59: II1i * o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( url ) :
 i1oOOoo00O0O = i1111 ( url )
 i11 = int ( re . compile ( 'p=(\d+)' ) . findall ( url ) [ 0 ] ) + 1
 I11 = re . compile ( '<li class="item clearfix" ><a href="(.+?)"><div [^>]*><img [^>]* src="(.+?)"/></div><div [^>]*><span [^>]*>(.+?)</span><span [^>]*>(.+?)</span><span [^>]*>(.+?)</span>' ) . findall ( i1oOOoo00O0O )
 for Oo0o0000o0o0 , oOo0oooo00o , oO0o0o0ooO0oO , oo0o0O00 , oO in I11 :
  o0oOOo0O0Ooo ( "[B]%s - %s[/B] (%s)" % ( oO0o0o0ooO0oO , oo0o0O00 , oO ) , Oo0o0000o0o0 , 'episodes' , oOo0oooo00o )
 o0oOOo0O0Ooo ( "[B]Next Page >>[/B]" , re . sub ( 'p=(\d+)' , 'p=%s' % i11 , url ) , 'indexajax' , ooo0OO )
 i1iiIIiiI111 = xbmc . getSkinDir ( )
 if i1iiIIiiI111 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 62 - 62: iIIIIiI - OoOO
def I1iiiiI1iII ( url ) :
 i1oOOoo00O0O = i1111 ( url )
 i11 = int ( re . compile ( 'p=(\d+)' ) . findall ( url ) [ 0 ] ) + 1
 I11 = re . compile ( '<a title="(.+?)" href="(.+?)"><img src="(.+?)" [^>]*>' ) . findall ( i1oOOoo00O0O )
 for IiIi11i , Oo0o0000o0o0 , oOo0oooo00o in I11 :
  o0oOOo0O0Ooo ( "[B]%s[/B]" % IiIi11i , Oo0o0000o0o0 , 'episodes' , oOo0oooo00o )
 o0oOOo0O0Ooo ( "[B]Next Page >>[/B]" , re . sub ( 'p=(\d+)' , 'p=%s' % i11 , url ) , 'indexcollection' , ooo0OO )
 i1iiIIiiI111 = xbmc . getSkinDir ( )
 if i1iiIIiiI111 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 43 - 43: I11i * II111iiii
def I111I11 ( url ) :
 i1oOOoo00O0O = i1111 ( url )
 i11 = int ( re . compile ( 'p=(\d+)' ) . findall ( url ) [ 0 ] ) + 1
 I11 = re . compile ( '<li [^>]*><a href="(.+?)"><div [^>]*><img[^>]*src="(.+?)"[^>]*></div><div [^>]*><span [^>]*>(.+?)</span><span [^>]*>(.+?)</span><span [^>]*>(.+?)</span>' ) . findall ( i1oOOoo00O0O )
 for Oo0o0000o0o0 , oOo0oooo00o , oO0o0o0ooO0oO , oo0o0O00 , oO in I11 :
  o0oOOo0O0Ooo ( "[B]%s - %s[/B] (%s)" % ( oO0o0o0ooO0oO , oo0o0O00 , oO ) , iiiii + Oo0o0000o0o0 , 'episodes' , oOo0oooo00o )
 if ( "cinema" not in url ) :
  o0oOOo0O0Ooo ( "[B]Next Page >>[/B]" , re . sub ( 'p=(\d+)' , 'p=%s' % i11 , url ) , 'index' , ooo0OO )
 i1iiIIiiI111 = xbmc . getSkinDir ( )
 if i1iiIIiiI111 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 62 - 62: o00 - Oo0oO0ooo - OOooOOo % oo / I1II1
def OoooooOoo ( ) :
 try :
  OO = xbmc . Keyboard ( '' , 'Enter search text' )
  OO . doModal ( )
  if ( OO . isConfirmed ( ) ) :
   oO0O = urllib . quote_plus ( OO . getText ( ) )
  OOoO000O0OO = 'http://m.phim.clip.vn/search?p=1&keyword=' + oO0O + '/'
  I111I11 ( OOoO000O0OO )
 except : pass
 if 23 - 23: i11iIiiIii + o0
def oOo ( url , name ) :
 i1oOOoo00O0O = i1111 ( url )
 oOoOoO = re . compile ( '<div class="item swiper-slide "><a href="(.+?)" [^>]*>(.+?)</a>' ) . findall ( i1oOOoo00O0O )
 for ii1I , OooO0 in oOoOoO :
  OooO0 = re . sub ( '<.*?>' , '' , OooO0 )
  ii1I = "http://m.clip.vn/embed/" + re . compile ( ',(.+?)/' ) . findall ( ii1I ) [ 0 ]
  II11iiii1Ii ( "[%s] Part - %s" % ( urllib . unquote_plus ( name ) , OooO0 . strip ( ) . encode ( "utf-8" ) ) , ii1I , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 70 - 70: I1II1 / OOO0O % OoOO % i11iIiiIii . o0
def O0o0Oo ( url , name ) :
 Oo00OOOOO = O0O ( url )
 O00o0OO = re . compile ( '<a href="javascript:" onclick="CLIP.play(.+?)">' ) . findall ( Oo00OOOOO ) [ 0 ]
 I11i1 ( "direct" , O00o0OO . replace ( '("' , '' ) . replace ( '")' , '' ) . encode ( "utf-8" ) )
 if 25 - 25: i1 - Oo0oO0ooo . II1Ii
def I11i1 ( videoType , videoId ) :
 OOoO000O0OO = ""
 if ( videoType == "youtube" ) :
  OOoO000O0OO = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' + videoId . replace ( '?' , '' )
  xbmc . executebuiltin ( "xbmc.PlayMedia(" + OOoO000O0OO + ")" )
 elif ( videoType == "vimeo" ) :
  OOoO000O0OO = 'plugin://plugin.video.vimeo/?action=play_video&videoID=' + videoId
 elif ( videoType == "tudou" ) :
  OOoO000O0OO = 'plugin://plugin.video.tudou/?mode=3&url=' + videoId
 else :
  I11ii1 = xbmc . Player ( )
  I11ii1 . play ( videoId )
  if 9 - 9: o00ooo0 + I1II1 % o00ooo0 + oo . oO0o
def i1111 ( url ) :
 III1i1i = urllib2 . Request ( url )
 iiI1 = urllib2 . urlopen ( III1i1i )
 i1oOOoo00O0O = iiI1 . read ( )
 iiI1 . close ( )
 i1oOOoo00O0O = '' . join ( i1oOOoo00O0O . splitlines ( ) ) . replace ( '\'' , '"' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\n' , '' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\t' , '' )
 i1oOOoo00O0O = re . sub ( '  +' , ' ' , i1oOOoo00O0O )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '> <' , '><' )
 return i1oOOoo00O0O
 if 19 - 19: II1i + OoOO
def O0O ( url ) :
 III1i1i = urllib2 . Request ( url )
 III1i1i . add_header ( 'User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; da-dk) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3' )
 iiI1 = urllib2 . urlopen ( III1i1i )
 i1oOOoo00O0O = iiI1 . read ( )
 iiI1 . close ( )
 i1oOOoo00O0O = '' . join ( i1oOOoo00O0O . splitlines ( ) ) . replace ( '\'' , '"' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\n' , '' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\t' , '' )
 i1oOOoo00O0O = re . sub ( '  +' , ' ' , i1oOOoo00O0O )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '> <' , '><' )
 return i1oOOoo00O0O
 if 53 - 53: II1Ii . oo
def II11iiii1Ii ( name , url , mode , iconimage , mirrorname ) :
 ii1I1i1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 OOoo0O0 = True
 iiiIi1i1I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iiiIi1i1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOoo0O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1I1i1I , listitem = iiiIi1i1I )
 return OOoo0O0
 if 80 - 80: OOooOOo - ii1IiI1i
def o0oOOo0O0Ooo ( name , url , mode , iconimage ) :
 ii1I1i1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 OOoo0O0 = True
 iiiIi1i1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiiIi1i1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOoo0O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1I1i1I , listitem = iiiIi1i1I , isFolder = True )
 return OOoo0O0
 if 87 - 87: I1II1 / II1i - oo * oO0o / II1Ii . II111iiii
def iii11I111 ( parameters ) :
 OOOO00ooo0Ooo = { }
 if 69 - 69: I11i * II111iiii + ii1IiI1i . OoO0O00 / II111iiii
 if parameters :
  O000oo0O = parameters [ 1 : ] . split ( "&" )
  for OOOO in O000oo0O :
   i11i1 = OOOO . split ( '=' )
   if ( len ( i11i1 ) ) == 2 :
    OOOO00ooo0Ooo [ i11i1 [ 0 ] ] = i11i1 [ 1 ]
 return OOOO00ooo0Ooo
 if 29 - 29: Ii1I % o0 + OoOO / I11i + oO0o * I11i
i1I1iI = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 93 - 93: OOO0O % I1II1 * oo
if os . path . exists ( i1I1iI ) == False :
 os . mkdir ( i1I1iI )
Ii11Ii1I = os . path . join ( i1I1iI , 'visitor' )
if 72 - 72: o00 / oo * i1 - iIIIIiI
if os . path . exists ( Ii11Ii1I ) == False :
 from random import randint
 Oo0O0O0ooO0O = open ( Ii11Ii1I , "w" )
 Oo0O0O0ooO0O . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 Oo0O0O0ooO0O . close ( )
 if 15 - 15: Ii1I + OOooOOo - II1Ii / oO0o
def oo000OO00Oo ( k , e ) :
 O0OOO0OOoO0O = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for O00Oo000ooO0 in range ( len ( e ) ) :
  OoO0O00IIiII = k [ O00Oo000ooO0 % len ( k ) ]
  o0ooOooo000oOO = chr ( ( 256 + ord ( e [ O00Oo000ooO0 ] ) - ord ( OoO0O00IIiII ) ) % 256 )
  O0OOO0OOoO0O . append ( o0ooOooo000oOO )
 return "" . join ( O0OOO0OOoO0O )
 if 59 - 59: OoO0O00 + II1Ii * OOooOOo + oo
Oo0OoO00oOO0o = xbmc . translatePath ( "special://userdata" )
Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( Oo0OoO00oOO0o , "uaip" ) )
if not os . path . exists ( Oo0OoO00oOO0o ) :
 OOO00O = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 OOoOO0oo0ooO = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in OOO00O for b in OOoOO0oo0ooO ) :
  O0o0O00Oo0o0 = i1111 ( oo000OO00Oo ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  O00Oo000ooO0 = O0o0O00Oo0o0 . replace ( '"' , '' ) . split ( ',' )
  ii1I1i1I = OOO00O . split ( ";" )
  with open ( Oo0OoO00oOO0o , "w" ) as O00O0oOO00O00 :
   O00O0oOO00O00 . write ( OOO00O + ";" + O00Oo000ooO0 [ 0 ] )
  i1Oo00 = { 'entry.436422879' : ii1I1i1I [ 0 ] , 'entry.1845442180' : ii1I1i1I [ 1 ] , 'entry.972740559' : ii1I1i1I [ 2 ] , 'entry.1836504487' : ii1I1i1I [ 3 ] , 'entry.1101915442' : O00Oo000ooO0 [ 0 ] , 'entry.1574658585' : O00Oo000ooO0 [ 1 ] , 'entry.1805295152' : O00Oo000ooO0 [ 2 ] , 'entry.512145242' : O00Oo000ooO0 [ 3 ] , 'entry.773640853' : O00Oo000ooO0 [ 4 ] , 'entry.319359888' : O00Oo000ooO0 [ 5 ] , 'entry.122876449' : O00Oo000ooO0 [ 6 ] , 'entry.1791949570' : O00Oo000ooO0 [ 7 ] , 'entry.1970011699' : O00Oo000ooO0 [ 8 ] , 'entry.422390183' : O00Oo000ooO0 [ 9 ] , 'entry.2030601071' : O00Oo000ooO0 [ 10 ] }
  i1i = urllib . urlencode ( i1Oo00 )
  iiI111I1iIiI = oo000OO00Oo ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  III1i1i = urllib2 . Request ( iiI111I1iIiI , i1i )
  III1i1i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  III1i1i . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  III1i1i . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  iiI1 = urllib2 . urlopen ( III1i1i )
  if 41 - 41: i1 . OoOO + II111iiii * I11i % i1 * i1
def iIIIIi1iiIi1 ( utm_url ) :
 iii1i1iiiiIi = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  III1i1i = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : iii1i1iiiiIi }
 )
  iiI1 = urllib2 . urlopen ( III1i1i ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return iiI1
 if 2 - 2: o0 / II111iiii / I11i % OOooOOo % o00ooo0
def o0o00OO0 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  i1I1ii = "1.0"
  oOOo0 = open ( Ii11Ii1I ) . read ( )
  oo00O00oO = "ClipVN"
  iIiIIIi = "UA-52209804-2"
  ooo00OOOooO = "www.viettv24.com"
  O00OOOoOoo0O = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   O000OOo00oo = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oo00O00oO ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oOOo0 , "1" , "1" , "2" ] )
   if 71 - 71: i11iIiiIii + Oo0oO0ooo
   if 57 - 57: I1II1 . II1i . oo
   if 42 - 42: II1i + Ii1I % II111iiii
   if 6 - 6: I1II1
   if 68 - 68: OOooOOo - ii1IiI1i
  else :
   if group == "None" :
    O000OOo00oo = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oo00O00oO + "/" + name ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oOOo0 , "1" , "1" , "2" ] )
    if 28 - 28: ii1IiI1i . oO0o / oO0o + i1 . Ii1I
    if 1 - 1: OOO0O / OoO0O00
    if 33 - 33: II1i
    if 18 - 18: I11i % o00 * II111iiii
    if 87 - 87: i11iIiiIii
   else :
    O000OOo00oo = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oo00O00oO + "/" + group + "/" + name ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oOOo0 , "1" , "1" , "2" ] )
    if 93 - 93: Ii1I - ii1IiI1i % i11iIiiIii . o00 / o00 - iIIIIiI
    if 9 - 9: Ii1I / i1 - o0 / II1Ii / OOO0O - I11i
    if 91 - 91: o00 % oo % OOO0O
    if 20 - 20: oO0o % o00ooo0 / o00ooo0 + o00ooo0
    if 45 - 45: I1II1 - Oo0oO0ooo - II1Ii - ii1IiI1i . OoO0O00 / II111iiii
    if 51 - 51: II111iiii + o00
  print "============================ POSTING ANALYTICS ============================"
  iIIIIi1iiIi1 ( O000OOo00oo )
  if 8 - 8: I1II1 * OOooOOo - o00ooo0 - ii1IiI1i * oO0o % o0
  if not group == "None" :
   ii = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( ooo00OOOooO ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + oo00O00oO + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( oo00O00oO ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , oOOo0 , "1" , "2" ] )
   if 90 - 90: I11i % oo / ii1IiI1i
   if 44 - 44: i1 . ii1IiI1i / Ii1I + o00ooo0
   if 65 - 65: II111iiii
   if 68 - 68: oO0o % iIIIIiI
   if 88 - 88: OOO0O - OoOO + oO0o
   if 40 - 40: o0 * o00ooo0 + oO0o % o00
   if 74 - 74: I1II1 - i1 + II1Ii + iIIIIiI / OOooOOo
   if 23 - 23: II111iiii
   try :
    print "============================ POSTING TRACK EVENT ============================"
    iIIIIi1iiIi1 ( ii )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 85 - 85: o00ooo0
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 84 - 84: o0 . OOO0O % II1Ii + o00ooo0 % II1Ii % ii1IiI1i
IIi1 = iii11I111 ( sys . argv [ 2 ] )
I1I1I = IIi1 . get ( 'mode' )
OOoO000O0OO = IIi1 . get ( 'url' )
OoOO000 = IIi1 . get ( 'name' )
if type ( OOoO000O0OO ) == type ( str ( ) ) :
 OOoO000O0OO = urllib . unquote_plus ( OOoO000O0OO )
 if 14 - 14: Oo0oO0ooo - Ii1I
Ii1i1iI1iIIi = str ( sys . argv [ 1 ] )
if I1I1I == 'index' :
 o0o00OO0 ( "Browse" , OoOO000 )
 I111I11 ( OOoO000O0OO )
elif I1I1I == 'indexajax' :
 o0o00OO0 ( "Browse" , OoOO000 )
 o0oOoO00o ( OOoO000O0OO )
elif I1I1I == 'indexcollection' :
 o0o00OO0 ( "Browse" , OoOO000 )
 I1iiiiI1iII ( OOoO000O0OO )
elif I1I1I == 'search' :
 o0o00OO0 ( "None" , "Search" )
 OoooooOoo ( )
elif I1I1I == 'moviesbyregion' :
 o0o00OO0 ( "Browse" , OoOO000 )
 Ooo0OO0oOO ( "1" )
elif I1I1I == 'moviesbycategory' :
 o0o00OO0 ( "Browse" , OoOO000 )
 IIII ( "1" )
elif I1I1I == 'seriesbyregion' :
 o0o00OO0 ( "Browse" , OoOO000 )
 Ooo0OO0oOO ( "2" )
elif I1I1I == 'seriesbycategory' :
 o0o00OO0 ( "Browse" , OoOO000 )
 IIII ( "2" )
elif I1I1I == 'episodes' :
 o0o00OO0 ( "Browse" , OoOO000 )
 oOo ( OOoO000O0OO , OoOO000 )
elif I1I1I == 'loadvideo' :
 o0o00OO0 ( "Play" , OoOO000 + "/" + OOoO000O0OO )
 I1Ii = xbmcgui . DialogProgress ( )
 I1Ii . create ( 'ClipVN' , 'Loading video. Please wait...' )
 O0o0Oo ( OOoO000O0OO , OoOO000 )
 I1Ii . close ( )
 del I1Ii
else :
 o0o00OO0 ( "None" , "None" )
 IIiIiII11i ( )
xbmcplugin . endOfDirectory ( int ( Ii1i1iI1iIIi ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
