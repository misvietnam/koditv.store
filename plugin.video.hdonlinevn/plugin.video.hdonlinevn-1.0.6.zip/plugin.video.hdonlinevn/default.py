#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , cookielib
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.hdonlinevn'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
iiiii = xbmc . translatePath ( os . path . join ( iiiii , "icon.png" ) )
ooo0OO = cookielib . LWPCookieJar ( )
II1 = urllib2 . build_opener ( urllib2 . HTTPCookieProcessor ( ooo0OO ) )
if 64 - 64: Oooo % OOO0O / II1Ii / Ooo
def OoO0O00 ( ) :
 IIiIiII11i ( 'Tìm kiếm' , 'http://hdonline.vn/tim-kiem/keyword/trang-1.html' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 IIiIiII11i ( 'Phim lẻ' , 'http://hdonline.vn/danh-sach/phim-le/trang-1.html' , 'index' , iiiii )
 IIiIiII11i ( 'Phim bộ' , 'http://hdonline.vn/danh-sach/phim-bo/trang-1.html' , 'index' , iiiii )
 IIiIiII11i ( 'Phim lẻ Lồng tiếng' , 'http://hdonline.vn/danh-sach/phim-le/trang-1.html?byaudio=3' , 'index' , iiiii )
 IIiIiII11i ( 'Phim lẻ Thuyết minh' , 'http://hdonline.vn/danh-sach/phim-le/trang-1.html?byaudio=2' , 'index' , iiiii )
 IIiIiII11i ( 'Phim bộ Lồng tiếng' , 'http://hdonline.vn/danh-sach/phim-bo/trang-1.html?byaudio=3' , 'index' , iiiii )
 IIiIiII11i ( 'Phim bộ Thuyết minh' , 'http://hdonline.vn/danh-sach/phim-bo/trang-1.html?byaudio=2' , 'index' , iiiii )
 if 51 - 51: oOo0O0Ooo * I1ii11iIi11i
 I1IiI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #I1IiI = xbmc . translatePath ( os . path . join ( I1IiI , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/hdonline.jpg' , I1IiI )
 #o0OOO = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , I1IiI )
 #iIiiiI = xbmcgui . WindowDialog ( )
 #iIiiiI . addControl ( o0OOO )
 #iIiiiI . doModal ( )
 if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 o0oO0 = xbmc . getSkinDir ( )
 if o0oO0 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 100 - 100: i11Ii11I1Ii1i
def Oooo0oOoO00o ( url ) :
 i1 = oOOoo00O0O ( url )
 i1111 = re . compile ( '<img[^>]*data-original="(.+?)"[^>]*/><div[^>]*><h1[^>]*><a href="(.+?)"[^>]*>(.+?)</a>(.+?)</h1>' ) . findall ( i1 )
 for i11 , I11 , Oo0o0000o0o0 , oOo0oooo00o in i1111 :
  IIiIiII11i ( Oo0o0000o0o0 + oOo0oooo00o , I11 , 'episodes' , i11 )
 if ( len ( i1111 ) == 32 ) :
  oO0o0o0ooO0oO = int ( re . compile ( 'trang-(\d+).html' ) . findall ( url ) [ 0 ] )
  url = url . replace ( "trang-" + str ( oO0o0o0ooO0oO ) + ".html" , "trang-" + str ( oO0o0o0ooO0oO + 1 ) + ".html" )
  IIiIiII11i ( "Next >>" , url , 'index' , "" )
 o0oO0 = xbmc . getSkinDir ( )
 if o0oO0 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 52 - 52: I1 - OOoOoo00oo - iiI11
def OOooO ( url ) :
 i1 = oOOoo00O0O ( url )
 i1111 = re . compile ( OOoO00o ( "1" , "baadUZSdkqSkblOkpaOWkp5emqWWnqRTb1lfXHBabWCmnW8=" ) ) . findall ( i1 )
 if len ( i1111 ) > 0 :
  if 9 - 9: I1iiiiI1iII - oOo0 / i1Ii % Ooo
  o00O00O0O0O = re . compile ( OOoO00o ( "2" , "bpNSmqSXmG9UWmBdcVtUUpuWb1RaYF1xW1SNkHCPXHBgXXFupaKToFKVnpOlpW9UoJOfl1RwWmBdcVtuYaWik6Bw" ) ) . findall ( i1111 [ 0 ] )
  for OooO0OO , iiiIi , IiIIIiI1I1 in o00O00O0O0O :
   if 86 - 86: i11iIiiIii + OOoOoo00oo + i1Ii * I1 + ii1II11I1ii1I
   if len ( OooO0OO . split ( "." ) ) < 3 :
    OooO0OO = OooO0OO . replace ( "html" , iiiIi + ".html" )
   oOoO ( "[" + oOo + "] - " + IiIIIiI1I1 , OOoO00o ( "6" , "nqqqpnBlZaNknpqlpKKfpJtkrKRl" ) + OooO0OO , 'loadvideo' , "" )
 else :
  url = OOoO00o ( "6" , "nqqqpnBlZaNknpqlpKKfpJtkrKRl" ) + url . split ( "/" ) [ - 1 ]
  i1 = oOoOoO ( url )
  i1111 = re . compile ( OOoO00o ( "5" , "caqhVZihlqiocleoqaealqJinqmaoqhXc3GWVZ2nmptyV11jYHReV5CTc5Jfcw==" ) ) . findall ( i1 )
  i1 = oOoOoO ( OOoO00o ( "6" , "nqqqpnBlZaNknpqlpKKfpJtkrKRl" ) + i1111 [ 0 ] )
  ii1I = re . compile ( OOoO00o ( "7" , "c6qmrKmanFeqqZp0WV9lYnZgWZKVdZRhZnU=" ) ) . findall ( i1 ) [ 0 ]
  OooO0 = re . compile ( OOoO00o ( "8" , "dKyqmZujWKuqm6SZpp91Wq6hWlijoaacdVqrrZqsoayknataWKyxqJ11WqydsKxnrqysWlirqpt1WmBmY3dhWpOWdpVidg==" ) ) . findall ( i1 )
  if len ( OooO0 ) > 0 :
   ii1I = ii1I + OOoO00o ( "9" , "oa2tqXNoaKZnoZ2op6Wip55nr6do" ) + OooO0 [ 0 ]
  oOoO ( oOo , ii1I , 'loadvideo' , "" )
  if 35 - 35: i11Ii11I1Ii1i % oOo0 % i11iIiiIii / II1Ii
def Ii11iI1i ( url ) :
 try :
  OooO0o0Oo = xbmc . Keyboard ( '' , 'Enter search text' )
  OooO0o0Oo . doModal ( )
  if ( OooO0o0Oo . isConfirmed ( ) ) :
   Oo00OOOOO = urllib . quote_plus ( OooO0o0Oo . getText ( ) . replace ( " " , "-" ) )
  url = url . replace ( "keyword" , Oo00OOOOO )
  Oooo0oOoO00o ( url )
 except : pass
 if 85 - 85: i1Ii . iiI11 - i11iII1iiI % i1Ii % oOo0O0Ooo
def OO0o00o ( url , sub , name ) :
 if "[" in name :
  i1 = oOoOoO ( url )
  ii1I = re . compile ( OOoO00o ( "7" , "c6qmrKmanFeqqZp0WV9lYnZgWZKVdZRhZnU=" ) ) . findall ( i1 ) [ 0 ]
  url = ii1I
  OooO0 = re . compile ( OOoO00o ( "8" , "dKyqmZujWKuqm6SZpp91Wq6hWlijoaacdVqrrZqsoayknataWKyxqJ11WqydsKxnrqysWlirqpt1WmBmY3dhWpOWdpVidg==" ) ) . findall ( i1 )
  if len ( OooO0 ) > 0 :
   sub = OOoO00o ( "9" , "oa2tqXNoaKZnoZ2op6Wip55nr6do" ) + OooO0 [ 0 ]
 oOOo0oo = xbmcgui . ListItem ( name )
 oOOo0oo . setProperty ( "IsPlayable" , "true" )
 oOOo0oo . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOo0oo )
 o0oo0o0O00OO = xbmc . Player ( )
 if ( sub != '' ) :
  I1IiI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
  I1IiI = xbmc . translatePath ( os . path . join ( I1IiI , "temp.sub" ) )
  o0oO = urllib2 . Request ( sub )
  o0oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; da-dk) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3' )
  o0oO . add_header ( 'Referer' , url )
  I1i1iii = urllib2 . urlopen ( o0oO )
  i1iiI11I = I1i1iii . read ( )
  I1i1iii . close ( )
  with open ( I1IiI , "w" ) as iiii :
   iiii . write ( i1iiI11I )
   if 54 - 54: oO0o0ooO0 * i11Ii11I1Ii1i
  o0oo0o0O00OO . setSubtitles ( I1IiI )
  if 13 - 13: I1iiiiI1iII + iI1Ii11111iIi - II1Ii + oOo0 . iiI11 + i11iII1iiI
def oOOoo00O0O ( url ) :
 i1 = ""
 if os . path . exists ( url ) == True :
  i1 = open ( url ) . read ( )
 else :
  o0oO = urllib2 . Request ( url )
  o0oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
  Ii = urllib2 . urlopen ( o0oO )
  i1 = Ii . read ( )
  Ii . close ( )
 i1 = '' . join ( i1 . splitlines ( ) ) . replace ( '\'' , '"' )
 i1 = i1 . replace ( '\n' , '' )
 i1 = i1 . replace ( '\t' , '' )
 i1 = re . sub ( '  +' , ' ' , i1 )
 i1 = i1 . replace ( '> <' , '><' )
 return i1
 if 57 - 57: OOO0O * OOoOoo00oo
def oOoOoO ( url ) :
 o0oO = urllib2 . Request ( url )
 o0oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; da-dk) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3' )
 try :
  Ii = II1 . open ( o0oO )
  if "app.php" in Ii . geturl ( ) :
   Ii = II1 . open ( o0oO )
  i1 = Ii . read ( )
  Ii . close ( )
  i1 = '' . join ( i1 . splitlines ( ) ) . replace ( '\'' , '"' )
  i1 = i1 . replace ( '\n' , '' )
  i1 = i1 . replace ( '\t' , '' )
  i1 = re . sub ( '  +' , ' ' , i1 )
  i1 = i1 . replace ( '> <' , '><' )
  return i1
 except urllib2 . HTTPError , OOOO :
  if OOOO . code in [ 404 ] :
   Ii = II1 . open ( o0oO )
   i1 = Ii . read ( )
   Ii . close ( )
   i1 = '' . join ( i1 . splitlines ( ) ) . replace ( '\'' , '"' )
   i1 = i1 . replace ( '\n' , '' )
   i1 = i1 . replace ( '\t' , '' )
   i1 = re . sub ( '  +' , ' ' , i1 )
   i1 = i1 . replace ( '> <' , '><' )
   return i1
   if 87 - 87: iiIIIII1i1iI / I1 - Ooo * i11Ii11I1Ii1i / II1Ii . Oooo
def OOoO00o ( k , e ) :
 iii11I111 = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for OOOO00ooo0Ooo in range ( len ( e ) ) :
  OOOooOooo00O0 = k [ OOOO00ooo0Ooo % len ( k ) ]
  Oo0OO = chr ( ( 256 + ord ( e [ OOOO00ooo0Ooo ] ) - ord ( OOOooOooo00O0 ) ) % 256 )
  iii11I111 . append ( Oo0OO )
 return "" . join ( iii11I111 )
 if 92 - 92: iiIIIII1i1iI - iI1Ii11111iIi
def oOoO ( name , url , mode , iconimage ) :
 i11i1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIIii1II1II = True
 i1I1iI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1I1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1I1iI . setProperty ( "IsPlayable" , "true" )
 IIIii1II1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i11i1 , listitem = i1I1iI )
 return IIIii1II1II
 if 93 - 93: OOO0O % iiIIIII1i1iI * Ooo
def IIiIiII11i ( name , url , mode , iconimage ) :
 i11i1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIIii1II1II = True
 i1I1iI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1II1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i11i1 , listitem = i1I1iI , isFolder = True )
 return IIIii1II1II
 if 16 - 16: Oooo - oOo0 * OOO0O + iiI11
def Ii11iII1 ( parameters ) :
 Oo0O0O0ooO0O = { }
 if 15 - 15: oO0o0ooO0 + iI1Ii11111iIi - II1Ii / i11Ii11I1Ii1i
 if parameters :
  oo000OO00Oo = parameters [ 1 : ] . split ( "&" )
  for O0OOO0OOoO0O in oo000OO00Oo :
   O00Oo000ooO0 = O0OOO0OOoO0O . split ( '=' )
   if ( len ( O00Oo000ooO0 ) ) == 2 :
    Oo0O0O0ooO0O [ O00Oo000ooO0 [ 0 ] ] = O00Oo000ooO0 [ 1 ]
 return Oo0O0O0ooO0O
 if 100 - 100: Oooo + I1iiiiI1iII - i11Ii11I1Ii1i + i11iIiiIii * OOoOoo00oo
iII = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 80 - 80: I1iiiiI1iII . iiIIIII1i1iI
if os . path . exists ( iII ) == False :
 os . mkdir ( iII )
IIi = os . path . join ( iII , 'visitor' )
if 26 - 26: iiI11
if os . path . exists ( IIi ) == False :
 from random import randint
 OOO = open ( IIi , "w" )
 OOO . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 OOO . close ( )
 if 59 - 59: oOo0O0Ooo + II1Ii * iI1Ii11111iIi + Ooo
Oo0OoO00oOO0o = xbmc . translatePath ( "special://userdata" )
Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( Oo0OoO00oOO0o , "uaip" ) )
if not os . path . exists ( Oo0OoO00oOO0o ) :
 OOO00O = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 OOoOO0oo0ooO = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in OOO00O for b in OOoOO0oo0ooO ) :
  O0o0O00Oo0o0 = oOOoo00O0O ( OOoO00o ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  OOOO00ooo0Ooo = O0o0O00Oo0o0 . replace ( '"' , '' ) . split ( ',' )
  i11i1 = OOO00O . split ( ";" )
  with open ( Oo0OoO00oOO0o , "w" ) as iiii :
   iiii . write ( OOO00O + ";" + OOOO00ooo0Ooo [ 0 ] )
  O00O0oOO00O00 = { 'entry.436422879' : i11i1 [ 0 ] , 'entry.1845442180' : i11i1 [ 1 ] , 'entry.972740559' : i11i1 [ 2 ] , 'entry.1836504487' : i11i1 [ 3 ] , 'entry.1101915442' : OOOO00ooo0Ooo [ 0 ] , 'entry.1574658585' : OOOO00ooo0Ooo [ 1 ] , 'entry.1805295152' : OOOO00ooo0Ooo [ 2 ] , 'entry.512145242' : OOOO00ooo0Ooo [ 3 ] , 'entry.773640853' : OOOO00ooo0Ooo [ 4 ] , 'entry.319359888' : OOOO00ooo0Ooo [ 5 ] , 'entry.122876449' : OOOO00ooo0Ooo [ 6 ] , 'entry.1791949570' : OOOO00ooo0Ooo [ 7 ] , 'entry.1970011699' : OOOO00ooo0Ooo [ 8 ] , 'entry.422390183' : OOOO00ooo0Ooo [ 9 ] , 'entry.2030601071' : OOOO00ooo0Ooo [ 10 ] }
  i1Oo00 = urllib . urlencode ( O00O0oOO00O00 )
  i1i = OOoO00o ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  o0oO = urllib2 . Request ( i1i , i1Oo00 )
  o0oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  o0oO . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  o0oO . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  Ii = urllib2 . urlopen ( o0oO )
  if 50 - 50: I1iiiiI1iII
def i11I1iIiII ( utm_url ) :
 oO00o0 = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  o0oO = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : oO00o0 }
 )
  Ii = urllib2 . urlopen ( o0oO ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return Ii
 if 55 - 55: iii1II11ii + OOO0O / iI1Ii11111iIi * iiIIIII1i1iI - i11iIiiIii - OOoOoo00oo
def ii1ii1ii ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  oooooOoo0ooo = "1.0"
  I1I1IiI1 = open ( IIi ) . read ( )
  III1iII1I1ii = "HDOnline"
  oOOo0 = "UA-52209804-2"
  oo00O00oO = "www.viettv24.com"
  iIiIIIi = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   ooo00OOOooO = iIiIIIi + "?" + "utmwv=" + oooooOoo0ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( III1iII1I1ii ) + "&utmac=" + oOOo0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , I1I1IiI1 , "1" , "1" , "2" ] )
   if 67 - 67: I1 * iiIIIII1i1iI * oO0o0ooO0 + i11Ii11I1Ii1i / Ooo
   if 11 - 11: OOoOoo00oo + iiI11 - i1Ii * iiIIIII1i1iI % i11iIiiIii - oOo0
   if 83 - 83: I1 / I1ii11iIi11i
   if 34 - 34: I1iiiiI1iII
   if 57 - 57: iiIIIII1i1iI . I1 . Ooo
  else :
   if group == "None" :
    ooo00OOOooO = iIiIIIi + "?" + "utmwv=" + oooooOoo0ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( III1iII1I1ii + "/" + name ) + "&utmac=" + oOOo0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , I1I1IiI1 , "1" , "1" , "2" ] )
    if 42 - 42: I1 + oO0o0ooO0 % Oooo
    if 6 - 6: iiIIIII1i1iI
    if 68 - 68: iI1Ii11111iIi - i11iII1iiI
    if 28 - 28: i11iII1iiI . i11Ii11I1Ii1i / i11Ii11I1Ii1i + iii1II11ii . oO0o0ooO0
    if 1 - 1: OOO0O / oOo0O0Ooo
   else :
    ooo00OOOooO = iIiIIIi + "?" + "utmwv=" + oooooOoo0ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( III1iII1I1ii + "/" + group + "/" + name ) + "&utmac=" + oOOo0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , I1I1IiI1 , "1" , "1" , "2" ] )
    if 33 - 33: I1
    if 18 - 18: ii1II11I1ii1I % iiI11 * Oooo
    if 87 - 87: i11iIiiIii
    if 93 - 93: oO0o0ooO0 - i11iII1iiI % i11iIiiIii . iiI11 / iiI11 - oOo0
    if 9 - 9: oO0o0ooO0 / iii1II11ii - I1ii11iIi11i / II1Ii / OOO0O - ii1II11I1ii1I
    if 91 - 91: iiI11 % Ooo % OOO0O
  print "============================ POSTING ANALYTICS ============================"
  i11I1iIiII ( ooo00OOOooO )
  if 20 - 20: i11Ii11I1Ii1i % OOoOoo00oo / OOoOoo00oo + OOoOoo00oo
  if not group == "None" :
   III1IiiI = iIiIIIi + "?" + "utmwv=" + oooooOoo0ooo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( oo00O00oO ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + III1iII1I1ii + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( III1iII1I1ii ) + "&utmac=" + oOOo0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , I1I1IiI1 , "1" , "2" ] )
   if 31 - 31: ii1II11I1ii1I . I1ii11iIi11i
   if 46 - 46: iiI11
   if 8 - 8: iiIIIII1i1iI * iI1Ii11111iIi - OOoOoo00oo - i11iII1iiI * i11Ii11I1Ii1i % I1ii11iIi11i
   if 48 - 48: Oooo
   if 11 - 11: I1 + II1Ii - i11iII1iiI / ii1II11I1ii1I + iii1II11ii . oOo0O0Ooo
   if 41 - 41: OOoOoo00oo - Oooo - Oooo
   if 68 - 68: i11Ii11I1Ii1i % oOo0
   if 88 - 88: OOO0O - i1Ii + i11Ii11I1Ii1i
   try :
    print "============================ POSTING TRACK EVENT ============================"
    i11I1iIiII ( III1IiiI )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 40 - 40: I1ii11iIi11i * OOoOoo00oo + i11Ii11I1Ii1i % iiI11
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 74 - 74: iiIIIII1i1iI - iii1II11ii + II1Ii + oOo0 / iI1Ii11111iIi
i1I1iI1iIi111i = Ii11iII1 ( sys . argv [ 2 ] )
iiIi1IIi1I = i1I1iI1iIi111i . get ( 'mode' )
o0OoOO000ooO0 = i1I1iI1iIi111i . get ( 'url' )
oOo = i1I1iI1iIi111i . get ( 'name' )
if type ( o0OoOO000ooO0 ) == type ( str ( ) ) :
 o0OoOO000ooO0 = urllib . unquote_plus ( o0OoOO000ooO0 )
if type ( oOo ) == type ( str ( ) ) :
 oOo = urllib . unquote_plus ( oOo )
o0o0o0oO0oOO = str ( sys . argv [ 1 ] )
if iiIi1IIi1I == 'index' :
 ii1ii1ii ( "Browse" , oOo )
 Oooo0oOoO00o ( o0OoOO000ooO0 )
elif iiIi1IIi1I == 'episodes' :
 ii1ii1ii ( "Browse" , oOo )
 OOooO ( o0OoOO000ooO0 )
elif iiIi1IIi1I == 'search' :
 ii1ii1ii ( "None" , "Search" )
 Ii11iI1i ( o0OoOO000ooO0 )
elif iiIi1IIi1I == 'loadvideo' :
 ii1ii1ii ( "Play" , oOo + "/" + o0OoOO000ooO0 )
 ii1Ii11I = xbmcgui . DialogProgress ( )
 ii1Ii11I . create ( 'HDOnline' , 'Loading video. Please wait...' )
 if len ( o0OoOO000ooO0 . split ( 'http' ) ) > 2 :
  OO0o00o ( 'http' + o0OoOO000ooO0 . split ( 'http' ) [ 1 ] , 'http' + o0OoOO000ooO0 . split ( 'http' ) [ 2 ] + 'http' + o0OoOO000ooO0 . split ( 'http' ) [ 3 ] , oOo )
 else :
  OO0o00o ( 'http' + o0OoOO000ooO0 . split ( 'http' ) [ 1 ] , '' , oOo )
 ii1Ii11I . close ( )
 del ii1Ii11I
else :
 ii1ii1ii ( "None" , "None" )
 OoO0O00 ( )
xbmcplugin . endOfDirectory ( int ( o0o0o0oO0oOO ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
