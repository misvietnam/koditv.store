#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , urlresolver , os , zlib , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.phim60s.info'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://phim60s.info/"
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Search' , 'http://phim60s.info/' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 i1I11i ( 'Movies' , 'http://phim60s.info/danh-sach/phim-le/page-1.html' , 'index' , 'http://echipstore.net/addonicons/Movies.jpg' )
 i1I11i ( 'Series' , 'http://phim60s.info/danh-sach/phim-bo/page-1.html' , 'index' , 'http://echipstore.net/addonicons/Series.jpg' )
 i1I11i ( 'Videos By Region' , 'http://phim60s.info/' , 'videosbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 i1I11i ( 'Videos By Category ' , 'http://phim60s.info/' , 'videosbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 if 27 - 27: Iii1IIIiiI + iI - Oo / iII11iiIII111 % iiiIIii1I1Ii . O00oOoOoO0o0O
 II1ii1II1iII1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #II1ii1II1iII1 = xbmc . translatePath ( os . path . join ( II1ii1II1iII1 , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/phim60s.jpg' , II1ii1II1iII1 )
 #Ii = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , II1ii1II1iII1 )
 #Oo0o = xbmcgui . WindowDialog ( )
 #Oo0o . addControl ( Ii )
 #Oo0o . doModal ( )
 if 60 - 60: Oo0oO0oo0oO00 + i11Ii11I1Ii1i . ooO - IiIiI11iIi
def Ii1IIii11 ( ) :
 i1I11i ( 'Vietnam' , 'http://phim60s.info/quoc-gia/phim-viet-nam/1/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Korea' , 'http://phim60s.info/quoc-gia/phim-han-quoc/2/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'China' , 'http://phim60s.info/quoc-gia/phim-trung-quoc/4/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Hong Kong' , 'http://phim60s.info/quoc-gia/phim-hong-kong/6/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Japan' , 'http://phim60s.info/quoc-gia/phim-nhat-ban/3/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Taiwan' , 'http://phim60s.info/quoc-gia/phim-dai-loan/7/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Asia' , 'http://phim60s.info/quoc-gia/phim-chau-a/8/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'India' , 'http://phim60s.info/quoc-gia/phim-an-do/10/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Thailand' , 'http://phim60s.info/quoc-gia/phim-thai-lan/11/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'UE-US' , 'http://phim60s.info/quoc-gia/phim-my-chau-au/5/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 if 55 - 55: i1111 - III / Oo0oO0oo0oO00 . OOO * oOooOoO0Oo0O - IiIiI11iIi
def O0o0o0000o0 ( ) :
 i1I11i ( 'Action' , 'http://phim60s.info/the-loai/phim-hanh-dong/1/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Comedy' , 'http://phim60s.info/the-loai/phim-hai-huoc/7/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Animation' , 'http://phim60s.info/the-loai/phim-hoat-hinh/5/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Martial Arts' , 'http://phim60s.info/the-loai/phim-vo-thuat/2/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Psychological' , 'http://phim60s.info/the-loai/phim-tam-ly/16/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Fiction' , 'http://phim60s.info/the-loai/phim-vien-tuong/8/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'War/Combat' , 'http://phim60s.info/the-loai/phim-chien-tranh/3/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Family' , 'http://phim60s.info/the-loai/phim-gia-dinh/15/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Horror' , 'http://phim60s.info/the-loai/phim-kinh-di-ma/6/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Adventure' , 'http://phim60s.info/the-loai/phim-phieu-luu/9/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Fantasy' , 'http://phim60s.info/the-loai/phim-than-thoai/10/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'TV' , 'http://phim60s.info/the-loai/phim-truyen-hinh/11/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Sports' , 'http://phim60s.info/the-loai/phim-the-thao/18/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Music/Art' , 'http://phim60s.info/the-loai/phim-am-nhac/19/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Romance' , 'http://phim60s.info/the-loai/phim-tinh-cam/17/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Popular' , 'http://phim60s.info/the-loai/phim-co-trang/12/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Thriller' , 'http://phim60s.info/the-loai/phim-giat-gan/24/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Crime' , 'http://phim60s.info/the-loai/phim-hinh-su/4/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Documentary' , 'http://phim60s.info/the-loai/phim-tai-lieu/20/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 i1I11i ( 'Adult Only (18+)' , 'http://phim60s.info/the-loai/phim-18/28/page-1.html' , 'index' , 'http://phim60s.info/skin/vip/images/logo.png' )
 if 11 - 11: III * Iii1IIIiiI % Oo0oO0oo0oO00 / i11iIiiIii / Oooo000o / ooO
def oO0O0o0o0 ( url ) :
 i1iIIII = I1 ( url )
 O0OoOoo00o = re . compile ( '<ul class="list-film">(.+?)<div class="pagination">' ) . findall ( i1iIIII )
 iiiI11 = re . compile ( '<div class="inner"><a title="(.+?)" href="(.+?)"><img [^>]* src="(.+?)"></a><div class="info"><div class="name">(.+?)<span class="process"><span>(.+?)</span></span></div></div></li>' ) . findall ( O0OoOoo00o [ 0 ] )
 for OOooO , OOoO00o , II111iiii , II , oOoOo00oOo in iiiI11 :
  if ( ( oOoOo00oOo . find ( "HD" ) >= 0 ) or ( oOoOo00oOo . find ( "Full HD" ) >= 0 ) ) :
   oOoOo00oOo = "[B][COLOR yellow]" + oOoOo00oOo + "[/COLOR][/B]"
  i1I11i ( "[B]" + OOooO + "[/B] (" + oOoOo00oOo + ")" , iiiii + OOoO00o , 'mirrors' , II111iiii )
 Ooo00O00O0O0O = re . compile ( '<div class="pagination">(.+?)</div>' ) . findall ( i1iIIII )
 OooO0OO = re . compile ( '<a class="pagelink" [^>]* href="(.+?)" [^>]*>(.+?)</a>' ) . findall ( Ooo00O00O0O0O [ 0 ] )
 for OOoO00o , iiiIi in OooO0OO :
  i1I11i ( iiiIi , iiiii + OOoO00o , 'index' , "" )
 IiIIIiI1I1 = xbmc . getSkinDir ( )
 if IiIIIiI1I1 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 86 - 86: i11iIiiIii + Oo0oO0oo0oO00 + i1111 * O00oOoOoO0o0O + iI
def oOoO ( ) :
 try :
  oOo = xbmc . Keyboard ( '' , 'Enter search text' )
  oOo . doModal ( )
  if 63 - 63: OOo
  if ( oOo . isConfirmed ( ) ) :
   ooOoOoo0O = urllib . quote_plus ( oOo . getText ( ) )
  OooO0 = 'http://phim60s.info/tim-kiem/' + ooOoOoo0O + '/'
  oO0O0o0o0 ( OooO0 )
 except : pass
 if 35 - 35: iiiIIii1I1Ii % IiIiI11iIi % i11iIiiIii / oOooOoO0Oo0O
def Ii11iI1i ( url ) :
 Ooo = O0o0Oo ( url )
 if Ooo . find ( "html" ) != - 1 :
  i1iIIII = I1 ( Ooo )
  Oo00OOOOO = re . compile ( '<div class="serverlist">(.+?)</div></div>' ) . findall ( i1iIIII )
  O0O = re . compile ( '<div class="label"><i></i><img [^>]*/>(.+?)</div>' ) . findall ( Oo00OOOOO [ 0 ] )
  for O00o0OO in O0O :
   i1I11i ( O00o0OO , Ooo . encode ( "utf-8" ) , 'episodes' , "" )
   if 44 - 44: ooO / iIIi1iI1II111 % III * iII11iiIII111 + OOo
   if 3 - 3: III / Oooo000o % O00oOoOoO0o0O * i11iIiiIii / iIIi1iI1II111 * O00oOoOoO0o0O
   if 49 - 49: iII11iiIII111 % Oo0oO0oo0oO00 + III . Oooo000o % Oo
def I1i1iii ( url , name ) :
 i1iIIII = I1 ( url )
 Oo00OOOOO = re . compile ( '<div class="serverlist">(.+?)</div></div>' ) . findall ( i1iIIII )
 O0O = re . compile ( '<div class="label"><i></i><img [^>]*/>' + urllib2 . unquote ( name ) + '(.+?)</li></ul>' ) . findall ( Oo00OOOOO [ 0 ] )
 i1iiI11I = re . compile ( '<a[^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( O0O [ 0 ] )
 for iiii , oO0o0O0OOOoo0 in i1iiI11I :
  oO0o0O0OOOoo0 = re . sub ( '<.*?>' , '' , oO0o0O0OOOoo0 )
  IiIiiI ( "[%s] Part - %s" % ( name , oO0o0O0OOOoo0 . strip ( ) . encode ( "utf-8" ) ) , iiiii + iiii , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 31 - 31: Oo0oO0oo0oO00 . Oo0oO0oo0oO00 - iI / OOO + i1111 * Oooo000o
def O0o0Oo ( url ) :
 O0ooOooooO = I1 ( url )
 iiii = re . compile ( '<a [^>]* class="btn-watch" href="(.+?)"></a>' ) . findall ( O0ooOooooO )
 return iiiii + iiii [ 0 ]
 if 60 - 60: O00oOoOoO0o0O / O00oOoOoO0o0O
def I1II1III11iii ( url , name ) :
 i1iIIII = I1 ( url )
 O0OoOoo00o = re . compile ( 'proxy.link=(.+?)&' ) . findall ( i1iIIII )
 if ( len ( O0OoOoo00o ) >= 1 ) :
  Oo000 = O0OoOoo00o [ 0 ]
  if ( Oo000 . find ( "cyworld.vn" ) > 0 ) :
   oo = I1 ( Oo000 )
   ii11I = re . compile ( '<meta property="og:video" content="(.+?)" />' ) . findall ( oo )
   Ooo0OO0oOO = ii11I [ 0 ]
   ii11i1 ( "direct" , Ooo0OO0oOO )
  elif ( Oo000 . find ( "picasaweb.google" ) > 0 ) :
   oo = IIIii1II1II ( Oo000 )
   ii11I = re . compile ( '\{"url"(.*?)\}' ) . findall ( oo )
   Ooo0OO0oOO = ""
   for i1I1iI in range ( 0 , len ( ii11I ) - 1 ) :
    if ( ii11I [ i1I1iI ] . find ( "video/mpeg4" ) != - 1 ) :
     Ooo0OO0oOO = ii11I [ i1I1iI ]
   ii11i1 ( name , Ooo0OO0oOO . split ( '","' ) [ 0 ] . replace ( ':"' , '' ) . encode ( "utf-8" ) )
  elif ( Oo000 . find ( "youtube" ) > 0 ) :
   ii11I = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( Oo000 )
   Ooo0OO0oOO = ii11I [ 0 ] [ len ( ii11I [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
   ii11i1 ( "youtube" , Ooo0OO0oOO )
  elif ( Oo000 . find ( "clip.vn" ) > 0 ) :
   Oo000 = Oo000 . replace ( 'http://' , 'http://m.' )
   oo = oo0OooOOo0 ( Oo000 )
   ii11I = re . compile ( '<a href="javascript:" onclick="CLIP.play(.+?)">' ) . findall ( oo )
   Ooo0OO0oOO = ii11I [ 0 ]
   ii11i1 ( "direct" , Ooo0OO0oOO . replace ( '("' , '' ) . replace ( '")' , '' ) . encode ( "utf-8" ) )
  else :
   o0O = [ ]
   O00oO = name
   I11i1I1I = urlresolver . HostedMediaFile ( url = Oo000 , title = O00oO )
   o0O . append ( I11i1I1I )
   oO0Oo = urlresolver . choose_source ( o0O )
   if oO0Oo :
    Ooo0OO0oOO = oO0Oo . resolve ( )
   else :
    Ooo0OO0oOO = ""
   ii11i1 ( "direct" , Ooo0OO0oOO )
 else :
  O0OoOoo00o = re . compile ( '<iframe [^>]* src="(.+?)">' ) . findall ( i1iIIII )
  Oo000 = O0OoOoo00o [ 0 ]
  if ( Oo000 . find ( "youtube" ) > 0 ) :
   ii11I = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( Oo000 )
   Ooo0OO0oOO = ii11I [ 0 ] [ len ( ii11I [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
   ii11i1 ( "youtube" , Ooo0OO0oOO )
   if 54 - 54: iI - Oooo000o + oOooOoO0Oo0O
def ii11i1 ( videoType , videoId ) :
 OooO0 = ""
 if ( videoType == "youtube" ) :
  OooO0 = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' + videoId . replace ( '?' , '' )
  xbmc . executebuiltin ( "xbmc.PlayMedia(" + OooO0 + ")" )
 elif ( videoType == "vimeo" ) :
  OooO0 = 'plugin://plugin.video.vimeo/?action=play_video&videoID=' + videoId
 elif ( videoType == "tudou" ) :
  OooO0 = 'plugin://plugin.video.tudou/?mode=3&url=' + videoId
 else :
  O0o0 = xbmcgui . ListItem ( OO00Oo )
  O0o0 . setInfo ( 'video' , { 'Title' : OO00Oo } )
  O0o0 . setProperty ( "IsPlayable" , "true" )
  O0o0 . setPath ( videoId )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0o0 )
  if 51 - 51: ooO * iI + O00oOoOoO0o0O + OOO
def I1 ( url ) :
 o0O0O00 = urllib2 . Request ( url )
 o0O0O00 . add_header ( 'Host' , 'phim60s.info' )
 o0O0O00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 o0O0O00 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 o000o = urllib2 . urlopen ( o0O0O00 )
 i1iIIII = o000o . read ( )
 o000o . close ( )
 i1iIIII = '' . join ( i1iIIII . splitlines ( ) ) . replace ( '\'' , '"' )
 i1iIIII = i1iIIII . replace ( '\n' , '' )
 i1iIIII = i1iIIII . replace ( '\t' , '' )
 i1iIIII = re . sub ( '  +' , ' ' , i1iIIII )
 i1iIIII = i1iIIII . replace ( '> <' , '><' )
 return i1iIIII
 if 7 - 7: i1111 * OOO % iII11iiIII111 . ooO
def IIIii1II1II ( url ) :
 Ii1iIiII1ii1 = urllib2 . urlopen ( 'http://echipstore.net/p' )
 ooOooo000oOO = Ii1iIiII1ii1 . read ( )
 Ii1iIiII1ii1 . close ( )
 Oo0oOOo = { 'isslverify' : 'true' , 'iagent' : 'User-Agent: Mozilla/5.0 (Windows NT 6.3; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0' , 'url' : url , 'ihttpheader' : 'true' }
 Oo0OoO00oOO0o = urllib . urlencode ( Oo0oOOo )
 o0O0O00 = urllib2 . Request ( urllib . unquote_plus ( ooOooo000oOO ) , Oo0OoO00oOO0o )
 o0O0O00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
 o0O0O00 . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
 o0O0O00 . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
 o0O0O00 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 o000o = urllib2 . urlopen ( o0O0O00 )
 i1iIIII = o000o . read ( )
 o000o . close ( )
 if "gzip" in o000o . info ( ) . getheader ( 'Content-Encoding' ) :
  i1iIIII = zlib . decompress ( i1iIIII , 16 + zlib . MAX_WBITS )
 i1iIIII = '' . join ( i1iIIII . splitlines ( ) ) . replace ( '\'' , '"' )
 i1iIIII = i1iIIII . replace ( '\n' , '' )
 i1iIIII = i1iIIII . replace ( '\t' , '' )
 i1iIIII = re . sub ( '  +' , ' ' , i1iIIII )
 i1iIIII = i1iIIII . replace ( '> <' , '><' )
 return i1iIIII
 if 80 - 80: iII11iiIII111 + iiiIIii1I1Ii - iiiIIii1I1Ii % i11Ii11I1Ii1i
def oo0OooOOo0 ( url ) :
 o0O0O00 = urllib2 . Request ( url )
 o0O0O00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; da-dk) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3' )
 o000o = urllib2 . urlopen ( o0O0O00 )
 i1iIIII = o000o . read ( )
 o000o . close ( )
 i1iIIII = '' . join ( i1iIIII . splitlines ( ) ) . replace ( '\'' , '"' )
 i1iIIII = i1iIIII . replace ( '\n' , '' )
 i1iIIII = i1iIIII . replace ( '\t' , '' )
 i1iIIII = re . sub ( '  +' , ' ' , i1iIIII )
 i1iIIII = i1iIIII . replace ( '> <' , '><' )
 return i1iIIII
 if 63 - 63: Oooo000o - Oo + iIIi1iI1II111 % O00oOoOoO0o0O / ii11i / iI
def IiIiiI ( name , url , mode , iconimage , mirrorname ) :
 O0o0O00Oo0o0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 O00O0oOO00O00 = True
 i1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1 . setProperty ( "IsPlayable" , "true" )
 O00O0oOO00O00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0o0O00Oo0o0 , listitem = i1 )
 return O00O0oOO00O00
 if 57 - 57: iIIi1iI1II111 / IiIiI11iIi % OOO / IiIiI11iIi . Iii1IIIiiI / iIIi1iI1II111
def i1I11i ( name , url , mode , iconimage ) :
 O0o0O00Oo0o0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O00O0oOO00O00 = True
 i1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O00O0oOO00O00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0o0O00Oo0o0 , listitem = i1 , isFolder = True )
 return O00O0oOO00O00
 if 89 - 89: Iii1IIIiiI
def OO0oOoOO0oOO0 ( parameters ) :
 oO0OOoo0OO = { }
 if 65 - 65: Oo0oO0oo0oO00 . ii11i / iIIi1iI1II111 - Oo0oO0oo0oO00
 if parameters :
  iii1i1iiiiIi = parameters [ 1 : ] . split ( "&" )
  for Iiii in iii1i1iiiiIi :
   OO0OoO0o00 = Iiii . split ( '=' )
   if ( len ( OO0OoO0o00 ) ) == 2 :
    oO0OOoo0OO [ OO0OoO0o00 [ 0 ] ] = OO0OoO0o00 [ 1 ]
 return oO0OOoo0OO
 if 53 - 53: iIIi1iI1II111 * OOO + iiiIIii1I1Ii
IioOOo0 = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 54 - 54: iIIi1iI1II111 - ooO % iiiIIii1I1Ii
if os . path . exists ( IioOOo0 ) == False :
 os . mkdir ( IioOOo0 )
OOoO = os . path . join ( IioOOo0 , 'visitor' )
if 46 - 46: OOO . OOo - oOooOoO0Oo0O
if os . path . exists ( OOoO ) == False :
 from random import randint
 ooo00OOOooO = open ( OOoO , "w" )
 ooo00OOOooO . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 ooo00OOOooO . close ( )
 if 67 - 67: O00oOoOoO0o0O * iII11iiIII111 * Oo + iiiIIii1I1Ii / III
def I1I111 ( k , e ) :
 Oo00oo0oO = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for i1I1iI in range ( len ( e ) ) :
  IIiIi1iI = k [ i1I1iI % len ( k ) ]
  i1IiiiI1iI = chr ( ( 256 + ord ( e [ i1I1iI ] ) - ord ( IIiIi1iI ) ) % 256 )
  Oo00oo0oO . append ( i1IiiiI1iI )
 return "" . join ( Oo00oo0oO )
 if 49 - 49: Oo0oO0oo0oO00 / OOO . oo00oOOo
ooOOoooooo = xbmc . translatePath ( "special://userdata" )
ooOOoooooo = xbmc . translatePath ( os . path . join ( ooOOoooooo , "uaip" ) )
if not os . path . exists ( ooOOoooooo ) :
 II1I = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 O0 = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in II1I for b in O0 ) :
  i1II1Iiii1I11 = I1 ( I1I111 ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  i1I1iI = i1II1Iiii1I11 . replace ( '"' , '' ) . split ( ',' )
  O0o0O00Oo0o0 = II1I . split ( ";" )
  with open ( ooOOoooooo , "w" ) as IIII :
   IIII . write ( II1I + ";" + i1I1iI [ 0 ] )
  Oo0oOOo = { 'entry.436422879' : O0o0O00Oo0o0 [ 0 ] , 'entry.1845442180' : O0o0O00Oo0o0 [ 1 ] , 'entry.972740559' : O0o0O00Oo0o0 [ 2 ] , 'entry.1836504487' : O0o0O00Oo0o0 [ 3 ] , 'entry.1101915442' : i1I1iI [ 0 ] , 'entry.1574658585' : i1I1iI [ 1 ] , 'entry.1805295152' : i1I1iI [ 2 ] , 'entry.512145242' : i1I1iI [ 3 ] , 'entry.773640853' : i1I1iI [ 4 ] , 'entry.319359888' : i1I1iI [ 5 ] , 'entry.122876449' : i1I1iI [ 6 ] , 'entry.1791949570' : i1I1iI [ 7 ] , 'entry.1970011699' : i1I1iI [ 8 ] , 'entry.422390183' : i1I1iI [ 9 ] , 'entry.2030601071' : i1I1iI [ 10 ] }
  Oo0OoO00oOO0o = urllib . urlencode ( Oo0oOOo )
  ooOooo000oOO = I1I111 ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  o0O0O00 = urllib2 . Request ( ooOooo000oOO , Oo0OoO00oOO0o )
  o0O0O00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  o0O0O00 . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  o0O0O00 . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  o000o = urllib2 . urlopen ( o0O0O00 )
  if 32 - 32: oOooOoO0Oo0O / ii11i - iI
def o00oooO0Oo ( utm_url ) :
 o0O0OOO0Ooo = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  o0O0O00 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : o0O0OOO0Ooo }
 )
  o000o = urllib2 . urlopen ( o0O0O00 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return o000o
 if 45 - 45: iIIi1iI1II111 / iI
def i1IIIII11I1IiI ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  i1I = "1.0"
  OoOO = open ( OOoO ) . read ( )
  ooOOO0 = "Phim60s"
  o0o = "UA-52209804-2"
  O0OOoO00OO0o = "www.viettv24.com"
  I1111IIIIIi = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   Iiii1i1 = I1111IIIIIi + "?" + "utmwv=" + i1I + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( ooOOO0 ) + "&utmac=" + o0o + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , OoOO , "1" , "1" , "2" ] )
   if 84 - 84: Oooo000o . ii11i % oOooOoO0Oo0O + Oo0oO0oo0oO00 % oOooOoO0Oo0O % OOO
   if 42 - 42: OOO / O00oOoOoO0o0O / iI + i11Ii11I1Ii1i / Iii1IIIiiI
   if 84 - 84: i1111 * oo00oOOo + OOo
   if 53 - 53: i11Ii11I1Ii1i % oo00oOOo . ooO - ii11i - ooO * oo00oOOo
   if 77 - 77: ii11i * OOO
  else :
   if group == "None" :
    Iiii1i1 = I1111IIIIIi + "?" + "utmwv=" + i1I + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( ooOOO0 + "/" + name ) + "&utmac=" + o0o + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , OoOO , "1" , "1" , "2" ] )
    if 95 - 95: Oooo000o + i11iIiiIii
    if 6 - 6: i1111 / i11iIiiIii + i11Ii11I1Ii1i * iII11iiIII111
    if 80 - 80: oo00oOOo
    if 83 - 83: O00oOoOoO0o0O . i11iIiiIii + oo00oOOo . iI * O00oOoOoO0o0O
    if 53 - 53: oo00oOOo
   else :
    Iiii1i1 = I1111IIIIIi + "?" + "utmwv=" + i1I + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( ooOOO0 + "/" + group + "/" + name ) + "&utmac=" + o0o + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , OoOO , "1" , "1" , "2" ] )
    if 31 - 31: OOO
    if 80 - 80: IiIiI11iIi . i11iIiiIii - iI
    if 25 - 25: OOO
    if 62 - 62: iiiIIii1I1Ii + iIIi1iI1II111
    if 98 - 98: iI
    if 51 - 51: OOo - iII11iiIII111 + oo00oOOo * Oo0oO0oo0oO00 . O00oOoOoO0o0O + iII11iiIII111
  print "============================ POSTING ANALYTICS ============================"
  o00oooO0Oo ( Iiii1i1 )
  if 78 - 78: i11iIiiIii / i11Ii11I1Ii1i - Oo0oO0oo0oO00 / iiiIIii1I1Ii + iII11iiIII111
  if not group == "None" :
   oOoooo0O0Oo = I1111IIIIIi + "?" + "utmwv=" + i1I + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( O0OOoO00OO0o ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + ooOOO0 + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( ooOOO0 ) + "&utmac=" + o0o + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , OoOO , "1" , "2" ] )
   if 76 - 76: Oo0oO0oo0oO00 + ooO
   if 34 - 34: OOo
   if 89 - 89: OOo * Iii1IIIiiI * IiIiI11iIi + i11Ii11I1Ii1i - O00oOoOoO0o0O
   if 8 - 8: iI % iIIi1iI1II111 / Oooo000o - iII11iiIII111
   if 43 - 43: i11iIiiIii + OOo * oo00oOOo * IiIiI11iIi * iIIi1iI1II111
   if 64 - 64: iiiIIii1I1Ii % ii11i * iII11iiIII111
   if 79 - 79: iIIi1iI1II111
   if 78 - 78: Oo + iiiIIii1I1Ii - IiIiI11iIi
   try :
    print "============================ POSTING TRACK EVENT ============================"
    o00oooO0Oo ( oOoooo0O0Oo )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 38 - 38: iI - iII11iiIII111 + ii11i / Iii1IIIiiI % OOo
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 57 - 57: OOO / i1111
Ii1I1Ii = OO0oOoOO0oOO0 ( sys . argv [ 2 ] )
OOoO0 = Ii1I1Ii . get ( 'mode' )
OooO0 = Ii1I1Ii . get ( 'url' )
OO00Oo = Ii1I1Ii . get ( 'name' )
if type ( OooO0 ) == type ( str ( ) ) :
 OooO0 = urllib . unquote_plus ( OooO0 )
if type ( OO00Oo ) == type ( str ( ) ) :
 OO00Oo = urllib . unquote_plus ( OO00Oo )
 if 86 - 86: iII11iiIII111 * iI % III . Oo0oO0oo0oO00 . i11iIiiIii
oOOoo00O00o = str ( sys . argv [ 1 ] )
if OOoO0 == 'index' :
 i1IIIII11I1IiI ( "Browse" , OO00Oo )
 oO0O0o0o0 ( OooO0 )
elif OOoO0 == 'search' :
 i1IIIII11I1IiI ( "None" , "Search" )
 oOoO ( )
elif OOoO0 == 'videosbyregion' :
 i1IIIII11I1IiI ( "Browse" , OO00Oo )
 Ii1IIii11 ( )
elif OOoO0 == 'videosbycategory' :
 i1IIIII11I1IiI ( "Browse" , OO00Oo )
 O0o0o0000o0 ( )
elif OOoO0 == 'mirrors' :
 i1IIIII11I1IiI ( "Browse" , OO00Oo )
 Ii11iI1i ( OooO0 )
elif OOoO0 == 'episodes' :
 i1IIIII11I1IiI ( "Browse" , OO00Oo )
 I1i1iii ( OooO0 , OO00Oo )
elif OOoO0 == 'loadvideo' :
 i1IIIII11I1IiI ( "Play" , OO00Oo + "/" + OooO0 )
 O0O00Oo = xbmcgui . DialogProgress ( )
 O0O00Oo . create ( 'phim60s.info' , 'Loading video. Please wait...' )
 I1II1III11iii ( OooO0 , OO00Oo )
 O0O00Oo . close ( )
 del O0O00Oo
else :
 i1IIIII11I1IiI ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( oOOoo00O00o ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
