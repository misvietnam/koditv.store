#!/usr/bin/python
# coding=utf-8
import os , xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , json , base64 , random
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.hayhaytv'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://api.hayhaytv.vn/"
ooo0OO = "https://fbcdn-profile-a.akamaihd.net/hprofile-ak-ash4/s100x100/293975_126352604193712_667893495_t.jpg"
II1 = "50"
if 64 - 64: Oooo % OOO0O / II1Ii / Ooo
def OoO0O00 ( ) :
 IIiIiII11i ( 'Search' , iiiii + 'search' , 'search' , 'http://static.hayhaytv.vn/layout_m/images/search_bt.png' , '' , '' )
 IIiIiII11i ( 'Phim bộ' , iiiii + 'hot/newest_bundle_movies' , 'index' , 'http://echipstore.net/addonicons/Series.jpg' , '' , '{"pageCount":' + II1 + ',"startIndex":0}' )
 IIiIiII11i ( 'Phim lẻ' , iiiii + 'hot/newest_single_movies' , 'index' , 'http://echipstore.net/addonicons/Movies.jpg' , '' , '{"pageCount":' + II1 + ',"startIndex":0}' )
 IIiIiII11i ( 'Phim chiếu rạp' , iiiii + 'hot/cinema_movies' , 'index' , 'http://echipstore.net/addonicons/Cinema.jpg' , '' , '{"pageCount":' + II1 + ',"startIndex":0}' )
 IIiIiII11i ( 'TV Show' , iiiii + 'show' , 'index' , 'http://echipstore.net/addonicons/TVShows.jpg' , '' , '{"pageCount":' + II1 + ',"startIndex":0}' )
 IIiIiII11i ( 'Theo thể loại' , iiiii + 'category' , 'videosbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' , '' , '' )
 IIiIiII11i ( 'Theo quốc gia' , iiiii + 'countries' , 'videosbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' , '' , '' )
 if 51 - 51: oOo0O0Ooo * I1ii11iIi11i
 try :
  I1IiI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
#  I1IiI = xbmc . translatePath ( os . path . join ( I1IiI , "temp.jpg" ) )
#  urllib . urlretrieve ( 'http://echipstore.net/images/hayhaytv.jpg' , I1IiI )
#  o0OOO = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , I1IiI )
#  iIiiiI = xbmcgui . WindowDialog ( )
#  iIiiiI . addControl ( o0OOO )
#  iIiiiI . doModal ( )
 finally :
  pass
  if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
def o0oO0 ( ) :
 oo00 = o00 ( Oo0oO0ooo , '' )
 for o0oOoO00o in oo00 [ 'data' ] :
  i1 = '{"type_film":-1,"pageCount":' + II1 + ',"category_id":' + o0oOoO00o [ 'id' ] + ',"startIndex":0,"order_id":"1","country_id":-1}'
  IIiIiII11i ( o0oOoO00o [ 'name' ] . encode ( 'utf-8' ) , iiiii + 'search/filter' , 'index' , 'hayhaytvicon' , '' , i1 )
  if 64 - 64: oo % O0Oooo00
def Ooo0 ( ) :
 oo00 = o00 ( Oo0oO0ooo , '' )
 for oo00000o0 in oo00 [ 'data' ] :
  i1 = '{"type_film":-1,"pageCount":' + II1 + ',"category_id":-1,"startIndex":0,"order_id":"1","country_id":' + oo00000o0 [ 'id' ] + '}'
  IIiIiII11i ( oo00000o0 [ 'name' ] . encode ( 'utf-8' ) , iiiii + 'search/filter' , 'index' , 'hayhaytvicon' , '' , i1 )
  if 34 - 34: O0o00 % o0ooo / OOO0Ooo0ooO0oOOOOo / I111IiIi % OoOOo / OOO0O
def I1IiIiiIII ( url , requestdata ) :
 oo00 = o00 ( url , requestdata )
 for iI11 in oo00 [ 'data' ] :
  iII111ii = ''
  if ( iI11 [ 'extension' ] != '' ) :
   iII111ii = '[COLOR yellow]' + iI11 [ 'extension' ] + '[/COLOR] - '
  iII111ii = iII111ii + '[B]' + iI11 [ 'name' ] + '[/B]'
  try :
   if ( iI11 [ 'last_episode' ] != '' ) :
    iII111ii = iII111ii + ' [COLOR green](' + iI11 [ 'last_episode' ] + ')[/COLOR]'
  except KeyError : pass
  if 'show' in url :
   IIiIiII11i ( iII111ii . encode ( 'utf-8' ) , iiiii + 'show/show_detail' , 'moviedetail' , iI11 [ 'image' ] . encode ( 'utf-8' ) , iI11 [ 'intro_text' ] . encode ( 'utf-8' ) , '{"show_id":"' + iI11 [ 'id' ] + '"}' )
  else :
   IIiIiII11i ( iII111ii . encode ( 'utf-8' ) , iiiii + 'movie/movie_detail' , 'moviedetail' , iI11 [ 'image' ] . encode ( 'utf-8' ) , iI11 [ 'intro_text' ] . encode ( 'utf-8' ) , '{"movie_id":"' + iI11 [ 'id' ] + '"}' )
 i1iIIi1 = json . loads ( requestdata )
 i1iIIi1 [ 'startIndex' ] = int ( i1iIIi1 [ 'startIndex' ] ) + int ( II1 )
 IIiIiII11i ( 'Next 50' , url , 'index' , '' , '' , json . dumps ( i1iIIi1 ) )
 ii11iIi1I = xbmc . getSkinDir ( )
 if ii11iIi1I == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(51)' )
  if 6 - 6: iI1Ii11111iIi * o0ooo
def O00O0O0O0 ( ) :
 try :
  ooO0O = xbmc . Keyboard ( '' , 'Enter search text' )
  ooO0O . doModal ( )
  if ( ooO0O . isConfirmed ( ) ) :
   ooiii11iII = ooO0O . getText ( )
  I1IiIiiIII ( Oo0oO0ooo , '{"pageCount":' + II1 + ',"key":"' + ooiii11iII + '","startIndex":0}' )
 except : pass
 if 42 - 42: I111IiIi + oO0o0ooO0
def OOoO000O0OO ( url , requestdata ) :
 iI11 = o00 ( url , requestdata ) [ 'data' ]
 if ( len ( iI11 [ 'list_episode' ] ) == 0 ) :
  for iiI1IiI in iI11 [ 'link_play' ] :
   II ( iiI1IiI [ 'resolution' ] . strip ( ) , iiI1IiI [ 'mp3u8_link' ] . strip ( ) + iI11 [ 'vn_subtitle' ] . strip ( ) , 'playvideo' , iI11 [ 'image' ] )
   if 57 - 57: iiIIIII1i1iI
   if 14 - 14: iii1II11ii . I1ii11iIi11i / O0o00
 else :
  for IiiiI1II1I1 in iI11 [ 'list_episode' ] :
   for iiI1IiI in IiiiI1II1I1 [ 'link_play' ] :
    II ( '%s - %s' % ( IiiiI1II1I1 [ 'name' ] . encode ( 'utf-8' ) , iiI1IiI [ 'resolution' ] . strip ( ) . encode ( 'utf-8' ) ) , iiI1IiI [ 'mp3u8_link' ] . strip ( ) + IiiiI1II1I1 [ 'vn_subtitle' ] . strip ( ) , 'playvideo' , iI11 [ 'image' ] )
    if 95 - 95: II1Ii . OOO0O
    if 67 - 67: oo / II1Ii % O0Oooo00 - OOO0O
    if 82 - 82: i11iIiiIii . oo / iii1II11ii * Oooo % iiIIIII1i1iI % OOO0O
    if 78 - 78: OOO0O - O0o00 * i11iII1iiI + ii1II11I1ii1I + o0ooo + o0ooo
def I11I11i1I ( url , sub , title ) :
 url = ii11i1iIII ( "jlgh" , "0uDb2KSblpqbnJWam52VmZuilY3dppihnaGM2w==" ) % ( random . randint ( 214 , 218 ) , url . split ( ii11i1iIII ( "jlgh" , "pJ2gm58=" ) ) [ 1 ] )
 print url
 Ii1I = xbmcgui . ListItem ( title )
 Ii1I . setInfo ( 'video' , { 'Title' : title } )
 if 89 - 89: i11iIiiIii / Oooo * iI1Ii11111iIi % oo % iiIIIII1i1iI
 Ii1 = ii11i1iIII ( "dfg" , "34jLxdrIhqDC34jb3dbMhqCJysfKycjW09GJkIjM0cfQ0IihhtLMyNvg2M7W0s2ny9PIzdKVx9XUhuPE4Q==" )
 III1i1i = ii11i1iIII ( "sda" , "29jV456QosXR3JLJ1N3J1N3V6ZLX4ZPW5snTotfK2tLW48PU4sfK1NDA4cnV6tPT3g==" )
 if 26 - 26: II1Ii
 IiiI11Iiiii = o00 ( III1i1i , Ii1 )
 ii1I1i1I = IiiI11Iiiii [ ii11i1iIII ( "qw" , "1djl2A==" ) ]
 OOoo0O0 = ii1I1i1I [ ii11i1iIII ( "jkl" , "3trXz9nLy9vc" ) ]
 iiiIi1i1I = ii1I1i1I [ ii11i1iIII ( "sd" , "6NfY1tLN1w==" ) ]
 url = "%s?uid=%s&token=%s" % ( url , iiiIi1i1I , OOoo0O0 )
 if 80 - 80: iI1Ii11111iIi - i11iII1iiI
 if 87 - 87: iiIIIII1i1iI / O0Oooo00 - Ooo * oo / II1Ii . Oooo
 if 1 - 1: oOo0O0Ooo - O0Oooo00 / O0Oooo00
 if 46 - 46: O0o00 * oo - i11iII1iiI * iiIIIII1i1iI - I111IiIi
 Ii1I . setProperty ( "IsPlayable" , "true" )
 Ii1I . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , Ii1I )
 oo0 = xbmc . Player ( )
 if ( sub != '' ) :
  I1IiI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
  I1IiI = xbmc . translatePath ( os . path . join ( I1IiI , "temp.sub" ) )
  urllib . urlretrieve ( sub , I1IiI )
  oo0 . setSubtitles ( I1IiI )
  if 57 - 57: oo . oo
def o00 ( url , requestdata ) :
 OooOooo = urllib2 . Request ( urllib . unquote_plus ( url ) )
 if "user" not in url :
  O000oo0O = urllib2 . urlopen ( 'https://docs.google.com/spreadsheets/d/1X0197S9P7vn7UsUReZUBc8oK6IgjM99FYdX4lcwp68o/export?format=tsv' )
  OOOO = O000oo0O . read ( ) . decode ( 'utf-8-sig' )
  O000oo0O . close ( )
  OooOooo . set_proxy ( OOOO . split ( "\n" ) [ 0 ] , "http" )
 OooOooo . add_header ( 'Content-Type' , 'application/x-www-form-urlencoded' )
 OooOooo . add_header ( 'Authorization' , 'Basic YXBpaGF5OmFzb2tzYXBySkRMSVVSbzJ1MDF1cndqcQ==' )
 OooOooo . add_header ( 'User-Agent' , 'Apache-HttpClient/UNAVAILABLE (java 1.4)' )
 i11i1 = urllib . urlencode ( { 'request' : requestdata } )
 IiiI11Iiiii = urllib2 . urlopen ( OooOooo , i11i1 , 120 )
 IIIii1II1II = IiiI11Iiiii . read ( )
 IiiI11Iiiii . close ( )
 IIIii1II1II = '' . join ( IIIii1II1II . splitlines ( ) )
 i1I1iI = json . loads ( IIIii1II1II )
 return i1I1iI
 if 93 - 93: OOO0O % iiIIIII1i1iI * Ooo
def Ii11Ii1I ( url ) :
 IIIii1II1II = ""
 if os . path . exists ( url ) == True :
  IIIii1II1II = open ( url ) . read ( )
 else :
  OooOooo = urllib2 . Request ( url )
  OooOooo . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
  IiiI11Iiiii = urllib2 . urlopen ( OooOooo )
  IIIii1II1II = IiiI11Iiiii . read ( )
  IiiI11Iiiii . close ( )
 IIIii1II1II = '' . join ( IIIii1II1II . splitlines ( ) ) . replace ( '\'' , '"' )
 IIIii1II1II = IIIii1II1II . replace ( '\n' , '' )
 IIIii1II1II = IIIii1II1II . replace ( '\t' , '' )
 IIIii1II1II = re . sub ( '  +' , ' ' , IIIii1II1II )
 IIIii1II1II = IIIii1II1II . replace ( '> <' , '><' )
 return IIIii1II1II
 if 72 - 72: o0ooo / Ooo * iii1II11ii - I111IiIi
def II ( name , url , mode , iconimage ) :
 Oo0O0O0ooO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIIIii = True
 O0o0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0o0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0o0 . setProperty ( "IsPlayable" , "true" )
 IIIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0O0O0ooO0O , listitem = O0o0 )
 return IIIIii
 if 71 - 71: oo + OoOOo % i11iIiiIii + oO0o0ooO0 - OOO0Ooo0ooO0oOOOOo
def IIiIiII11i ( name , url , mode , iconimage , plot , requestdata ) :
 Oo0O0O0ooO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&requestdata=" + urllib . quote_plus ( requestdata )
 IIIIii = True
 O0o0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0o0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : plot } )
 IIIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0O0O0ooO0O , listitem = O0o0 , isFolder = True )
 return IIIIii
 if 88 - 88: iI1Ii11111iIi - i11iII1iiI % oo
def ii11i1iIII ( k , e ) :
 iI1I111Ii111i = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for I11IiI1I11i1i in range ( len ( e ) ) :
  iI1ii1Ii = k [ I11IiI1I11i1i % len ( k ) ]
  oooo000 = chr ( ( 256 + ord ( e [ I11IiI1I11i1i ] ) - ord ( iI1ii1Ii ) ) % 256 )
  iI1I111Ii111i . append ( oooo000 )
 return "" . join ( iI1I111Ii111i )
 if 16 - 16: oO0o0ooO0 + i11iII1iiI - oOo0O0Ooo
def oOoOO0 ( parameters ) :
 IiI11iII1 = { }
 if 29 - 29: iii1II11ii - iiIIIII1i1iI - O0Oooo00 % o0ooo - iiIIIII1i1iI
 if parameters :
  OOO0o = parameters [ 1 : ] . split ( "&" )
  for IiI1 in OOO0o :
   Oo0O00Oo0o0 = IiI1 . split ( '=' )
   if ( len ( Oo0O00Oo0o0 ) ) == 2 :
    IiI11iII1 [ Oo0O00Oo0o0 [ 0 ] ] = Oo0O00Oo0o0 [ 1 ]
 return IiI11iII1
 if 87 - 87: OoOOo * iii1II11ii % i11iIiiIii % iI1Ii11111iIi - oo
O0ooo0O0oo0 = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 91 - 91: OOO0O + I111IiIi
if os . path . exists ( O0ooo0O0oo0 ) == False :
 os . mkdir ( O0ooo0O0oo0 )
i1i = os . path . join ( O0ooo0O0oo0 , 'visitor' )
if 46 - 46: I111IiIi % O0Oooo00 + i11iII1iiI . iI1Ii11111iIi . i11iII1iiI
if os . path . exists ( i1i ) == False :
 from random import randint
 oO00o0 = open ( i1i , "w" )
 oO00o0 . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 oO00o0 . close ( )
 if 55 - 55: iii1II11ii + OOO0O / iI1Ii11111iIi * iiIIIII1i1iI - i11iIiiIii - O0o00
ii1ii1ii = xbmc . translatePath ( "special://userdata" )
ii1ii1ii = xbmc . translatePath ( os . path . join ( ii1ii1ii , "uaip" ) )
if not os . path . exists ( ii1ii1ii ) :
 oooooOoo0ooo = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 I1I1IiI1 = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in oooooOoo0ooo for b in I1I1IiI1 ) :
  III1iII1I1ii = Ii11Ii1I ( ii11i1iIII ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  I11IiI1I11i1i = III1iII1I1ii . replace ( '"' , '' ) . split ( ',' )
  Oo0O0O0ooO0O = oooooOoo0ooo . split ( ";" )
  with open ( ii1ii1ii , "w" ) as oOOo0 :
   oOOo0 . write ( oooooOoo0ooo + ";" + I11IiI1I11i1i [ 0 ] )
  oo00O00oO = { 'entry.436422879' : Oo0O0O0ooO0O [ 0 ] , 'entry.1845442180' : Oo0O0O0ooO0O [ 1 ] , 'entry.972740559' : Oo0O0O0ooO0O [ 2 ] , 'entry.1836504487' : Oo0O0O0ooO0O [ 3 ] , 'entry.1101915442' : I11IiI1I11i1i [ 0 ] , 'entry.1574658585' : I11IiI1I11i1i [ 1 ] , 'entry.1805295152' : I11IiI1I11i1i [ 2 ] , 'entry.512145242' : I11IiI1I11i1i [ 3 ] , 'entry.773640853' : I11IiI1I11i1i [ 4 ] , 'entry.319359888' : I11IiI1I11i1i [ 5 ] , 'entry.122876449' : I11IiI1I11i1i [ 6 ] , 'entry.1791949570' : I11IiI1I11i1i [ 7 ] , 'entry.1970011699' : I11IiI1I11i1i [ 8 ] , 'entry.422390183' : I11IiI1I11i1i [ 9 ] , 'entry.2030601071' : I11IiI1I11i1i [ 10 ] }
  ii1I1i1I = urllib . urlencode ( oo00O00oO )
  OOOO = ii11i1iIII ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  OooOooo = urllib2 . Request ( OOOO , ii1I1i1I )
  OooOooo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  OooOooo . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  OooOooo . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  IiiI11Iiiii = urllib2 . urlopen ( OooOooo )
  if 23 - 23: i11iII1iiI + i11iII1iiI . oo
def ii1ii11IIIiiI ( utm_url ) :
 O00OOOoOoo0O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  OooOooo = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : O00OOOoOoo0O }
 )
  IiiI11Iiiii = urllib2 . urlopen ( OooOooo ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return IiiI11Iiiii
 if 77 - 77: o0ooo % o0ooo * iiIIIII1i1iI - i11iIiiIii
def Oo0oO ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  IIiIi1iI = "1.0"
  i1IiiiI1iI = open ( i1i ) . read ( )
  i1iIi = "HayHayTV"
  ooOOoooooo = "UA-52209804-2"
  II1I = "www.viettv24.com"
  O0 = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   i1II1Iiii1I11 = O0 + "?" + "utmwv=" + IIiIi1iI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1iIi ) + "&utmac=" + ooOOoooooo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , i1IiiiI1iI , "1" , "1" , "2" ] )
   if 9 - 9: oO0o0ooO0 / iii1II11ii - I1ii11iIi11i / II1Ii / OOO0O - ii1II11I1ii1I
   if 91 - 91: o0ooo % Ooo % OOO0O
   if 20 - 20: oo % O0o00 / O0o00 + O0o00
   if 45 - 45: iiIIIII1i1iI - OOO0Ooo0ooO0oOOOOo - II1Ii - i11iII1iiI . oOo0O0Ooo / Oooo
   if 51 - 51: Oooo + o0ooo
  else :
   if group == "None" :
    i1II1Iiii1I11 = O0 + "?" + "utmwv=" + IIiIi1iI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1iIi + "/" + name ) + "&utmac=" + ooOOoooooo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , i1IiiiI1iI , "1" , "1" , "2" ] )
    if 8 - 8: iiIIIII1i1iI * iI1Ii11111iIi - O0o00 - i11iII1iiI * oo % I1ii11iIi11i
    if 48 - 48: Oooo
    if 11 - 11: O0Oooo00 + II1Ii - i11iII1iiI / ii1II11I1ii1I + iii1II11ii . oOo0O0Ooo
    if 41 - 41: O0o00 - Oooo - Oooo
    if 68 - 68: oo % I111IiIi
   else :
    i1II1Iiii1I11 = O0 + "?" + "utmwv=" + IIiIi1iI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1iIi + "/" + group + "/" + name ) + "&utmac=" + ooOOoooooo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , i1IiiiI1iI , "1" , "1" , "2" ] )
    if 88 - 88: OOO0O - OoOOo + oo
    if 40 - 40: I1ii11iIi11i * O0o00 + oo % o0ooo
    if 74 - 74: iiIIIII1i1iI - iii1II11ii + II1Ii + I111IiIi / iI1Ii11111iIi
    if 23 - 23: Oooo
    if 85 - 85: O0o00
    if 84 - 84: I1ii11iIi11i . OOO0O % II1Ii + O0o00 % II1Ii % i11iII1iiI
  print "============================ POSTING ANALYTICS ============================"
  ii1ii11IIIiiI ( i1II1Iiii1I11 )
  if 42 - 42: i11iII1iiI / O0Oooo00 / ii1II11I1ii1I + o0ooo / iI1Ii11111iIi
  if not group == "None" :
   o0OoOO000ooO0 = O0 + "?" + "utmwv=" + IIiIi1iI + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( II1I ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + i1iIi + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( i1iIi ) + "&utmac=" + ooOOoooooo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , i1IiiiI1iI , "1" , "2" ] )
   if 56 - 56: o0ooo
   if 86 - 86: oOo0O0Ooo % I111IiIi
   if 15 - 15: Ooo * I1ii11iIi11i + i11iIiiIii
   if 6 - 6: OoOOo / i11iIiiIii + o0ooo * iiIIIII1i1iI
   if 80 - 80: oOo0O0Ooo
   if 83 - 83: O0Oooo00 . i11iIiiIii + oOo0O0Ooo . ii1II11I1ii1I * O0Oooo00
   if 53 - 53: oOo0O0Ooo
   if 31 - 31: i11iII1iiI
   try :
    print "============================ POSTING TRACK EVENT ============================"
    ii1ii11IIIiiI ( o0OoOO000ooO0 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 80 - 80: I111IiIi . i11iIiiIii - ii1II11I1ii1I
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 25 - 25: i11iII1iiI
oOo0oO = oOoOO0 ( sys . argv [ 2 ] )
OOOO0oo0 = oOo0oO . get ( 'mode' )
Oo0oO0ooo = oOo0oO . get ( 'url' )
I11iiI1i1 = oOo0oO . get ( 'name' )
I1i1Iiiii = oOo0oO . get ( 'requestdata' )
if type ( Oo0oO0ooo ) == type ( str ( ) ) :
 Oo0oO0ooo = urllib . unquote_plus ( Oo0oO0ooo )
if type ( I1i1Iiiii ) == type ( str ( ) ) :
 I1i1Iiiii = urllib . unquote_plus ( I1i1Iiiii )
 if 94 - 94: ii1II11I1ii1I * O0o00 / iii1II11ii / O0o00
oO0 = str ( sys . argv [ 1 ] )
if OOOO0oo0 == 'index' :
 Oo0oO ( "Browse" , I11iiI1i1 )
 I1IiIiiIII ( Oo0oO0ooo , I1i1Iiiii )
elif OOOO0oo0 == 'search' :
 Oo0oO ( "None" , "Search" )
 O00O0O0O0 ( )
elif OOOO0oo0 == 'videosbycategory' :
 Oo0oO ( "Browse" , I11iiI1i1 )
 o0oO0 ( )
elif OOOO0oo0 == 'videosbyregion' :
 Oo0oO ( "Browse" , I11iiI1i1 )
 Ooo0 ( )
elif OOOO0oo0 == 'moviedetail' :
 Oo0oO ( "Browse" , I11iiI1i1 )
 OOoO000O0OO ( Oo0oO0ooo , I1i1Iiiii )
elif OOOO0oo0 == 'playvideo' :
 Oo0oO ( "Play" , I11iiI1i1 + "/" + Oo0oO0ooo )
 O0OO0O = xbmcgui . DialogProgress ( )
 O0OO0O . create ( 'HayHayTV' , 'Loading video. Please wait...' )
 OO = urllib . unquote_plus ( I11iiI1i1 ) . replace ( 'Play [' , '' ) . replace ( ']' , '' )
 if len ( Oo0oO0ooo . split ( 'http' ) ) > 2 :
  I11I11i1I ( 'http' + Oo0oO0ooo . split ( 'http' ) [ 1 ] , 'http' + Oo0oO0ooo . split ( 'http' ) [ 2 ] , OO )
 else :
  I11I11i1I ( 'http' + Oo0oO0ooo . split ( 'http' ) [ 1 ] , '' , OO )
 O0OO0O . close ( )
 del O0OO0O
 if 83 - 83: Oooo / I1ii11iIi11i - i11iII1iiI - oo
else :
 Oo0oO ( "None" , "None" )
 OoO0O00 ( )
xbmcplugin . endOfDirectory ( int ( oO0 ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
