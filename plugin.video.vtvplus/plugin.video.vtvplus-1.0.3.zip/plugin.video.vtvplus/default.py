#!/usr/bin/python
# coding=utf-8
import os , xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , base64 , cookielib
if 64 - 64: i11iIiiIii
OO0o = xbmcaddon . Addon ( id = 'plugin.video.vtvplus' )
Oo0Ooo = int ( sys . argv [ 1 ] )
O0O0OO0O0O0 = xbmc . translatePath ( OO0o . getAddonInfo ( 'profile' ) ) . decode ( "utf-8" )
iiiii = xbmc . translatePath ( os . path . join ( O0O0OO0O0O0 , "cookie.txt" ) )
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( "VTV3HD" , "1" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/VTV3HD.jpg" )
 i1I11i ( "VTV2" , "3" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/VTV2.jpg" )
 i1I11i ( "VTV4" , "4" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/VTV4.jpg" )
 i1I11i ( "2014/05/VTV6HD" , "5" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/05/VTV6HD.png" )
 i1I11i ( "VTV9" , "6" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/VTV9.jpg" )
 i1I11i ( "cab-17" , "7" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/cab-17.jpg" )
 i1I11i ( "SCTV-TheThaoHD" , "8" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV-TheThaoHD.jpg" )
 i1I11i ( "SCTV15" , "10" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV15.jpg" )
 i1I11i ( "Cab16-BongdaHD" , "11" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab16-BongdaHD.jpg" )
 i1I11i ( "TheThaoTVHD" , "12" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/TheThaoTVHD.jpg" )
 i1I11i ( "HTV-Thethao" , "13" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTV-Thethao.jpg" )
 i1I11i ( "Cab15-InvestTV" , "14" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab15-InvestTV.jpg" )
 i1I11i ( "Cab3-TheThaoTVSD" , "15" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab3-TheThaoTVSD.jpg" )
 i1I11i ( "logo_fox_sports" , "16" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/logo_fox_sports.png" )
 i1I11i ( "Cab16-BongdaSD" , "17" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab16-BongdaSD.jpg" )
 i1I11i ( "StarMoviesHD" , "18" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/StarMoviesHD.jpg" )
 i1I11i ( "Cab7-DDramas" , "19" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab7-DDramas.jpg" )
 i1I11i ( "Cab2-PhimViet" , "20" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab2-PhimViet.jpg" )
 i1I11i ( "Cab5-Echannel" , "21" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab5-Echannel.jpg" )
 i1I11i ( "logo_hbo_hd" , "22" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/logo_hbo_hd.png" )
 i1I11i ( "Cab6" , "23" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab6.jpg" )
 i1I11i ( "TodayTV" , "24" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/TodayTV.jpg" )
 i1I11i ( "SCTV9" , "25" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV9.jpg" )
 i1I11i ( "SCTV4" , "26" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV4.jpg" )
 i1I11i ( "SCTV14" , "27" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV14.jpg" )
 i1I11i ( "SCTV17" , "28" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV17.jpg" )
 i1I11i ( "Letsviet" , "29" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Letsviet.png" )
 i1I11i ( "ThuanViet" , "30" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/ThuanViet.jpg" )
 i1I11i ( "YanTV" , "31" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/YanTV.jpg" )
 i1I11i ( "SCTV6" , "32" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV6.jpg" )
 i1I11i ( "SCTV13" , "33" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV13.jpg" )
 i1I11i ( "SCTV3" , "34" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV3.jpg" )
 i1I11i ( "SCTV1" , "35" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV1.png" )
 i1I11i ( "SCTV-HaiHD" , "36" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/SCTV-HaiHD.jpg" )
 i1I11i ( "HTV7" , "37" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTV7.jpg" )
 i1I11i ( "HTV9" , "38" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTV9.jpg" )
 i1I11i ( "HTV3" , "39" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTV3.jpg" )
 i1I11i ( "HTVC-AmNhac" , "40" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTVC-AmNhac.jpg" )
 i1I11i ( "HTVCHD" , "41" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTVCHD.jpg" )
 i1I11i ( "HTV4" , "42" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/HTV4.jpg" )
 i1I11i ( "logoFBNC" , "43" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/logoFBNC.jpg" )
 i1I11i ( "StarworldHD" , "44" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/StarworldHD.jpg" )
 i1I11i ( "CNN" , "45" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/CNN.jpg" )
 i1I11i ( "Natgeo-HD" , "46" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Natgeo-HD.jpg" )
 i1I11i ( "Channel1" , "47" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Channel1.jpg" )
 i1I11i ( "Natgeowild" , "48" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Natgeowild.jpg" )
 i1I11i ( "BBCworld" , "49" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/BBCworld.jpg" )
 i1I11i ( "Natgeo" , "50" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Natgeo.jpg" )
 i1I11i ( "VOV" , "51" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/VOV.jpg" )
 i1I11i ( "ANTV" , "52" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/ANTV.jpg" )
 i1I11i ( "THVL" , "53" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/05/THVL.png" )
 i1I11i ( "TTXVN" , "54" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/TTXVN.jpg" )
 i1I11i ( "MTV" , "55" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/MTV.png" )
 i1I11i ( "GiaitriTV" , "56" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/GiaitriTV.jpg" )
 i1I11i ( "17-yeah1tv" , "57" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/17-yeah1tv.jpg" )
 i1I11i ( "Cab12-StyleTV" , "58" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab12-StyleTV.jpg" )
 i1I11i ( "Cab8-Bibi" , "59" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab8-Bibi.jpg" )
 i1I11i ( "Cab9-INFOTV" , "61" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab9-INFOTV.jpg" )
 i1I11i ( "Cab10-O2TV" , "62" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/Cab10-O2TV.jpg" )
 i1I11i ( "logos_cinemax3" , "74" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/01/logos_cinemax3.png" )
 i1I11i ( "logo_starsports" , "75" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/01/logo_starsports.png" )
 i1I11i ( "VTV1" , "83" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/04/VTV1.jpg" )
 i1I11i ( "VTV3" , "84" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/04/VTV3.jpg" )
 i1I11i ( "VTV6" , "85" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/04/VTV6.jpg" )
 i1I11i ( "BongdaTVHD" , "86" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/04/BongdaTVHD.jpg" )
 i1I11i ( "ThethaoTVHD" , "87" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/04/ThethaoTVHD.jpg" )
 i1I11i ( "VTV3-SD" , "88" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/05/VTV3-SD.png" )
 i1I11i ( "VTV6-SD" , "89" , "playvideo" , "https://api.vtvplus.vn/files/uploads/images/2014/05/VTV6-SD.jpg" )
 try :
  OoOoOO00 = xbmc . translatePath ( OO0o . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
  #OoOoOO00 = xbmc . translatePath ( os . path . join ( OoOoOO00 , "temp.jpg" ) )
  #urllib . urlretrieve ( 'http://echipstore.net/images/vtvplus.jpg' , OoOoOO00 )
  #I11i = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , OoOoOO00 )
  #O0O = xbmcgui . WindowDialog ( )
  #O0O . addControl ( I11i )
  #O0O . doModal ( )
 finally :
  pass
  if 78 - 78: i11ii11iIi11i . oOoO0oo0OOOo + IiiI / Iii1ii1II11i
 iI111iI = xbmc . getSkinDir ( )
 if iI111iI == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
def Oo ( cid , title ) :
 I1Ii11I1Ii1i = urllib2 . urlopen ( 'https://docs.google.com/feeds/download/documents/export/Export?id=1gLFT_b_M22ei_AudXq8i1yHb-kyAThALr_K0uumkz7E&exportFormat=txt' )
 Ooo = I1Ii11I1Ii1i . read ( ) . decode ( 'utf-8-sig' )
 I1Ii11I1Ii1i . close ( )
 o0oOoO00o = "http://www.vtvplus.vn/index.php?option=com_vtv&view=channel&id=" + cid
 i1 = { 'host' : 'www.vtvplus.vn' , 'Accept-Encoding' : 'gzip, deflate' , 'Connection' : 'keep-alive' , 'Cookie' : Ooo }
 oOOoo00O0O = urllib2 . Request ( o0oOoO00o , headers = i1 )
 I1Ii11I1Ii1i = urllib2 . urlopen ( oOOoo00O0O )
 i1111 = I1Ii11I1Ii1i . read ( )
 I1Ii11I1Ii1i . close ( )
 i11 = re . compile ( 'var responseText = "(.+?)";' ) . findall ( i1111 )
 if i11 :
  I11 = xbmcgui . ListItem ( title )
  I11 . setInfo ( 'video' , { 'Title' : title } )
  I11 . setProperty ( "IsPlayable" , "true" )
  I11 . setPath ( i11 [ 0 ] . split ( "," ) [ 0 ] )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I11 )
  if 98 - 98: I1111 * o0o0Oo0oooo0 / I1I1i1 * oO0 / IIIi1i1I
  if 72 - 72: iii11iiII % ii11i / IIIi1i1I + IIIi1i1I % I1i1iI1i
  if 31 - 31: oOoO0oo0OOOo . Oo0ooO0oo0oO + O00oOoOoO0o0O - iii1I1I
  if 22 - 22: o0o0Oo0oooo0 * iIIi1iI1II111 / O0oo0OO0
  if 64 - 64: o0o0Oo0oooo0 % i11ii11iIi11i % oOooOoO0Oo0O
  if 3 - 3: I1I1i1 + iIIi1iI1II111
  if 42 - 42: II / i11ii11iIi11i + i11iIiiIii - o0o0Oo0oooo0
  if 78 - 78: iii1I1I
  if 18 - 18: iIIi1iI1II111 - I1I1i1 / I1I1i1 + iii11iiII % iii11iiII - oO0
  if 62 - 62: I1I1i1 - oO0 - O00oOoOoO0o0O % i11ii11iIi11i / I1i1iI1i
  if 77 - 77: oOoO0oo0OOOo - oOoO0oo0OOOo . IiiI / O0oo0OO0
  if 14 - 14: I1111 % iIIi1iI1II111
  if 41 - 41: i11ii11iIi11i + IIIi1i1I + II - oO0
  if 77 - 77: Iii1ii1II11i . oO0 % iii11iiII
  if 42 - 42: I1i1iI1i - i11ii11iIi11i / i11iIiiIii + II + iii1I1I
  if 17 - 17: I1i1iI1i . Iii1ii1II11i . Oo0ooO0oo0oO
  if 3 - 3: O00oOoOoO0o0O . Iii1ii1II11i . IiiI / o0o0Oo0oooo0
  if 38 - 38: oOoO0oo0OOOo % i11iIiiIii . iii11iiII - II + o0o0Oo0oooo0
  if 66 - 66: oOooOoO0Oo0O * oOooOoO0Oo0O . II . i11ii11iIi11i - II
  if 77 - 77: I1111 - ii11i
  if 82 - 82: i11iIiiIii . II / Iii1ii1II11i * iIIi1iI1II111 % I1i1iI1i % ii11i
  if 78 - 78: ii11i - o0o0Oo0oooo0 * iii1I1I + O0oo0OO0 + I1I1i1 + I1I1i1
  if 11 - 11: I1I1i1 - iii1I1I % iii11iiII % I1I1i1 / O00oOoOoO0o0O - iii1I1I
  if 74 - 74: I1I1i1 * iIIi1iI1II111
def oOOo0oo ( ) :
 o0oo0o0O00OO = xbmcgui . Dialog ( )
 if o0oo0o0O00OO . yesno ( "VTV Plus" , "Bạn cần tài khoản VTV Plus VIP để xem các kênh truyền hình của VTV Plus. Nếu chưa có tài khoản" , "Vui lòng đăng ký và nạp tiền tại" , "www.vtvplus.vn" , "Thoát" , "Đăng nhập" ) :
  Ooo = ""
  o0oO = ""
  if ( os . path . exists ( iiiii ) ) :
   with open ( iiiii , "r" ) as I1i1iii :
    Ooo = I1i1iii . read ( )
   o0oO = Ooo . split ( "vtv_user=" ) [ 1 ] . split ( "; " ) [ 0 ]
  i1iiI11I = xbmc . Keyboard ( o0oO . split ( "-" ) [ 0 ] . replace ( "_aaa_" , "@" ) , 'VTV Plus - Nhập Username' )
  i1iiI11I . doModal ( )
  if i1iiI11I . isConfirmed ( ) :
   iiii = i1iiI11I . getText ( )
  i1iiI11I = xbmc . Keyboard ( urllib . unquote ( o0oO . split ( "-" ) [ 1 ] ) , 'VTV Plus - Nhập Mật khẩu' )
  i1iiI11I . doModal ( )
  if i1iiI11I . isConfirmed ( ) :
   oO0o0O0OOOoo0 = i1iiI11I . getText ( )
  if not IiIiiI ( iiii , oO0o0O0OOOoo0 ) :
   oOOo0oo ( )
   if 31 - 31: o0o0Oo0oooo0 . o0o0Oo0oooo0 - O0oo0OO0 / iii1I1I + iii11iiII * IiiI
def IiIiiI ( username , password ) :
 O0ooOooooO = 'http://www.vtvplus.vn/index.php?option=com_vtv&task=user.login'
 o00O = { 'username' : username , 'password' : password , 'save' : "1" }
 i1 = { 'host' : 'www.vtvplus.vn' , 'Accept-Encoding' : 'gzip, deflate' , 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8' , 'Connection' : 'keep-alive' }
 OOO0OOO00oo = urllib . urlencode ( o00O )
 oOOoo00O0O = urllib2 . Request ( O0ooOooooO , headers = i1 , data = OOO0OOO00oo )
 I1Ii11I1Ii1i = urllib2 . urlopen ( oOOoo00O0O )
 i1111 = I1Ii11I1Ii1i . read ( )
 if "thành công" in i1111 :
  o0oo0o0O00OO = xbmcgui . Dialog ( )
  o0oo0o0O00OO . ok ( "VTV Plus" , "Đăng nhập thành công" , "Vui lòng chọn kênh yêu thích để xem" )
  Iii111II = os . path . dirname ( iiiii )
  if not os . path . exists ( Iii111II ) :
   os . makedirs ( Iii111II )
  with open ( iiiii , "w" ) as I1i1iii :
   I1i1iii . write ( I1Ii11I1Ii1i . headers . get ( "Set-Cookie" ) )
  I1Ii11I1Ii1i . close ( )
  return True
 else :
  I1Ii11I1Ii1i . close ( )
  return False
  if 9 - 9: iii1I1I
def i11O0oo0OO0oOOOo ( url ) :
 oOOoo00O0O = urllib2 . Request ( url )
 i1i1i11IIi = urllib2 . urlopen ( oOOoo00O0O )
 II1III = i1i1i11IIi . read ( )
 i1i1i11IIi . close ( )
 II1III = '' . join ( II1III . splitlines ( ) ) . replace ( '\'' , '"' )
 II1III = II1III . replace ( '\n' , '' )
 II1III = II1III . replace ( '\t' , '' )
 II1III = re . sub ( '  +' , ' ' , II1III )
 II1III = II1III . replace ( '> <' , '><' )
 return II1III
 if 19 - 19: I1i1iI1i % i11ii11iIi11i % O0oo0OO0
def i1I11i ( name , cid , mode , iconimage ) :
 oo0OooOOo0 = sys . argv [ 0 ] + "?cid=" + urllib . quote_plus ( cid ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 o0O = True
 O00oO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O00oO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O00oO . setProperty ( "IsPlayable" , "true" )
 o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oo0OooOOo0 , listitem = O00oO )
 return o0O
 if 39 - 39: oO0 - oOoO0oo0OOOo * iii1I1I % O0oo0OO0 * oOoO0oo0OOOo % oOoO0oo0OOOo
def OoOOOOO ( k , e ) :
 iIi1i111II = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for OoOO00O in range ( len ( e ) ) :
  oOOoO0O0O0 = k [ OoOO00O % len ( k ) ]
  Oo000o = chr ( ( 256 + ord ( e [ OoOO00O ] ) - ord ( oOOoO0O0O0 ) ) % 256 )
  iIi1i111II . append ( Oo000o )
 return "" . join ( iIi1i111II )
 if 7 - 7: iii11iiII * iii1I1I % I1i1iI1i . oO0
def Ii1iIiII1ii1 ( parameters ) :
 ooOooo000oOO = { }
 if 59 - 59: oOoO0oo0OOOo + oOooOoO0Oo0O * O00oOoOoO0o0O + i11ii11iIi11i
 if parameters :
  Oo0OoO00oOO0o = parameters [ 1 : ] . split ( "&" )
  for OOO00O in Oo0OoO00oOO0o :
   OOoOO0oo0ooO = OOO00O . split ( '=' )
   if ( len ( OOoOO0oo0ooO ) ) == 2 :
    ooOooo000oOO [ OOoOO0oo0ooO [ 0 ] ] = OOoOO0oo0ooO [ 1 ]
 return ooOooo000oOO
 if 98 - 98: I1I1i1 * I1I1i1 / I1I1i1 + I1111
ii111111I1iII = xbmc . translatePath ( OO0o . getAddonInfo ( 'profile' ) )
if 68 - 68: I1I1i1 - ii11i * i11iIiiIii / Oo0ooO0oo0oO * IIIi1i1I
if os . path . exists ( ii111111I1iII ) == False :
 os . mkdir ( ii111111I1iII )
i1iIi1iIi1i = os . path . join ( ii111111I1iII , 'visitor' )
if 46 - 46: IIIi1i1I % I1111 + iii1I1I . O00oOoOoO0o0O . iii1I1I
if os . path . exists ( i1iIi1iIi1i ) == False :
 from random import randint
 oO00o0 = open ( i1iIi1iIi1i , "w" )
 oO00o0 . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 oO00o0 . close ( )
 if 55 - 55: Iii1ii1II11i + ii11i / O00oOoOoO0o0O * I1i1iI1i - i11iIiiIii - o0o0Oo0oooo0
ii1ii1ii = xbmc . translatePath ( "special://userdata" )
ii1ii1ii = xbmc . translatePath ( os . path . join ( ii1ii1ii , "uaip" ) )
if not os . path . exists ( ii1ii1ii ) :
 oooooOoo0ooo = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 I1I1IiI1 = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in oooooOoo0ooo for b in I1I1IiI1 ) :
  III1iII1I1ii = i11O0oo0OO0oOOOo ( OoOOOOO ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  OoOO00O = III1iII1I1ii . replace ( '"' , '' ) . split ( ',' )
  oo0OooOOo0 = oooooOoo0ooo . split ( ";" )
  with open ( ii1ii1ii , "w" ) as I1i1iii :
   I1i1iii . write ( oooooOoo0ooo + ";" + OoOO00O [ 0 ] )
  o00O = { 'entry.436422879' : oo0OooOOo0 [ 0 ] , 'entry.1845442180' : oo0OooOOo0 [ 1 ] , 'entry.972740559' : oo0OooOOo0 [ 2 ] , 'entry.1836504487' : oo0OooOOo0 [ 3 ] , 'entry.1101915442' : OoOO00O [ 0 ] , 'entry.1574658585' : OoOO00O [ 1 ] , 'entry.1805295152' : OoOO00O [ 2 ] , 'entry.512145242' : OoOO00O [ 3 ] , 'entry.773640853' : OoOO00O [ 4 ] , 'entry.319359888' : OoOO00O [ 5 ] , 'entry.122876449' : OoOO00O [ 6 ] , 'entry.1791949570' : OoOO00O [ 7 ] , 'entry.1970011699' : OoOO00O [ 8 ] , 'entry.422390183' : OoOO00O [ 9 ] , 'entry.2030601071' : OoOO00O [ 10 ] }
  OOO0OOO00oo = urllib . urlencode ( o00O )
  Ooo = OoOOOOO ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  oOOoo00O0O = urllib2 . Request ( Ooo , OOO0OOO00oo )
  oOOoo00O0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  oOOoo00O0O . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  oOOoo00O0O . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  i1i1i11IIi = urllib2 . urlopen ( oOOoo00O0O )
  if 61 - 61: oOoO0oo0OOOo
def O0OOO ( utm_url ) :
 II11iIiIIIiI = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  oOOoo00O0O = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : II11iIiIIIiI }
 )
  i1i1i11IIi = urllib2 . urlopen ( oOOoo00O0O ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return i1i1i11IIi
 if 67 - 67: IIIi1i1I . I1I1i1 . iIIi1iI1II111
def IIIIiiII111 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  OOoOoo = "1.0"
  oO0000OOo00 = open ( i1iIi1iIi1i ) . read ( )
  iiIi1IIiIi = "VTVPlus"
  oOO00Oo = "UA-52209804-2"
  i1iIIIi1i = "www.viettv24.com"
  iI1iIIiiii = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   i1iI11i1ii11 = iI1iIIiiii + "?" + "utmwv=" + OOoOoo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iiIi1IIiIi ) + "&utmac=" + oOO00Oo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oO0000OOo00 , "1" , "1" , "2" ] )
   if 58 - 58: iii1I1I % i11iIiiIii . I1I1i1 / I1i1iI1i
   if 84 - 84: I1I1i1 . Oo0ooO0oo0oO / Iii1ii1II11i - IiiI / oOooOoO0Oo0O / O0oo0OO0
   if 12 - 12: IiiI * I1I1i1 % i11ii11iIi11i % ii11i
   if 20 - 20: II % o0o0Oo0oooo0 / o0o0Oo0oooo0 + o0o0Oo0oooo0
   if 45 - 45: I1i1iI1i - oO0 - oOooOoO0Oo0O - iii1I1I . oOoO0oo0OOOo / iIIi1iI1II111
  else :
   if group == "None" :
    i1iI11i1ii11 = iI1iIIiiii + "?" + "utmwv=" + OOoOoo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iiIi1IIiIi + "/" + name ) + "&utmac=" + oOO00Oo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oO0000OOo00 , "1" , "1" , "2" ] )
    if 51 - 51: iIIi1iI1II111 + I1I1i1
    if 8 - 8: I1i1iI1i * O00oOoOoO0o0O - o0o0Oo0oooo0 - iii1I1I * II % IiiI
    if 48 - 48: iIIi1iI1II111
    if 11 - 11: I1111 + oOooOoO0Oo0O - iii1I1I / O0oo0OO0 + Iii1ii1II11i . oOoO0oo0OOOo
    if 41 - 41: o0o0Oo0oooo0 - iIIi1iI1II111 - iIIi1iI1II111
   else :
    i1iI11i1ii11 = iI1iIIiiii + "?" + "utmwv=" + OOoOoo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( iiIi1IIiIi + "/" + group + "/" + name ) + "&utmac=" + oOO00Oo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oO0000OOo00 , "1" , "1" , "2" ] )
    if 68 - 68: II % IIIi1i1I
    if 88 - 88: ii11i - iii11iiII + II
    if 40 - 40: IiiI * o0o0Oo0oooo0 + II % I1I1i1
    if 74 - 74: I1i1iI1i - Iii1ii1II11i + oOooOoO0Oo0O + IIIi1i1I / O00oOoOoO0o0O
    if 23 - 23: iIIi1iI1II111
    if 85 - 85: o0o0Oo0oooo0
  print "============================ POSTING ANALYTICS ============================"
  O0OOO ( i1iI11i1ii11 )
  if 84 - 84: IiiI . ii11i % oOooOoO0Oo0O + o0o0Oo0oooo0 % oOooOoO0Oo0O % iii1I1I
  if not group == "None" :
   IIi1 = iI1iIIiiii + "?" + "utmwv=" + OOoOoo + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( i1iIIIi1i ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + iiIi1IIiIi + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( iiIi1IIiIi ) + "&utmac=" + oOO00Oo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , oO0000OOo00 , "1" , "2" ] )
   if 45 - 45: I1I1i1 / I1I1i1 + IIIi1i1I + iii11iiII
   if 47 - 47: O0oo0OO0 + iii11iiII
   if 82 - 82: oOoO0oo0OOOo . oO0 - ii11i - oO0 * oOoO0oo0OOOo
   if 77 - 77: ii11i * iii1I1I
   if 95 - 95: IiiI + i11iIiiIii
   if 6 - 6: iii11iiII / i11iIiiIii + I1I1i1 * I1i1iI1i
   if 80 - 80: oOoO0oo0OOOo
   if 83 - 83: I1111 . i11iIiiIii + oOoO0oo0OOOo . O0oo0OO0 * I1111
   try :
    print "============================ POSTING TRACK EVENT ============================"
    O0OOO ( IIi1 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 53 - 53: oOoO0oo0OOOo
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 31 - 31: iii1I1I
o0OIiII = Ii1iIiII1ii1 ( sys . argv [ 2 ] )
ii1iII1II = o0OIiII . get ( 'mode' )
Iii1I1I11iiI1 = o0OIiII . get ( 'cid' )
I1I1i1I = o0OIiII . get ( 'name' )
ii1I = o0OIiII . get ( 'requestdata' )
if type ( Iii1I1I11iiI1 ) == type ( str ( ) ) :
 Iii1I1I11iiI1 = urllib . unquote_plus ( Iii1I1I11iiI1 )
if type ( ii1I ) == type ( str ( ) ) :
 ii1I = urllib . unquote_plus ( ii1I )
 if 99 - 99: o0o0Oo0oooo0 / Iii1ii1II11i / oO0 % IiiI
i11I1II1I11i = str ( sys . argv [ 1 ] )
if ii1iII1II == 'playvideo' :
 IIIIiiII111 ( "Play" , I1I1i1I + "/" + Iii1I1I11iiI1 )
 OooOoOO0 = xbmcgui . DialogProgress ( )
 OooOoOO0 . create ( 'VTV Plus' , 'Loading stream. Please wait...' )
 iI1i11iII111 = urllib . unquote_plus ( I1I1i1I )
 Oo ( Iii1I1I11iiI1 , iI1i11iII111 )
 OooOoOO0 . close ( )
 del OooOoOO0
 if 15 - 15: i11iIiiIii % o0o0Oo0oooo0 . Iii1ii1II11i + Oo0ooO0oo0oO
else :
 IIIIiiII111 ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( i11I1II1I11i ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
