#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , json
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xomgiaitri.com'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://phim.xixam.com"
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Search' , 'http://www.xom02.com/web/search/%s/1.html' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 i1I11i ( 'Phim Lẻ' , 'http://www.xom02.com/web/list/phim-dien-anh' , 'index' , 'http://echipstore.net/addonicons/Movies.jpg' )
 i1I11i ( 'Phim Bộ' , 'http://www.xom02.com/web/list/phim-bo' , 'index' , 'http://echipstore.net/addonicons/Series.jpg' )
 i1I11i ( 'Phim Bộ theo Quốc Gia' , 'http://www.xom02.com/' , 'videosbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 i1I11i ( 'Phim Lẻ theo Thể Loại' , 'http://www.xom02.com/' , 'videosbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 IiI1ii1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #IiI1ii1 = xbmc . translatePath ( os . path . join ( IiI1ii1 , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/xixam.jpg' , IiI1ii1 )
 #oooOOooo = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiI1ii1 )
 #o0oo0oo0OO00 = xbmcgui . WindowDialog ( )
 #o0oo0oo0OO00 . addControl ( oooOOooo )
 #o0oo0oo0OO00 . doModal ( )
 if 20 - 20: i111iII
def oOOo ( ) :
 i1I11i ( "Hồng Kong" , "http://www.xom02.com/web/category/1/phim-bo-hong-kong.html" , "index" , "" )
 i1I11i ( "Hồng Kong (VNLT)" , "http://www.xom02.com/web/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 i1I11i ( "Hàn Quốc" , "http://www.xom02.com/web/category/4/phim-bo-han-quoc.html" , "index" , "" )
 i1I11i ( "Hàn Quốc (vietsub)" , "http://www.xom02.com/web/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 i1I11i ( "Trung Quốc" , "http://www.xom02.com/web/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 i1I11i ( "Đài Loan" , "http://www.xom02.com/web/category/3/phim-bo-dai-loan.html" , "index" , "" )
 i1I11i ( "Việt Nam" , "http://www.xom02.com/web/category/5/phim-bo-viet-nam.html" , "index" , "" )
 i1I11i ( "Thái Lan" , "http://www.xom02.com/web/category/22/phim-bo-thai-lan.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , "http://www.xom02.com/web/category/7/cac-loai-khac.html" , "index" , "" )
 if 25 - 25: O0 + OoOoOoO0o0OO * Ooo0OO0oOO * Ii * o0o - OOO0o0o
def Ii1iI ( ) :
 i1I11i ( "Hành Động" , "http://www.xom02.com/web/category/8/hanh-dong.html" , "index" , "" )
 i1I11i ( "Tình Cảm" , "http://www.xom02.com/web/category/9/tinh-cam.html" , "index" , "" )
 i1I11i ( "Phim Hài" , "http://www.xom02.com/web/category/10/phim-hai.html" , "index" , "" )
 i1I11i ( "Kinh Dị" , "http://www.xom02.com/web/category/11/kinh-di.html" , "index" , "" )
 i1I11i ( "Kiếm Hiệp" , "http://www.xom02.com/web/category/12/kiem-hiep.html" , "index" , "" )
 i1I11i ( "Việt Nam" , "http://www.xom02.com/web/category/15/viet-nam.html" , "index" , "" )
 i1I11i ( "Hài Kịch" , "http://www.xom02.com/web/category/16/hai-kich.html" , "index" , "" )
 i1I11i ( "Ca Nhạc" , "http://www.xom02.com/web/category/17/ca-nhac.html" , "index" , "" )
 i1I11i ( "Cải Lương" , "http://www.xom02.com/web/category/18/cai-luong.html" , "index" , "" )
 i1I11i ( "Phóng Sự" , "http://www.xom02.com/web/category/19/phong-su.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , "http://www.xom02.com/web/category/20/cac-loai-khac.html" , "index" , "" )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * OOO - i11iIiiIii
def II1Iiii1111i ( url ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 oo = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( i1IIi11111i )
 for IiII1I1i1i1ii , IIIII , I1 in oo :
  i1I11i ( "[B]" + IIIII + "[/B]" , "http://www.xom02.com/web" + IiII1I1i1i1ii , 'mirrors' , I1 )
 O0OoOoo00o = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( i1IIi11111i . replace ( "'" , '"' ) )
 for IiII1I1i1i1ii , iiiI11 in O0OoOoo00o :
  i1I11i ( iiiI11 , IiII1I1i1i1ii . replace ( "./" , "http://www.xom02.com/web/" ) , 'index' , "" )
  if 91 - 91: O0 / oo00oOOo . OoOoOoO0o0OO + Ii
def iI11 ( ) :
 try :
  iII111ii = xbmc . Keyboard ( '' , 'Enter search text' )
  iII111ii . doModal ( )
  if 3 - 3: i11Ii11I1Ii1i + iIIi1iI1II111
  if ( iII111ii . isConfirmed ( ) ) :
   I1Ii = urllib . quote_plus ( iII111ii . getText ( ) )
  II1Iiii1111i ( o0oOo0Ooo0O % I1Ii )
 except : pass
 if 81 - 81: OoOoOoO0o0OO * ooO * o0o - i11Ii11I1Ii1i - O0
def OooO0OO ( url ) :
 iiiIi = IiIIIiI1I1 ( url )
 i1IIi11111i = o000o0o00o0Oo ( iiiIi )
 OoO000 = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( i1IIi11111i )
 for IIiiIiI1 in OoO000 :
  iiIiIIi = [ ]
  if not any ( x in IIiiIiI1 for x in iiIiIIi ) :
   i1I11i ( IIiiIiI1 , iiiIi . encode ( "utf-8" ) , 'episodes' , "" )
   if 65 - 65: i111iII
def ii1I ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 OooO0 = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % urllib2 . unquote ( name ) ) . findall ( i1IIi11111i )
 II11iiii1Ii = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( OooO0 [ 0 ] )
 if ( "episode_bg_2" in OooO0 [ 0 ] ) :
  OO0oOoo = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( OooO0 [ 0 ] )
  O0o0Oo ( "Part - " + OO0oOoo [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , url , 'loadvideo' , '' , name . encode ( "utf-8" ) )
 for Oo00OOOOO , O0O in II11iiii1Ii :
  O0o0Oo ( "Part - " + O0O . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , "http://www.xom02.com/web/" + Oo00OOOOO , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 83 - 83: o0o + oo00oOOo * O0 % OOO + o0o
def IiIIIiI1I1 ( url ) :
 Ii1iIIIi1ii = o000o0o00o0Oo ( url )
 return re . compile ( '(http://www.xom\d+.com/web/watch/\d+/)' ) . findall ( Ii1iIIIi1ii ) [ 0 ]
 if 80 - 80: o0o * i11iIiiIii / OOoO
def I11II1i ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 IIIIIooooooO0oo = ""
 if ( "proxy.link" in i1IIi11111i ) :
  IIiiiiiiIi1I1 = re . compile ( '"proxy.link", "(.+?)"' ) . findall ( i1IIi11111i ) [ 0 ]
  I1IIIii , oOoOooOo0o0 , OOOO = re . compile ( '/photos/(\d+)/albums/(\d+)/(\d+)' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  i1IIi11111i = o000o0o00o0Oo ( "https://picasaweb.google.com/data/feed/api/user/%s/albumid/%s/photoid/%s?alt=json" % ( I1IIIii , oOoOooOo0o0 , OOOO ) )
  OOO00 = json . loads ( i1IIi11111i , encoding = "utf8" )
  IIIIIooooooO0oo = OOO00 [ "feed" ] [ "media$group" ] [ "media$content" ] [ - 1 ] [ "url" ]
 elif "https://redirector.googlevideo.com/" in i1IIi11111i :
  IIIIIooooooO0oo = re . compile ( '"(https://redirector.googlevideo.com/.+?)"' ) . findall ( i1IIi11111i ) [ 0 ]
 elif "stream1.php" in i1IIi11111i :
  IIIIIooooooO0oo = re . compile ( '"(http://www.xomgiaitri.com/stream1.php\?file=.+?)"' ) . findall ( i1IIi11111i ) [ 0 ]
 elif '"file", "' in i1IIi11111i :
  IIIIIooooooO0oo = re . compile ( '"file", "(.+?)"' ) . findall ( i1IIi11111i ) [ 0 ]
 iiiiiIIii = xbmcgui . ListItem ( name )
 iiiiiIIii . setProperty ( "IsPlayable" , "true" )
 iiiiiIIii . setPath ( IIIIIooooooO0oo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiiiIIii )
 if 71 - 71: Ii + OOO0o0o * Ii - OOO * O0
def o000o0o00o0Oo ( url ) :
 Oooo0Ooo000 = urllib2 . Request ( url )
 Oooo0Ooo000 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 Oooo0Ooo000 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 ooii11I = urllib2 . urlopen ( Oooo0Ooo000 )
 i1IIi11111i = ooii11I . read ( )
 ooii11I . close ( )
 i1IIi11111i = '' . join ( i1IIi11111i . splitlines ( ) ) . replace ( '\'' , '"' )
 i1IIi11111i = i1IIi11111i . replace ( '\n' , '' )
 i1IIi11111i = i1IIi11111i . replace ( '\t' , '' )
 i1IIi11111i = re . sub ( '  +' , ' ' , i1IIi11111i )
 i1IIi11111i = i1IIi11111i . replace ( '> <' , '><' )
 return i1IIi11111i
 if 96 - 96: oo00oOOo % OOO0o0o . Ii + oOooOoO0Oo0O * Ooo0OO0oOO - i111iII
def O0o0Oo ( name , url , mode , iconimage , mirrorname ) :
 i11i1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 IIIii1II1II = True
 i1I1iI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1I1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1I1iI . setProperty ( "IsPlayable" , "true" )
 IIIii1II1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i11i1 , listitem = i1I1iI )
 return IIIii1II1II
 if 93 - 93: ii11i % Ooo0OO0oOO * III
def i1I11i ( name , url , mode , iconimage ) :
 i11i1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIIii1II1II = True
 i1I1iI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage . replace ( " " , "%20" ) )
 i1I1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1II1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i11i1 , listitem = i1I1iI , isFolder = True )
 return IIIii1II1II
 if 16 - 16: iIIi1iI1II111 - OOoO * ii11i + i11Ii11I1Ii1i
def Ii11iII1 ( k , e ) :
 Oo0O0O0ooO0O = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for IIIIii in range ( len ( e ) ) :
  O0o0 = k [ IIIIii % len ( k ) ]
  OO00Oo = chr ( ( 256 + ord ( e [ IIIIii ] ) - ord ( O0o0 ) ) % 256 )
  Oo0O0O0ooO0O . append ( OO00Oo )
 return "" . join ( Oo0O0O0ooO0O )
 if 51 - 51: ooO * O0 + o0o + OOO
def o0O0O00 ( parameters ) :
 o000o = { }
 if 7 - 7: ooo0Oo0 * OOO % Ooo0OO0oOO . ooO
 if parameters :
  Ii1iIiII1ii1 = parameters [ 1 : ] . split ( "&" )
  for ooOooo000oOO in Ii1iIiII1ii1 :
   Oo0oOOo = ooOooo000oOO . split ( '=' )
   if ( len ( Oo0oOOo ) ) == 2 :
    o000o [ Oo0oOOo [ 0 ] ] = Oo0oOOo [ 1 ]
 return o000o
 if 58 - 58: oo00oOOo * Ii * OoOoOoO0o0OO / Ii
oO0o0OOOO = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 68 - 68: i11Ii11I1Ii1i - OOoO - Oooo000o - OoOoOoO0o0OO + o0o
if os . path . exists ( oO0o0OOOO ) == False :
 os . mkdir ( oO0o0OOOO )
iiiI1I11i1 = os . path . join ( oO0o0OOOO , 'visitor' )
if 49 - 49: Oooo000o % ooo0Oo0 . ooo0Oo0 . o0o * ooo0Oo0
if os . path . exists ( iiiI1I11i1 ) == False :
 from random import randint
 O0oOO0 = open ( iiiI1I11i1 , "w" )
 O0oOO0 . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 O0oOO0 . close ( )
 if 68 - 68: OOoO % III . ooO . OoOoOoO0o0OO
o0 = xbmc . translatePath ( "special://userdata" )
o0 = xbmc . translatePath ( os . path . join ( o0 , "uaip" ) )
if not os . path . exists ( o0 ) :
 oo0oOo = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 o000O0o = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in oo0oOo for b in o000O0o ) :
  iI1iII1 = o000o0o00o0Oo ( Ii11iII1 ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  IIIIii = iI1iII1 . replace ( '"' , '' ) . split ( ',' )
  i11i1 = oo0oOo . split ( ";" )
  with open ( o0 , "w" ) as oO0OOoo0OO :
   oO0OOoo0OO . write ( oo0oOo + ";" + IIIIii [ 0 ] )
  O0ii1ii1ii = { 'entry.436422879' : i11i1 [ 0 ] , 'entry.1845442180' : i11i1 [ 1 ] , 'entry.972740559' : i11i1 [ 2 ] , 'entry.1836504487' : i11i1 [ 3 ] , 'entry.1101915442' : IIIIii [ 0 ] , 'entry.1574658585' : IIIIii [ 1 ] , 'entry.1805295152' : IIIIii [ 2 ] , 'entry.512145242' : IIIIii [ 3 ] , 'entry.773640853' : IIIIii [ 4 ] , 'entry.319359888' : IIIIii [ 5 ] , 'entry.122876449' : IIIIii [ 6 ] , 'entry.1791949570' : IIIIii [ 7 ] , 'entry.1970011699' : IIIIii [ 8 ] , 'entry.422390183' : IIIIii [ 9 ] , 'entry.2030601071' : IIIIii [ 10 ] }
  OOO00 = urllib . urlencode ( O0ii1ii1ii )
  oooooOoo0ooo = Ii11iII1 ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  Oooo0Ooo000 = urllib2 . Request ( oooooOoo0ooo , OOO00 )
  Oooo0Ooo000 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  Oooo0Ooo000 . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  Oooo0Ooo000 . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  ooii11I = urllib2 . urlopen ( Oooo0Ooo000 )
  if 6 - 6: o0o - OOO0o0o + ii11i - OOoO - i11iIiiIii
def OO0oOO0O ( utm_url ) :
 oO = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  Oooo0Ooo000 = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : oO }
 )
  ooii11I = urllib2 . urlopen ( Oooo0Ooo000 ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return ooii11I
 if 7 - 7: O0 - Oooo000o
def OOo00O0 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  ooOOOoO = "1.0"
  o0oo00 = open ( iiiI1I11i1 ) . read ( )
  OooOO000 = "XomGiaiTri"
  OOoOoo = "UA-52209804-2"
  oO0000OOo00 = "www.viettv24.com"
  iiIi1IIiIi = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   oOO00Oo = iiIi1IIiIi + "?" + "utmwv=" + ooOOOoO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OooOO000 ) + "&utmac=" + OOoOoo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , o0oo00 , "1" , "1" , "2" ] )
   if 6 - 6: Ooo0OO0oOO
   if 68 - 68: i111iII - OOO
   if 28 - 28: OOO . Ii / Ii + OOo . OoOoOoO0o0OO
   if 1 - 1: ii11i / oo00oOOo
   if 33 - 33: o0o
  else :
   if group == "None" :
    oOO00Oo = iiIi1IIiIi + "?" + "utmwv=" + ooOOOoO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OooOO000 + "/" + name ) + "&utmac=" + OOoOoo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , o0oo00 , "1" , "1" , "2" ] )
    if 18 - 18: O0 % i11Ii11I1Ii1i * iIIi1iI1II111
    if 87 - 87: i11iIiiIii
    if 93 - 93: OoOoOoO0o0OO - OOO % i11iIiiIii . i11Ii11I1Ii1i / i11Ii11I1Ii1i - OOoO
    if 9 - 9: OoOoOoO0o0OO / OOo - Oooo000o / oOooOoO0Oo0O / ii11i - O0
    if 91 - 91: i11Ii11I1Ii1i % III % ii11i
   else :
    oOO00Oo = iiIi1IIiIi + "?" + "utmwv=" + ooOOOoO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OooOO000 + "/" + group + "/" + name ) + "&utmac=" + OOoOoo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , o0oo00 , "1" , "1" , "2" ] )
    if 20 - 20: Ii % OOO0o0o / OOO0o0o + OOO0o0o
    if 45 - 45: Ooo0OO0oOO - ooO - oOooOoO0Oo0O - OOO . oo00oOOo / iIIi1iI1II111
    if 51 - 51: iIIi1iI1II111 + i11Ii11I1Ii1i
    if 8 - 8: Ooo0OO0oOO * i111iII - OOO0o0o - OOO * Ii % Oooo000o
    if 48 - 48: iIIi1iI1II111
    if 11 - 11: o0o + oOooOoO0Oo0O - OOO / O0 + OOo . oo00oOOo
  print "============================ POSTING ANALYTICS ============================"
  OO0oOO0O ( oOO00Oo )
  if 41 - 41: OOO0o0o - iIIi1iI1II111 - iIIi1iI1II111
  if not group == "None" :
   oO00OOoO00 = iiIi1IIiIi + "?" + "utmwv=" + ooOOOoO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( oO0000OOo00 ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + OooOO000 + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( OooOO000 ) + "&utmac=" + OOoOoo + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , o0oo00 , "1" , "2" ] )
   if 40 - 40: Oooo000o * OOO0o0o + Ii % i11Ii11I1Ii1i
   if 74 - 74: Ooo0OO0oOO - OOo + oOooOoO0Oo0O + OOoO / i111iII
   if 23 - 23: iIIi1iI1II111
   if 85 - 85: OOO0o0o
   if 84 - 84: Oooo000o . ii11i % oOooOoO0Oo0O + OOO0o0o % oOooOoO0Oo0O % OOO
   if 42 - 42: OOO / o0o / O0 + i11Ii11I1Ii1i / i111iII
   if 84 - 84: ooo0Oo0 * oo00oOOo + OOo
   if 53 - 53: i11Ii11I1Ii1i % oo00oOOo . ooO - ii11i - ooO * oo00oOOo
   try :
    print "============================ POSTING TRACK EVENT ============================"
    OO0oOO0O ( oO00OOoO00 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 77 - 77: ii11i * OOO
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 95 - 95: Oooo000o + i11iIiiIii
I1IiO0oo00o0O = o0O0O00 ( sys . argv [ 2 ] )
i1I1I = I1IiO0oo00o0O . get ( 'mode' )
o0oOo0Ooo0O = I1IiO0oo00o0O . get ( 'url' )
iiI1I = I1IiO0oo00o0O . get ( 'name' )
if type ( o0oOo0Ooo0O ) == type ( str ( ) ) :
 o0oOo0Ooo0O = urllib . unquote_plus ( o0oOo0Ooo0O )
if type ( iiI1I ) == type ( str ( ) ) :
 iiI1I = urllib . unquote_plus ( iiI1I )
 if 12 - 12: i11iIiiIii - III - OOO . III - Ii + iIIi1iI1II111
oO0OOOO0 = str ( sys . argv [ 1 ] )
if i1I1I == 'index' :
 OOo00O0 ( "Browse" , iiI1I )
 II1Iiii1111i ( o0oOo0Ooo0O )
elif i1I1I == 'search' :
 OOo00O0 ( "None" , "Search" )
 iI11 ( )
elif i1I1I == 'videosbyregion' :
 OOo00O0 ( "Browse" , iiI1I )
 oOOo ( )
elif i1I1I == 'videosbycategory' :
 OOo00O0 ( "Browse" , iiI1I )
 Ii1iI ( )
elif i1I1I == 'mirrors' :
 OOo00O0 ( "Browse" , iiI1I )
 OooO0OO ( o0oOo0Ooo0O )
elif i1I1I == 'episodes' :
 OOo00O0 ( "Browse" , iiI1I )
 ii1I ( o0oOo0Ooo0O , iiI1I )
elif i1I1I == 'loadvideo' :
 OOo00O0 ( "Play" , iiI1I + "/" + o0oOo0Ooo0O )
 iI1I11iiI1i = xbmcgui . DialogProgress ( )
 iI1I11iiI1i . create ( 'phim.xixam.com' , 'Loading video. Please wait...' )
 I11II1i ( o0oOo0Ooo0O , iiI1I )
 iI1I11iiI1i . close ( )
 del iI1I11iiI1i
else :
 OOo00O0 ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( oO0OOOO0 ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
