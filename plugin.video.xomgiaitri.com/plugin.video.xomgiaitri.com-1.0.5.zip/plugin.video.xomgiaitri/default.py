#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xomgiaitri.com'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://phim.xixam.com"
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Search' , 'http://www.xom02.com/web/search/%s/1.html' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 i1I11i ( 'Phim Lẻ' , 'http://www.xom02.com/web/list/phim-dien-anh' , 'index' , 'http://echipstore.net/addonicons/Movies.jpg' )
 i1I11i ( 'Phim Bộ' , 'http://www.xom02.com/web/list/phim-bo' , 'index' , 'http://echipstore.net/addonicons/Series.jpg' )
 i1I11i ( 'Phim Bộ theo Quốc Gia' , 'http://www.xom02.com/' , 'videosbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 i1I11i ( 'Phim Lẻ theo Thể Loại' , 'http://www.xom02.com/' , 'videosbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 IiI1ii1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 IiI1ii1 = xbmc . translatePath ( os . path . join ( IiI1ii1 , "temp.jpg" ) )
 urllib . urlretrieve ( 'http://echipstore.net/images/xixam.jpg' , IiI1ii1 )
 oooOOooo = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiI1ii1 )
 o0oo0oo0OO00 = xbmcgui . WindowDialog ( )
 o0oo0oo0OO00 . addControl ( oooOOooo )
 o0oo0oo0OO00 . doModal ( )
 if 20 - 20: i111iII
def oOOo ( ) :
 i1I11i ( "Hồng Kong" , "http://www.xom02.com/web/category/1/phim-bo-hong-kong.html" , "index" , "" )
 i1I11i ( "Hồng Kong (VNLT)" , "http://www.xom02.com/web/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 i1I11i ( "Hàn Quốc" , "http://www.xom02.com/web/category/4/phim-bo-han-quoc.html" , "index" , "" )
 i1I11i ( "Hàn Quốc (vietsub)" , "http://www.xom02.com/web/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 i1I11i ( "Trung Quốc" , "http://www.xom02.com/web/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 i1I11i ( "Đài Loan" , "http://www.xom02.com/web/category/3/phim-bo-dai-loan.html" , "index" , "" )
 i1I11i ( "Việt Nam" , "http://www.xom02.com/web/category/5/phim-bo-viet-nam.html" , "index" , "" )
 i1I11i ( "Thái Lan" , "http://www.xom02.com/web/category/22/phim-bo-thai-lan.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , "http://www.xom02.com/web/category/7/cac-loai-khac.html" , "index" , "" )
 if 25 - 25: O0 + OoOoOoO0o0OO * Ooo0OO0oOO * Ii * o0o - OOO0o0o
def Ii1iI ( ) :
 i1I11i ( "Hành Động" , "http://www.xom02.com/web/category/8/hanh-dong.html" , "index" , "" )
 i1I11i ( "Tình Cảm" , "http://www.xom02.com/web/category/9/tinh-cam.html" , "index" , "" )
 i1I11i ( "Phim Hài" , "http://www.xom02.com/web/category/10/phim-hai.html" , "index" , "" )
 i1I11i ( "Kinh Dị" , "http://www.xom02.com/web/category/11/kinh-di.html" , "index" , "" )
 i1I11i ( "Kiếm Hiệp" , "http://www.xom02.com/web/category/12/kiem-hiep.html" , "index" , "" )
 i1I11i ( "Việt Nam" , "http://www.xom02.com/web/category/15/viet-nam.html" , "index" , "" )
 i1I11i ( "Hài Kịch" , "http://www.xom02.com/web/category/16/hai-kich.html" , "index" , "" )
 i1I11i ( "Ca Nhạc" , "http://www.xom02.com/web/category/17/ca-nhac.html" , "index" , "" )
 i1I11i ( "Cải Lương" , "http://www.xom02.com/web/category/18/cai-luong.html" , "index" , "" )
 i1I11i ( "Phóng Sự" , "http://www.xom02.com/web/category/19/phong-su.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , "http://www.xom02.com/web/category/20/cac-loai-khac.html" , "index" , "" )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * OOO - i11iIiiIii
def II1Iiii1111i ( url ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 oo = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( i1IIi11111i )
 for IiII1I1i1i1ii , IIIII , I1 in oo :
  i1I11i ( "[B]" + IIIII + "[/B]" , "http://www.xom02.com/web" + IiII1I1i1i1ii , 'mirrors' , I1 )
 O0OoOoo00o = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( i1IIi11111i . replace ( "'" , '"' ) )
 for IiII1I1i1i1ii , iiiI11 in O0OoOoo00o :
  i1I11i ( iiiI11 , IiII1I1i1i1ii . replace ( "./" , "http://www.xom02.com/web/" ) , 'index' , "" )
 OOooO = xbmc . getSkinDir ( )
 if 58 - 58: OOO + i111iII / OOO0o0o * oOooOoO0Oo0O
def II111iiii ( ) :
 try :
  II = xbmc . Keyboard ( '' , 'Enter search text' )
  II . doModal ( )
  if 63 - 63: i111iII % III
  if ( II . isConfirmed ( ) ) :
   o0oOo0Ooo0O = urllib . quote_plus ( II . getText ( ) )
  II1Iiii1111i ( OO00O0O0O00Oo % o0oOo0Ooo0O )
 except : pass
 if 25 - 25: O0 % oo00oOOo - oo00oOOo . oo00oOOo
def Ii1 ( url ) :
 oOOoO0 = O0OoO000O0OO ( url )
 i1IIi11111i = o000o0o00o0Oo ( oOOoO0 )
 iiI1IiI = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( i1IIi11111i )
 for IIooOoOoo0O in iiI1IiI :
  OooO0 = [ ]
  if not any ( x in IIooOoOoo0O for x in OooO0 ) :
   i1I11i ( IIooOoOoo0O , oOOoO0 . encode ( "utf-8" ) , 'episodes' , "" )
   if 35 - 35: Ii % OOoO % i11iIiiIii / oOooOoO0Oo0O
def Ii11iI1i ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 Ooo = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % urllib2 . unquote ( name ) ) . findall ( i1IIi11111i )
 O0o0Oo = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( Ooo [ 0 ] )
 if ( "episode_bg_2" in Ooo [ 0 ] ) :
  Oo00OOOOO = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( Ooo [ 0 ] )
  O0O ( "Part - " + Oo00OOOOO [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , url , 'loadvideo' , '' , name . encode ( "utf-8" ) )
 for O00o0OO , I11i1 in O0o0Oo :
  O0O ( "Part - " + I11i1 . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , "http://www.xom02.com/web/" + O00o0OO , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 25 - 25: OOo - ooO . oOooOoO0Oo0O
def O0OoO000O0OO ( url ) :
 I11ii1 = o000o0o00o0Oo ( url )
 return re . compile ( '(http://www.xom\d+\.com/xem/watch/\d+/)' ) . findall ( I11ii1 ) [ 0 ]
 if 9 - 9: OOO0o0o + Ooo0OO0oOO % OOO0o0o + III . Ii
def III1i1i ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 if ( "proxy.link" in i1IIi11111i ) :
  iiI1 = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( i1IIi11111i )
  i1IIi11111i = o000o0o00o0Oo ( iiI1 [ 0 ] )
  if 19 - 19: o0o + ooo0Oo0
 iiI1 = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( i1IIi11111i )
 print iiI1 [ 0 ]
 ooo = xbmcgui . ListItem ( name )
 ooo . setProperty ( "IsPlayable" , "true" )
 ooo . setPath ( iiI1 [ 0 ] )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooo )
 if 18 - 18: O0
def o000o0o00o0Oo ( url ) :
 I1i1I1II = urllib2 . Request ( url )
 I1i1I1II . add_header ( 'Host' , 'phim.xixam.com' )
 I1i1I1II . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 I1i1I1II . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 i1 = urllib2 . urlopen ( I1i1I1II )
 i1IIi11111i = i1 . read ( )
 i1 . close ( )
 i1IIi11111i = '' . join ( i1IIi11111i . splitlines ( ) ) . replace ( '\'' , '"' )
 i1IIi11111i = i1IIi11111i . replace ( '\n' , '' )
 i1IIi11111i = i1IIi11111i . replace ( '\t' , '' )
 i1IIi11111i = re . sub ( '  +' , ' ' , i1IIi11111i )
 i1IIi11111i = i1IIi11111i . replace ( '> <' , '><' )
 return i1IIi11111i
 if 48 - 48: iIIi1iI1II111 + iIIi1iI1II111 - OoOoOoO0o0OO . ooo0Oo0 / ii11i
def O0O ( name , url , mode , iconimage , mirrorname ) :
 OoOOO00oOO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 oOoo = True
 iIii11I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iIii11I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iIii11I . setProperty ( "IsPlayable" , "true" )
 oOoo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOOO00oOO0 , listitem = iIii11I )
 return oOoo
 if 69 - 69: Ooo0OO0oOO % OOoO - O0 + OOoO - iIIi1iI1II111 % oOooOoO0Oo0O
def i1I11i ( name , url , mode , iconimage ) :
 OoOOO00oOO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 oOoo = True
 iIii11I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iIii11I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOOO00oOO0 , listitem = iIii11I , isFolder = True )
 return oOoo
 if 31 - 31: oo00oOOo - Ii . OOoO % i111iII - iIIi1iI1II111
def iii11 ( k , e ) :
 O0oo0OO0oOOOo = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for i1i1i11IIi in range ( len ( e ) ) :
  II1III = k [ i1i1i11IIi % len ( k ) ]
  iI1iI1I1i1I = chr ( ( 256 + ord ( e [ i1i1i11IIi ] ) - ord ( II1III ) ) % 256 )
  O0oo0OO0oOOOo . append ( iI1iI1I1i1I )
 return "" . join ( O0oo0OO0oOOOo )
 if 24 - 24: OoOoOoO0o0OO
def o0Oo0O0Oo00oO ( parameters ) :
 I11i1I1I = { }
 if 83 - 83: OoOoOoO0o0OO / ooo0Oo0
 if parameters :
  iIIIIii1 = parameters [ 1 : ] . split ( "&" )
  for oo000OO00Oo in iIIIIii1 :
   O0OOO0OOoO0O = oo000OO00Oo . split ( '=' )
   if ( len ( O0OOO0OOoO0O ) ) == 2 :
    I11i1I1I [ O0OOO0OOoO0O [ 0 ] ] = O0OOO0OOoO0O [ 1 ]
 return I11i1I1I
 if 70 - 70: ooO * OOo * o0o / OOO0o0o
oO = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 93 - 93: OOO % Ooo0OO0oOO . OOO * OOoO % OOO0o0o . oo00oOOo
if os . path . exists ( oO ) == False :
 os . mkdir ( oO )
iI1ii1Ii = os . path . join ( oO , 'visitor' )
if 92 - 92: i111iII
if os . path . exists ( iI1ii1Ii ) == False :
 from random import randint
 i1OOO = open ( iI1ii1Ii , "w" )
 i1OOO . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 i1OOO . close ( )
 if 59 - 59: oo00oOOo + oOooOoO0Oo0O * i111iII + III
Oo0OoO00oOO0o = xbmc . translatePath ( "special://userdata" )
Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( Oo0OoO00oOO0o , "uaip" ) )
if not os . path . exists ( Oo0OoO00oOO0o ) :
 OOO00O = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 OOoOO0oo0ooO = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in OOO00O for b in OOoOO0oo0ooO ) :
  O0o0O00Oo0o0 = o000o0o00o0Oo ( iii11 ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  i1i1i11IIi = O0o0O00Oo0o0 . replace ( '"' , '' ) . split ( ',' )
  OoOOO00oOO0 = OOO00O . split ( ";" )
  with open ( Oo0OoO00oOO0o , "w" ) as O00O0oOO00O00 :
   O00O0oOO00O00 . write ( OOO00O + ";" + i1i1i11IIi [ 0 ] )
  i1Oo00 = { 'entry.436422879' : OoOOO00oOO0 [ 0 ] , 'entry.1845442180' : OoOOO00oOO0 [ 1 ] , 'entry.972740559' : OoOOO00oOO0 [ 2 ] , 'entry.1836504487' : OoOOO00oOO0 [ 3 ] , 'entry.1101915442' : i1i1i11IIi [ 0 ] , 'entry.1574658585' : i1i1i11IIi [ 1 ] , 'entry.1805295152' : i1i1i11IIi [ 2 ] , 'entry.512145242' : i1i1i11IIi [ 3 ] , 'entry.773640853' : i1i1i11IIi [ 4 ] , 'entry.319359888' : i1i1i11IIi [ 5 ] , 'entry.122876449' : i1i1i11IIi [ 6 ] , 'entry.1791949570' : i1i1i11IIi [ 7 ] , 'entry.1970011699' : i1i1i11IIi [ 8 ] , 'entry.422390183' : i1i1i11IIi [ 9 ] , 'entry.2030601071' : i1i1i11IIi [ 10 ] }
  i1i = urllib . urlencode ( i1Oo00 )
  iiI111I1iIiI = iii11 ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  I1i1I1II = urllib2 . Request ( iiI111I1iIiI , i1i )
  I1i1I1II . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  I1i1I1II . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  I1i1I1II . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  i1 = urllib2 . urlopen ( I1i1I1II )
  if 41 - 41: OOo . ooo0Oo0 + iIIi1iI1II111 * O0 % OOo * OOo
def iIIIIi1iiIi1 ( utm_url ) :
 iii1i1iiiiIi = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  I1i1I1II = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : iii1i1iiiiIi }
 )
  i1 = urllib2 . urlopen ( I1i1I1II ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return i1
 if 2 - 2: Oooo000o / iIIi1iI1II111 / O0 % i111iII % OOO0o0o
def o0o00OO0 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  i1I1ii = "1.0"
  oOOo0 = open ( iI1ii1Ii ) . read ( )
  oo00O00oO = "XomGiaiTri"
  iIiIIIi = "UA-52209804-2"
  ooo00OOOooO = "www.viettv24.com"
  O00OOOoOoo0O = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   O000OOo00oo = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oo00O00oO ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oOOo0 , "1" , "1" , "2" ] )
   if 71 - 71: i11iIiiIii + ooO
   if 57 - 57: Ooo0OO0oOO . o0o . III
   if 42 - 42: o0o + OoOoOoO0o0OO % iIIi1iI1II111
   if 6 - 6: Ooo0OO0oOO
   if 68 - 68: i111iII - OOO
  else :
   if group == "None" :
    O000OOo00oo = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oo00O00oO + "/" + name ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oOOo0 , "1" , "1" , "2" ] )
    if 28 - 28: OOO . Ii / Ii + OOo . OoOoOoO0o0OO
    if 1 - 1: ii11i / oo00oOOo
    if 33 - 33: o0o
    if 18 - 18: O0 % i11Ii11I1Ii1i * iIIi1iI1II111
    if 87 - 87: i11iIiiIii
   else :
    O000OOo00oo = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oo00O00oO + "/" + group + "/" + name ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , oOOo0 , "1" , "1" , "2" ] )
    if 93 - 93: OoOoOoO0o0OO - OOO % i11iIiiIii . i11Ii11I1Ii1i / i11Ii11I1Ii1i - OOoO
    if 9 - 9: OoOoOoO0o0OO / OOo - Oooo000o / oOooOoO0Oo0O / ii11i - O0
    if 91 - 91: i11Ii11I1Ii1i % III % ii11i
    if 20 - 20: Ii % OOO0o0o / OOO0o0o + OOO0o0o
    if 45 - 45: Ooo0OO0oOO - ooO - oOooOoO0Oo0O - OOO . oo00oOOo / iIIi1iI1II111
    if 51 - 51: iIIi1iI1II111 + i11Ii11I1Ii1i
  print "============================ POSTING ANALYTICS ============================"
  iIIIIi1iiIi1 ( O000OOo00oo )
  if 8 - 8: Ooo0OO0oOO * i111iII - OOO0o0o - OOO * Ii % Oooo000o
  if not group == "None" :
   ii = O00OOOoOoo0O + "?" + "utmwv=" + i1I1ii + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( ooo00OOOooO ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + oo00O00oO + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( oo00O00oO ) + "&utmac=" + iIiIIIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , oOOo0 , "1" , "2" ] )
   if 90 - 90: O0 % III / OOO
   if 44 - 44: OOo . OOO / OoOoOoO0o0OO + OOO0o0o
   if 65 - 65: iIIi1iI1II111
   if 68 - 68: Ii % OOoO
   if 88 - 88: ii11i - ooo0Oo0 + Ii
   if 40 - 40: Oooo000o * OOO0o0o + Ii % i11Ii11I1Ii1i
   if 74 - 74: Ooo0OO0oOO - OOo + oOooOoO0Oo0O + OOoO / i111iII
   if 23 - 23: iIIi1iI1II111
   try :
    print "============================ POSTING TRACK EVENT ============================"
    iIIIIi1iiIi1 ( ii )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 85 - 85: OOO0o0o
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 84 - 84: Oooo000o . ii11i % oOooOoO0Oo0O + OOO0o0o % oOooOoO0Oo0O % OOO
IIi1 = o0Oo0O0Oo00oO ( sys . argv [ 2 ] )
I1I1I = IIi1 . get ( 'mode' )
OO00O0O0O00Oo = IIi1 . get ( 'url' )
OoOO000 = IIi1 . get ( 'name' )
if type ( OO00O0O0O00Oo ) == type ( str ( ) ) :
 OO00O0O0O00Oo = urllib . unquote_plus ( OO00O0O0O00Oo )
if type ( OoOO000 ) == type ( str ( ) ) :
 OoOO000 = urllib . unquote_plus ( OoOO000 )
 if 14 - 14: ooO - OoOoOoO0o0OO
Ii1i1iI1iIIi = str ( sys . argv [ 1 ] )
if I1I1I == 'index' :
 o0o00OO0 ( "Browse" , OoOO000 )
 II1Iiii1111i ( OO00O0O0O00Oo )
elif I1I1I == 'search' :
 o0o00OO0 ( "None" , "Search" )
 II111iiii ( )
elif I1I1I == 'videosbyregion' :
 o0o00OO0 ( "Browse" , OoOO000 )
 oOOo ( )
elif I1I1I == 'videosbycategory' :
 o0o00OO0 ( "Browse" , OoOO000 )
 Ii1iI ( )
elif I1I1I == 'mirrors' :
 o0o00OO0 ( "Browse" , OoOO000 )
 Ii1 ( OO00O0O0O00Oo )
elif I1I1I == 'episodes' :
 o0o00OO0 ( "Browse" , OoOO000 )
 Ii11iI1i ( OO00O0O0O00Oo , OoOO000 )
elif I1I1I == 'loadvideo' :
 o0o00OO0 ( "Play" , OoOO000 + "/" + OO00O0O0O00Oo )
 I1Ii = xbmcgui . DialogProgress ( )
 I1Ii . create ( 'phim.xixam.com' , 'Loading video. Please wait...' )
 III1i1i ( OO00O0O0O00Oo , OoOO000 )
 I1Ii . close ( )
 del I1Ii
else :
 o0o00OO0 ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( Ii1i1iI1iIIi ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
