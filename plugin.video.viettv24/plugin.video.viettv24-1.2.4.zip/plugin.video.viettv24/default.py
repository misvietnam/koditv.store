#!/usr/bin/python
#coding=utf-8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , base64 , json
from math import radians , sqrt , sin , cos , atan2
from operator import itemgetter
import xmltodict
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.viettv24'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
iiiii = int ( sys . argv [ 1 ] )
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #i1I11i = xbmc . translatePath ( os . path . join ( i1I11i , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/viettv24.jpg' , i1I11i )
 #OoOoOO00 = xbmcgui . WindowDialog ( )
 #I11i = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , i1I11i )
 #OoOoOO00 . addControl ( I11i )
 #OoOoOO00 . doModal ( )
 if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
 I11iIi1I = IiiIII111iI ( IiII ( "ghjl" , "z9ze3KGXmeDP19jTld7T0dvc4J6bls3b1Jfd29zazdHGztPYzA==" ) )
 if 28 - 28: Ii11111i * iiI1i1
 for i1I1ii1II1iII , oooO0oo0oOOOO in eval ( I11iIi1I ) :
  O0oO ( i1I1ii1II1iII , oooO0oo0oOOOO , 'indexgroup' , i1I11i . replace ( "temp.jpg" , "icon.png" ) )
 o0oO0 = xbmc . getSkinDir ( )
 if o0oO0 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 100 - 100: i11Ii11I1Ii1i
def Ooo ( url ) :
 o0oOoO00o = IiiIII111iI ( url )
 i1oOOoo00O0O = re . compile ( '<name>(.+?)</name>' ) . findall ( o0oOoO00o )
 if len ( i1oOOoo00O0O ) == 1 :
  i1111 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0oOoO00o )
  for i11 in i1111 :
   I11 = ""
   Oo0o0000o0o0 = ""
   oOo0oooo00o = ""
   if "/title" in i11 :
    Oo0o0000o0o0 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11 ) [ 0 ]
   if "/link" in i11 :
    oOo0oooo00o = re . compile ( '<link>(.+?)</link>' ) . findall ( i11 ) [ 0 ]
   if "/thumbnail" in i11 :
    I11 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11 ) [ 0 ]
   oO0o0o0ooO0oO ( i1oOOoo00O0O [ 0 ] + "/" + Oo0o0000o0o0 , oOo0oooo00o , 'play' , I11 )
  o0oO0 = xbmc . getSkinDir ( )
  if o0oO0 == 'skin.xeebo' :
   xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
 else :
  for oo0o0O00 in i1oOOoo00O0O :
   O0oO ( oo0o0O00 , url + "&n=" + oo0o0O00 , 'index' , '' )
   if 68 - 68: o00oo . iI1OoOooOOOO + i11iiII
def I1iiiiI1iII ( url ) :
 IiIi11i = url . split ( "&n=" ) [ 1 ]
 o0oOoO00o = IiiIII111iI ( url )
 iIii1I111I11I = re . compile ( '<channel>(.+?)</channel>' ) . findall ( o0oOoO00o )
 for OO00OooO0OO in iIii1I111I11I :
  if IiIi11i in OO00OooO0OO :
   i1111 = re . compile ( '<item>(.+?)</item>' ) . findall ( OO00OooO0OO )
   for i11 in i1111 :
    I11 = ""
    Oo0o0000o0o0 = ""
    oOo0oooo00o = ""
    if "/title" in i11 :
     Oo0o0000o0o0 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11 ) [ 0 ]
    if "/link" in i11 :
     oOo0oooo00o = re . compile ( '<link>(.+?)</link>' ) . findall ( i11 ) [ 0 ]
    if "/thumbnail" in i11 :
     I11 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11 ) [ 0 ]
    oO0o0o0ooO0oO ( IiIi11i + "/" + Oo0o0000o0o0 , oOo0oooo00o , 'play' , I11 )
 o0oO0 = xbmc . getSkinDir ( )
 if o0oO0 == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 28 - 28: iIii1
def IiII ( k , e ) :
 oOOoO0 = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for O0OoO000O0OO in range ( len ( e ) ) :
  iiI1IiI = k [ O0OoO000O0OO % len ( k ) ]
  II = chr ( ( 256 + ord ( e [ O0OoO000O0OO ] ) - ord ( iiI1IiI ) ) % 256 )
  oOOoO0 . append ( II )
 return "" . join ( oOOoO0 )
 if 57 - 57: ooOoo0O
def OooO0 ( url ) :
 i1I11i = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 i1I11i = xbmc . translatePath ( os . path . join ( i1I11i , "temp.jpg" ) )
 urllib . urlretrieve ( url , i1I11i )
 OoOoOO00 = xbmcgui . WindowDialog ( )
 I11i = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , i1I11i )
 OoOoOO00 . addControl ( I11i )
 OoOoOO00 . doModal ( )
 if 35 - 35: Ooooo0Oo00oO0 % OooO0o0Oo . O00 % iII11i
def O0O00o0OOO0 ( url , title ) :
 if ( "youtube" in url ) :
  Ii1iIIIi1ii = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( url )
  o0oo0o0O00OO = Ii1iIIIi1ii [ 0 ] [ len ( Ii1iIIIi1ii [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  url = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' + o0oo0o0O00OO . replace ( '?' , '' )
  xbmc . executebuiltin ( "xbmc.PlayMedia(" + url + ")" )
 else :
  if ( "50.7.104.132" in url ) :
   o0oO = "http://www.viettv24.com/api/?ip=%s"
   I1i1iii = json . loads ( urllib2 . urlopen ( o0oO % "" ) . read ( ) )
   i1iiI11I = "http://50.7.104.133:1935/loadbalancer?serverInfoXML"
   iiii = xmltodict . parse ( urllib2 . urlopen ( i1iiI11I ) . read ( ) )
   oO0o0O0OOOoo0 = [ ]
   for IiIiiI in iiii [ "LoadBalancerServerInfo" ] [ "LoadBalancerServer" ] :
    if int ( IiIiiI [ "connectCount" ] ) < 300 :
     I1I = json . loads ( urllib2 . urlopen ( o0oO % IiIiiI [ "redirect" ] ) . read ( ) )
     oOO00oOO = OoOo ( int ( I1i1iii [ "latitude" ] ) , int ( I1i1iii [ "longitude" ] ) , int ( I1I [ "latitude" ] ) , int ( I1I [ "longitude" ] ) )
     oO0o0O0OOOoo0 . append ( [ IiIiiI [ "redirect" ] , int ( oOO00oOO ) + int ( IiIiiI [ "connectCount" ] ) ] )
   iI = sorted ( oO0o0O0OOOoo0 , key = itemgetter ( 1 ) ) [ 0 ] [ 0 ]
   url = url . replace ( "50.7.104.132" , iI )
  title = urllib . unquote_plus ( title )
  o00O = xbmc . PlayList ( 1 )
  o00O . clear ( )
  OOO0OOO00oo = xbmcgui . ListItem ( title )
  OOO0OOO00oo . setInfo ( 'video' , { 'Title' : title } )
  Iii111II = xbmc . Player ( )
  o00O . add ( url , OOO0OOO00oo )
  Iii111II . play ( o00O )
  if 9 - 9: Ii11111i
def OoOo ( lat1 , lon1 , lat2 , lon2 ) :
 lat1 = radians ( lat1 )
 lon1 = radians ( lon1 )
 lat2 = radians ( lat2 )
 lon2 = radians ( lon2 )
 if 33 - 33: iII11i . Ooooo0Oo00oO0
 O0oo0OO0oOOOo = lon1 - lon2
 if 35 - 35: OooO0o0Oo % ii1IiI1i
 o0OOoo0OO0OOO = 6372.8
 if 19 - 19: iI1OoOooOOOO % OOooo000oo0 % i11Ii11I1Ii1i
 oo0OooOOo0 = sqrt (
 ( cos ( lat2 ) * sin ( O0oo0OO0oOOOo ) ) ** 2
 + ( cos ( lat1 ) * sin ( lat2 ) - sin ( lat1 ) * cos ( lat2 ) * cos ( O0oo0OO0oOOOo ) ) ** 2
 )
 o0O = sin ( lat1 ) * sin ( lat2 ) + cos ( lat1 ) * cos ( lat2 ) * cos ( O0oo0OO0oOOOo )
 O00oO = atan2 ( oo0OooOOo0 , o0O )
 return o0OOoo0OO0OOO * O00oO
 if 39 - 39: OooO0o0Oo - i1 * Ii11111i % i11Ii11I1Ii1i * i1 % i1
def IiiIII111iI ( url ) :
 oOo0oooo00o = ""
 if os . path . exists ( url ) == True :
  oOo0oooo00o = open ( url ) . read ( )
 else :
  OoOOOOO = urllib2 . Request ( url )
  OoOOOOO . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
  iIi1i111II = urllib2 . urlopen ( OoOOOOO )
  oOo0oooo00o = iIi1i111II . read ( )
  iIi1i111II . close ( )
  if 83 - 83: i11iIiiIii + o00oo - OooO0o0Oo * i11Ii11I1Ii1i + iIii1 + Ii11111i
 if ( "xml" in url ) :
  oOo0oooo00o = IiII ( "umbala" , oOo0oooo00o )
 oOo0oooo00o = '' . join ( oOo0oooo00o . splitlines ( ) ) . replace ( '\'' , '"' )
 oOo0oooo00o = oOo0oooo00o . replace ( '\n' , '' )
 oOo0oooo00o = oOo0oooo00o . replace ( '\t' , '' )
 oOo0oooo00o = re . sub ( '  +' , ' ' , oOo0oooo00o )
 oOo0oooo00o = oOo0oooo00o . replace ( '> <' , '><' )
 return oOo0oooo00o
 if 66 - 66: iiI1i1
def oO0o0o0ooO0oO ( name , url , mode , iconimage ) :
 oO000Oo000 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 i111IiI1I = True
 O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i111IiI1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO000Oo000 , listitem = O0 )
 return i111IiI1I
 if 30 - 30: i11Ii11I1Ii1i . ooOoo0O - oOooOoO0Oo0O
def O0oO ( name , url , mode , iconimage ) :
 oO000Oo000 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 i111IiI1I = True
 O0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i111IiI1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO000Oo000 , listitem = O0 , isFolder = True )
 return i111IiI1I
 if 8 - 8: OOooo000oo0 - ii11i * i1 + i11iIiiIii / O00 % i11iiII
def iIIIi1 ( parameters ) :
 iiII1i1 = { }
 if 66 - 66: i11iiII - iIii1
 if parameters :
  I1i1III = parameters [ 1 : ] . split ( "&" )
  for OO0O0OoOO0 in I1i1III :
   iiiI1I11i1 = OO0O0OoOO0 . split ( '=' )
   if ( len ( iiiI1I11i1 ) ) == 2 :
    iiII1i1 [ iiiI1I11i1 [ 0 ] ] = iiiI1I11i1 [ 1 ]
 return iiII1i1
 if 49 - 49: ii1IiI1i % iII11i . iII11i . iIii1 * iII11i
if os . path . exists ( O0O0OO0O0O0 ) == False :
 os . mkdir ( O0O0OO0O0O0 )
O0oOO0 = os . path . join ( O0O0OO0O0O0 , 'visitor' )
if 68 - 68: O00 % OOooo000oo0 . OooO0o0Oo . o00oo
if os . path . exists ( O0oOO0 ) == False :
 from random import randint
 o0 = open ( O0oOO0 , "w" )
 o0 . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 o0 . close ( )
 if 91 - 91: ii11i + O00
i1i = xbmc . translatePath ( "special://userdata" )
i1i = xbmc . translatePath ( os . path . join ( i1i , "uaip" ) )
if not os . path . exists ( i1i ) :
 I1I1iIiII1 = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 i11i1I1 = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in I1I1iIiII1 for b in i11i1I1 ) :
  ii1I = IiiIII111iI ( IiII ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  O0OoO000O0OO = ii1I . replace ( '"' , '' ) . split ( ',' )
  oO000Oo000 = I1I1iIiII1 . split ( ";" )
  with open ( i1i , "w" ) as Oo0ooOo0o :
   Oo0ooOo0o . write ( I1I1iIiII1 + ";" + O0OoO000O0OO [ 0 ] )
  Ii1i1 = { 'entry.436422879' : oO000Oo000 [ 0 ] , 'entry.1845442180' : oO000Oo000 [ 1 ] , 'entry.972740559' : oO000Oo000 [ 2 ] , 'entry.1836504487' : oO000Oo000 [ 3 ] , 'entry.1101915442' : O0OoO000O0OO [ 0 ] , 'entry.1574658585' : O0OoO000O0OO [ 1 ] , 'entry.1805295152' : O0OoO000O0OO [ 2 ] , 'entry.512145242' : O0OoO000O0OO [ 3 ] , 'entry.773640853' : O0OoO000O0OO [ 4 ] , 'entry.319359888' : O0OoO000O0OO [ 5 ] , 'entry.122876449' : O0OoO000O0OO [ 6 ] , 'entry.1791949570' : O0OoO000O0OO [ 7 ] , 'entry.1970011699' : O0OoO000O0OO [ 8 ] , 'entry.422390183' : O0OoO000O0OO [ 9 ] , 'entry.2030601071' : O0OoO000O0OO [ 10 ] }
  iiIii = urllib . urlencode ( Ii1i1 )
  O00oO = IiII ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  OoOOOOO = urllib2 . Request ( O00oO , iiIii )
  OoOOOOO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  OoOOOOO . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  OoOOOOO . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  iIi1i111II = urllib2 . urlopen ( OoOOOOO )
  if 79 - 79: oOooOoO0Oo0O / iIIi1iI1II111
def OO0OoO0o00 ( utm_url ) :
 ooOO0O0ooOooO = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  OoOOOOO = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : ooOO0O0ooOooO }
 )
  iIi1i111II = urllib2 . urlopen ( OoOOOOO ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return iIi1i111II
 if 55 - 55: i11Ii11I1Ii1i * iiI1i1
def o0O00oOoOO ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  iIIi1i1 = "4.2.8"
  i1IIIiiII1 = open ( O0oOO0 ) . read ( )
  OOOOoOoo0O0O0 = "VietTV24"
  OOOo00oo0oO = "UA-52209804-2"
  IIiIi1iI = "www.viettv24.com"
  i1IiiiI1iI = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   i1iIi = i1IiiiI1iI + "?" + "utmwv=" + iIIi1i1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OOOOoOoo0O0O0 ) + "&utmac=" + OOOo00oo0oO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , i1IIIiiII1 , "1" , "1" , "2" ] )
   if 68 - 68: i11iIiiIii % o00oo + i11iIiiIii
   if 31 - 31: i1 . ii1IiI1i
   if 1 - 1: IIIiiIIii / i11Ii11I1Ii1i % Ooooo0Oo00oO0 * OooO0o0Oo . i11iIiiIii
   if 2 - 2: o00oo * iIii1 - ii11i + ii1IiI1i . iI1OoOooOOOO % Ooooo0Oo00oO0
   if 92 - 92: Ooooo0Oo00oO0
  else :
   if group == "None" :
    i1iIi = i1IiiiI1iI + "?" + "utmwv=" + iIIi1i1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OOOOoOoo0O0O0 + "/" + name ) + "&utmac=" + OOOo00oo0oO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , i1IIIiiII1 , "1" , "1" , "2" ] )
    if 25 - 25: IIIiiIIii - ii1IiI1i / oOooOoO0Oo0O / i11Ii11I1Ii1i
    if 12 - 12: ii1IiI1i * Ooooo0Oo00oO0 % OOooo000oo0 % ii11i
    if 20 - 20: i11iiII % ooOoo0O / ooOoo0O + ooOoo0O
    if 45 - 45: iI1OoOooOOOO - OooO0o0Oo - oOooOoO0Oo0O - Ii11111i . i1 / iIIi1iI1II111
    if 51 - 51: iIIi1iI1II111 + Ooooo0Oo00oO0
   else :
    i1iIi = i1IiiiI1iI + "?" + "utmwv=" + iIIi1i1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OOOOoOoo0O0O0 + "/" + group + "/" + name ) + "&utmac=" + OOOo00oo0oO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , i1IIIiiII1 , "1" , "1" , "2" ] )
    if 8 - 8: iI1OoOooOOOO * iiI1i1 - ooOoo0O - Ii11111i * i11iiII % ii1IiI1i
    if 48 - 48: iIIi1iI1II111
    if 11 - 11: iIii1 + oOooOoO0Oo0O - Ii11111i / i11Ii11I1Ii1i + IIIiiIIii . i1
    if 41 - 41: ooOoo0O - iIIi1iI1II111 - iIIi1iI1II111
    if 68 - 68: i11iiII % O00
    if 88 - 88: ii11i - iII11i + i11iiII
  print "============================ POSTING ANALYTICS ============================"
  OO0OoO0o00 ( i1iIi )
  if 40 - 40: ii1IiI1i * ooOoo0O + i11iiII % Ooooo0Oo00oO0
  if not group == "None" :
   OOOOOoo0 = i1IiiiI1iI + "?" + "utmwv=" + iIIi1i1 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( IIiIi1iI ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + OOOOoOoo0O0O0 + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( OOOOoOoo0O0O0 ) + "&utmac=" + OOOo00oo0oO + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , i1IIIiiII1 , "1" , "2" ] )
   if 49 - 49: iIIi1iI1II111 . Ooooo0Oo00oO0
   if 11 - 11: OooO0o0Oo * ii1IiI1i . ii11i % oOooOoO0Oo0O + Ooooo0Oo00oO0
   if 78 - 78: Ii11111i . i11iiII + Ii11111i / iIii1 / Ii11111i
   if 54 - 54: iiI1i1 % Ooooo0Oo00oO0
   if 37 - 37: iiI1i1 * IIIiiIIii / iII11i - Ooooo0Oo00oO0 % i1 . iI1OoOooOOOO
   if 88 - 88: Ooooo0Oo00oO0 . i1 * i1 % O00
   if 15 - 15: OOooo000oo0 * ii1IiI1i + i11iIiiIii
   if 6 - 6: iII11i / i11iIiiIii + Ooooo0Oo00oO0 * iI1OoOooOOOO
   try :
    print "============================ POSTING TRACK EVENT ============================"
    OO0OoO0o00 ( OOOOOoo0 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 80 - 80: i1
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 83 - 83: iIii1 . i11iIiiIii + i1 . i11Ii11I1Ii1i * iIii1
oooO0 = iIIIi1 ( sys . argv [ 2 ] )
iIiIiiIIiIIi = oooO0 . get ( 'mode' )
oO0OOOO0 = oooO0 . get ( 'url' )
oo0o0O00 = oooO0 . get ( 'name' )
if type ( oO0OOOO0 ) == type ( str ( ) ) :
 oO0OOOO0 = urllib . unquote_plus ( oO0OOOO0 )
if type ( oo0o0O00 ) == type ( str ( ) ) :
 oo0o0O00 = urllib . unquote_plus ( oo0o0O00 )
 if 26 - 26: ooOoo0O
I11iiI1i1 = str ( sys . argv [ 1 ] )
if iIiIiiIIiIIi == 'index' :
 o0O00oOoOO ( "Browse" , oo0o0O00 )
 I1iiiiI1iII ( oO0OOOO0 )
elif iIiIiiIIiIIi == 'indexgroup' :
 o0O00oOoOO ( "Browse" , oo0o0O00 )
 Ooo ( oO0OOOO0 )
elif iIiIiiIIiIIi == 'play' :
 o0O00oOoOO ( "Play" , oo0o0O00 + "/" + oO0OOOO0 )
 if ( oO0OOOO0 . find ( ".jpg" ) > 0 ) :
  OooO0 ( oO0OOOO0 )
 else :
  I1i1Iiiii = xbmcgui . DialogProgress ( )
  I1i1Iiiii . create ( 'Brought to you by VietTV24.com' , 'Loading video. Please wait...' )
  O0O00o0OOO0 ( oO0OOOO0 , oo0o0O00 )
  I1i1Iiiii . close ( )
  del I1i1Iiiii
else :
 o0O00oOoOO ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( I11iiI1i1 ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
