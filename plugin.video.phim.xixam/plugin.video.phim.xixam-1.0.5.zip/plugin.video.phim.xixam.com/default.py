#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , urlresolver , os , zlib , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.phim.xixam.com'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://phim.xixam.com"
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Search' , 'http://phim.xixam.com/tim-kiem/?tk=' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 i1I11i ( 'Movies' , 'http://phim.xixam.com/phim-le/' , 'index' , 'http://echipstore.net/addonicons/Movies.jpg' )
 i1I11i ( 'Series' , 'http://phim.xixam.com/phim-bo/' , 'index' , 'http://echipstore.net/addonicons/Series.jpg' )
 i1I11i ( 'By Region' , 'http://phim.xixam.com/' , 'videosbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 i1I11i ( 'Movies By Category ' , 'http://phim.xixam.com/' , 'videosbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 i1I11i ( 'Others ' , 'http://phim.xixam.com/phim-khac/' , 'index' , 'http://echipstore.net/addonicons/Categories.jpg' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 IiI1ii1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #IiI1ii1 = xbmc . translatePath ( os . path . join ( IiI1ii1 , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/xixam.jpg' , IiI1ii1 )
 #oooOOooo = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiI1ii1 )
 #o0oo0oo0OO00 = xbmcgui . WindowDialog ( )
 #o0oo0oo0OO00 . addControl ( oooOOooo )
 #o0oo0oo0OO00 . doModal ( )
 if 20 - 20: i111iII
def oOOo ( ) :
 i1I11i ( 'Vietnam' , 'http://phim.xixam.com/country/vietnam-9/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Korea' , 'http://phim.xixam.com/country/korea-1/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'China' , 'http://phim.xixam.com/country/china-5/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Hong Kong' , 'http://phim.xixam.com/country/hong-kong-18/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Japan' , 'http://phim.xixam.com/country/japan-11/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Taiwan' , 'http://phim.xixam.com/country/taiwan-2/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Singapore' , 'http://phim.xixam.com/country/singapore-17/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Philippines' , 'http://phim.xixam.com/country/philippines-4/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Thailand' , 'http://phim.xixam.com/country/thailand-3/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'UK' , 'http://phim.xixam.com/country/united-kingdom-52/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'US' , 'http://phim.xixam.com/country/united-states-10/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 if 25 - 25: O0 + OoOoOoO0o0OO * Ooo0OO0oOO * Ii * o0o - OOO0o0o
def Ii1iI ( ) :
 i1I11i ( 'Action' , 'http://phim.xixam.com/phim-hanh-dong/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Martial Arts' , 'http://phim.xixam.com/phim-kiem-hiep/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Comedy' , 'http://phim.xixam.com/phim-hai/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Adventure' , 'http://phim.xixam.com/phim-phieu-luu/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Horror' , 'http://phim.xixam.com/phim-kinh-di/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Romance' , 'http://phim.xixam.com/phim-tinh-cam/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Animation' , 'http://phim.xixam.com/phim-hoat-hinh/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Fiction' , 'http://phim.xixam.com/phim-vien-tuong/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Psychological' , 'http://phim.xixam.com/phim-tam-ly/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Comedy (Vietnamesse only)' , 'http://phim.xixam.com/hai-kich/11/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'War/Combat' , 'http://phim.xixam.com/phim-chien-tranh/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Sports' , 'http://phim.xixam.com/the-thao/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'TV Shows' , 'http://phim.xixam.com/talkshow-tivi-show/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 i1I11i ( 'Adult Only (18+)' , 'http://phim.xixam.com/phim-18/' , 'index' , 'http://phim.xixam.com/images/logo.png' )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * OOO - i11iIiiIii
def II1Iiii1111i ( url ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 oo = re . compile ( '<div class="rowProduct">(.+?)<div class="fr_page_links">' ) . findall ( i1IIi11111i )
 IiII1I1i1i1ii = re . compile ( '<a href="(.+?)" class="img" title="(.+?)"><img src="(.+?)" [^>]*/>(.+?)<span class="tap">(.*?)</span>' ) . findall ( oo [ 0 ] )
 for IIIII , I1 , O0OoOoo00o , iiiI11 , OOooO in IiII1I1i1i1ii :
  if ( O0OoOoo00o . find ( "http://" ) == - 1 ) :
   O0OoOoo00o = iiiii + O0OoOoo00o . replace ( "/ " , "/" )
  if ( OOooO . find ( "HD" ) != - 1 ) :
   OOooO = "[B][COLOR yellow]" + OOooO + "[/COLOR][/B]"
  i1I11i ( "[B]" + I1 + "[/B] (" + OOooO + ")" , IIIII , 'mirrors' , O0OoOoo00o )
 OOoO00o = re . compile ( '<div class="fr_page_links">(.+?)</div>' ) . findall ( i1IIi11111i )
 II111iiii = re . compile ( '<a href="(.+?)" [^>]*>(.+?)</a>' ) . findall ( OOoO00o [ 0 ] )
 for IIIII , II in II111iiii :
  i1I11i ( II , iiiii + IIIII , 'index' , "" )
 oOoOo00oOo = xbmc . getSkinDir ( )
 if oOoOo00oOo == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(52)' )
  if 96 - 96: III . i111iII * Ii % ooo0Oo0
def OO0O0O00OooO ( ) :
 try :
  OoooooOoo = xbmc . Keyboard ( '' , 'Enter search text' )
  OoooooOoo . doModal ( )
  if 70 - 70: OOO . OOO - OOO / OoOoOoO0o0OO * Ii
  if ( OoooooOoo . isConfirmed ( ) ) :
   OoO000 = urllib . quote_plus ( OoooooOoo . getText ( ) )
  IIiiIiI1 = 'http://phim.xixam.com/tim-kiem/?tk=' + OoO000
  II1Iiii1111i ( IIiiIiI1 )
 except : pass
 if 41 - 41: i111iII
def IIooOoOoo0O ( url ) :
 OooO0 = II11iiii1Ii ( url )
 if OooO0 . find ( "html" ) != - 1 :
  i1IIi11111i = o000o0o00o0Oo ( OooO0 )
  OO0oOoo = re . compile ( '<div class="serverlist"><span>(.+?)</span>' ) . findall ( i1IIi11111i )
  for O0o0Oo in OO0oOoo :
   Oo00OOOOO = [ 'Zing' , 'Download' ]
   if not any ( x in O0o0Oo for x in Oo00OOOOO ) :
    i1I11i ( O0o0Oo , OooO0 . encode ( "utf-8" ) , 'episodes' , "" )
    if 85 - 85: ooo0Oo0 . i11Ii11I1Ii1i - OOO % ooo0Oo0 % oo00oOOo
def OO0o00o ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 oOOo0oo = re . compile ( '<div class="serverlist"><span>' + urllib2 . unquote ( name ) + '</span>(.*?)</div>' ) . findall ( i1IIi11111i )
 o0oo0o0O00OO = re . compile ( '<a [^>]*href="(.+?)">(.+?)</a>' ) . findall ( oOOo0oo [ 0 ] )
 for o0oO , I1i1iii in o0oo0o0O00OO :
  i1iiI11I ( "Part - " + I1i1iii . strip ( ) . encode ( "utf-8" ) , iiiii + "/m/" + o0oO , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 29 - 29: oOooOoO0Oo0O
def II11iiii1Ii ( url ) :
 url = url . split ( "/" ) [ 2 ] . replace ( ".html" , "-1-1.html" )
 return iiiii + "/m/xem-online/" + url
 if 23 - 23: O0 . oo00oOOo
def Oo0O0OOOoo ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 oo = re . compile ( '<source src="(.+?)" [^>]*/>' ) . findall ( i1IIi11111i )
 print oo
 oOoOooOo0o0 = xbmcgui . ListItem ( name )
 oOoOooOo0o0 . setProperty ( "IsPlayable" , "true" )
 oOoOooOo0o0 . setPath ( oo [ 0 ] )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOoOooOo0o0 )
 if 61 - 61: O0 / OOO + ooo0Oo0 * Ooo0OO0oOO / Ooo0OO0oOO
def o000o0o00o0Oo ( url ) :
 OoOo = urllib2 . Request ( url )
 OoOo . add_header ( 'Host' , 'phim.xixam.com' )
 OoOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 OoOo . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 iI = urllib2 . urlopen ( OoOo )
 i1IIi11111i = iI . read ( )
 iI . close ( )
 i1IIi11111i = '' . join ( i1IIi11111i . splitlines ( ) ) . replace ( '\'' , '"' )
 i1IIi11111i = i1IIi11111i . replace ( '\n' , '' )
 i1IIi11111i = i1IIi11111i . replace ( '\t' , '' )
 i1IIi11111i = re . sub ( '  +' , ' ' , i1IIi11111i )
 i1IIi11111i = i1IIi11111i . replace ( '> <' , '><' )
 return i1IIi11111i
 if 60 - 60: o0o / o0o
def i1iiI11I ( name , url , mode , iconimage , mirrorname ) :
 I1II1III11iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 Oo000 = True
 ooii11I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ooii11I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ooii11I . setProperty ( "IsPlayable" , "true" )
 Oo000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1II1III11iii , listitem = ooii11I )
 return Oo000
 if 96 - 96: oo00oOOo % OOO0o0o . Ii + oOooOoO0Oo0O * Ooo0OO0oOO - i111iII
def i1I11i ( name , url , mode , iconimage ) :
 I1II1III11iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 Oo000 = True
 ooii11I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooii11I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Oo000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1II1III11iii , listitem = ooii11I , isFolder = True )
 return Oo000
 if 10 - 10: Ii / Oooo000o * Ii
def IIIii1II1II ( k , e ) :
 i1I1iI = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for oo0OooOOo0 in range ( len ( e ) ) :
  o0O = k [ oo0OooOOo0 % len ( k ) ]
  O00oO = chr ( ( 256 + ord ( e [ oo0OooOOo0 ] ) - ord ( o0O ) ) % 256 )
  i1I1iI . append ( O00oO )
 return "" . join ( i1I1iI )
 if 39 - 39: ooO - oo00oOOo * OOO % O0 * oo00oOOo % oo00oOOo
def OoOOOOO ( parameters ) :
 iIi1i111II = { }
 if 83 - 83: i11iIiiIii + OoOoOoO0o0OO - ooO * O0 + o0o + OOO
 if parameters :
  o0O0O00 = parameters [ 1 : ] . split ( "&" )
  for o000o in o0O0O00 :
   I11IiI1I11i1i = o000o . split ( '=' )
   if ( len ( I11IiI1I11i1i ) ) == 2 :
    iIi1i111II [ I11IiI1I11i1i [ 0 ] ] = I11IiI1I11i1i [ 1 ]
 return iIi1i111II
 if 38 - 38: O0
Oo0O = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 25 - 25: i111iII . oo00oOOo / i11Ii11I1Ii1i . Ii * OOO . Oooo000o
if os . path . exists ( Oo0O ) == False :
 os . mkdir ( Oo0O )
Oo0oOOo = os . path . join ( Oo0O , 'visitor' )
if 58 - 58: oo00oOOo * Ii * OoOoOoO0o0OO / Ii
if os . path . exists ( Oo0oOOo ) == False :
 from random import randint
 oO0o0OOOO = open ( Oo0oOOo , "w" )
 oO0o0OOOO . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 oO0o0OOOO . close ( )
 if 68 - 68: i11Ii11I1Ii1i - OOoO - Oooo000o - OoOoOoO0o0OO + o0o
iiiI1I11i1 = xbmc . translatePath ( "special://userdata" )
iiiI1I11i1 = xbmc . translatePath ( os . path . join ( iiiI1I11i1 , "uaip" ) )
if not os . path . exists ( iiiI1I11i1 ) :
 IIi1i11111 = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 ooOO00O00oo = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in IIi1i11111 for b in ooOO00O00oo ) :
  I1ii11iI = o000o0o00o0Oo ( IIIii1II1II ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  oo0OooOOo0 = I1ii11iI . replace ( '"' , '' ) . split ( ',' )
  I1II1III11iii = IIi1i11111 . split ( ";" )
  with open ( iiiI1I11i1 , "w" ) as IIi1i :
   IIi1i . write ( IIi1i11111 + ";" + oo0OooOOo0 [ 0 ] )
  I1I1iIiII1 = { 'entry.436422879' : I1II1III11iii [ 0 ] , 'entry.1845442180' : I1II1III11iii [ 1 ] , 'entry.972740559' : I1II1III11iii [ 2 ] , 'entry.1836504487' : I1II1III11iii [ 3 ] , 'entry.1101915442' : oo0OooOOo0 [ 0 ] , 'entry.1574658585' : oo0OooOOo0 [ 1 ] , 'entry.1805295152' : oo0OooOOo0 [ 2 ] , 'entry.512145242' : oo0OooOOo0 [ 3 ] , 'entry.773640853' : oo0OooOOo0 [ 4 ] , 'entry.319359888' : oo0OooOOo0 [ 5 ] , 'entry.122876449' : oo0OooOOo0 [ 6 ] , 'entry.1791949570' : oo0OooOOo0 [ 7 ] , 'entry.1970011699' : oo0OooOOo0 [ 8 ] , 'entry.422390183' : oo0OooOOo0 [ 9 ] , 'entry.2030601071' : oo0OooOOo0 [ 10 ] }
  i11i1I1 = urllib . urlencode ( I1I1iIiII1 )
  ii1I = IIIii1II1II ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  OoOo = urllib2 . Request ( ii1I , i11i1I1 )
  OoOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  OoOo . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  OoOo . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  iI = urllib2 . urlopen ( OoOo )
  if 67 - 67: i11iIiiIii - III % OoOoOoO0o0OO . iIIi1iI1II111
def o0oo ( utm_url ) :
 oooooOoo0ooo = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  OoOo = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : oooooOoo0ooo }
 )
  iI = urllib2 . urlopen ( OoOo ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return iI
 if 6 - 6: o0o - OOO0o0o + ii11i - OOoO - i11iIiiIii
def OO0oOO0O ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  oO = "1.0"
  iIi1IIIi1 = open ( Oo0oOOo ) . read ( )
  O0oOoOOOoOO = "XiXam"
  ii1ii11IIIiiI = "UA-52209804-2"
  O00OOOoOoo0O = "www.viettv24.com"
  O000OOo00oo = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   oo0OOo = O000OOo00oo + "?" + "utmwv=" + oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( O0oOoOOOoOO ) + "&utmac=" + ii1ii11IIIiiI + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iIi1IIIi1 , "1" , "1" , "2" ] )
   if 64 - 64: o0o
   if 22 - 22: OOo + OOO0o0o % OoOoOoO0o0OO
   if 9 - 9: oOooOoO0Oo0O
   if 62 - 62: Ii / OOO + OOO0o0o / OOO . oo00oOOo
   if 68 - 68: i11iIiiIii % OoOoOoO0o0OO + i11iIiiIii
  else :
   if group == "None" :
    oo0OOo = O000OOo00oo + "?" + "utmwv=" + oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( O0oOoOOOoOO + "/" + name ) + "&utmac=" + ii1ii11IIIiiI + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iIi1IIIi1 , "1" , "1" , "2" ] )
    if 31 - 31: oo00oOOo . Oooo000o
    if 1 - 1: OOo / O0 % i11Ii11I1Ii1i * ooO . i11iIiiIii
    if 2 - 2: OoOoOoO0o0OO * o0o - ii11i + Oooo000o . Ooo0OO0oOO % i11Ii11I1Ii1i
    if 92 - 92: i11Ii11I1Ii1i
    if 25 - 25: OOo - Oooo000o / oOooOoO0Oo0O / O0
   else :
    oo0OOo = O000OOo00oo + "?" + "utmwv=" + oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( O0oOoOOOoOO + "/" + group + "/" + name ) + "&utmac=" + ii1ii11IIIiiI + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iIi1IIIi1 , "1" , "1" , "2" ] )
    if 12 - 12: Oooo000o * i11Ii11I1Ii1i % III % ii11i
    if 20 - 20: Ii % OOO0o0o / OOO0o0o + OOO0o0o
    if 45 - 45: Ooo0OO0oOO - ooO - oOooOoO0Oo0O - OOO . oo00oOOo / iIIi1iI1II111
    if 51 - 51: iIIi1iI1II111 + i11Ii11I1Ii1i
    if 8 - 8: Ooo0OO0oOO * i111iII - OOO0o0o - OOO * Ii % Oooo000o
    if 48 - 48: iIIi1iI1II111
  print "============================ POSTING ANALYTICS ============================"
  o0oo ( oo0OOo )
  if 11 - 11: o0o + oOooOoO0Oo0O - OOO / O0 + OOo . oo00oOOo
  if not group == "None" :
   i1Iii1i1I = O000OOo00oo + "?" + "utmwv=" + oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( O00OOOoOoo0O ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + O0oOoOOOoOO + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( O0oOoOOOoOO ) + "&utmac=" + ii1ii11IIIiiI + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , iIi1IIIi1 , "1" , "2" ] )
   if 91 - 91: OoOoOoO0o0OO + Oooo000o . Ii * OoOoOoO0o0OO + Oooo000o * OOo
   if 80 - 80: i11Ii11I1Ii1i % Ii % Ooo0OO0oOO - OOo + OOo
   if 19 - 19: i111iII * III
   if 14 - 14: i11Ii11I1Ii1i
   if 11 - 11: ooO * Oooo000o . ii11i % oOooOoO0Oo0O + i11Ii11I1Ii1i
   if 78 - 78: OOO . Ii + OOO / o0o / OOO
   if 54 - 54: i111iII % i11Ii11I1Ii1i
   if 37 - 37: i111iII * OOo / ooo0Oo0 - i11Ii11I1Ii1i % oo00oOOo . Ooo0OO0oOO
   try :
    print "============================ POSTING TRACK EVENT ============================"
    o0oo ( i1Iii1i1I )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 88 - 88: i11Ii11I1Ii1i . oo00oOOo * oo00oOOo % OOoO
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 15 - 15: III * Oooo000o + i11iIiiIii
I1Ii = OoOOOOO ( sys . argv [ 2 ] )
O0oo00o0O = I1Ii . get ( 'mode' )
IIiiIiI1 = I1Ii . get ( 'url' )
i1I1I = I1Ii . get ( 'name' )
if type ( IIiiIiI1 ) == type ( str ( ) ) :
 IIiiIiI1 = urllib . unquote_plus ( IIiiIiI1 )
if type ( i1I1I ) == type ( str ( ) ) :
 i1I1I = urllib . unquote_plus ( i1I1I )
 if 12 - 12: i11iIiiIii / OOO
o0OIiII = str ( sys . argv [ 1 ] )
if O0oo00o0O == 'index' :
 OO0oOO0O ( "Browse" , i1I1I )
 II1Iiii1111i ( IIiiIiI1 )
elif O0oo00o0O == 'search' :
 OO0oOO0O ( "None" , "Search" )
 OO0O0O00OooO ( )
elif O0oo00o0O == 'videosbyregion' :
 OO0oOO0O ( "Browse" , i1I1I )
 oOOo ( )
elif O0oo00o0O == 'videosbycategory' :
 OO0oOO0O ( "Browse" , i1I1I )
 Ii1iI ( )
elif O0oo00o0O == 'mirrors' :
 OO0oOO0O ( "Browse" , i1I1I )
 IIooOoOoo0O ( IIiiIiI1 )
elif O0oo00o0O == 'episodes' :
 OO0oOO0O ( "Browse" , i1I1I )
 OO0o00o ( IIiiIiI1 , i1I1I )
elif O0oo00o0O == 'loadvideo' :
 OO0oOO0O ( "Play" , i1I1I + "/" + IIiiIiI1 )
 ii1iII1II = xbmcgui . DialogProgress ( )
 ii1iII1II . create ( 'phim.xixam.com' , 'Loading video. Please wait...' )
 Oo0O0OOOoo ( IIiiIiI1 , i1I1I )
 ii1iII1II . close ( )
 del ii1iII1II
else :
 OO0oOO0O ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( o0OIiII ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
