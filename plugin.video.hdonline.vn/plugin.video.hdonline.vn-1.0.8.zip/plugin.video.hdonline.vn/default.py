#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , cookielib
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.hdonline.vn'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
iiiii = xbmc . translatePath ( os . path . join ( iiiii , "icon.png" ) )
ooo0OO = cookielib . LWPCookieJar ( )
II1 = urllib2 . build_opener ( urllib2 . HTTPCookieProcessor ( ooo0OO ) )
if 64 - 64: Oooo % OOO0O / II1Ii / Ooo
def OoO0O00 ( ) :
 IIiIiII11i ( '[B]Tìm kiếm[/B]' , 'http://m.hdonline.vn/tim-kiem/keyword/trang-1.html' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' , '' )
 IIiIiII11i ( '[B]Phim Lẻ[/B]' , 'http://m.hdonline.vn/danh-sach/phim-le/trang-1.html' , 'index' , iiiii , '' )
 IIiIiII11i ( '[B]Phim Bộ[/B]' , 'http://m.hdonline.vn/danh-sach/phim-bo/trang-1.html' , 'index' , iiiii , '' )
 IIiIiII11i ( '[B]Phim Lẻ theo Thể Loại[/B]' , '' , '' , iiiii , '' )
 IIiIiII11i ( '--- Kiếm Hiệp' , 'http://m.hdonline.vn/xem-phim-kiem-hiep/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Hành Động' , 'http://m.hdonline.vn/xem-phim-hanh-dong/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phiêu Lưu' , 'http://m.hdonline.vn/xem-phim-phieu-luu/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Kinh Dị' , 'http://m.hdonline.vn/xem-phim-kinh-di/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Tình Cảm' , 'http://m.hdonline.vn/xem-phim-tinh-cam/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Hoạt Hình' , 'http://m.hdonline.vn/xem-phim-hoat-hinh/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Võ Thuật' , 'http://m.hdonline.vn/xem-phim-vo-thuat/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Hài Hước' , 'http://m.hdonline.vn/xem-phim-hai-huoc/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Tâm Lý' , 'http://m.hdonline.vn/xem-phim-tam-ly/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Viễn Tưởng' , 'http://m.hdonline.vn/xem-phim-vien-tuong/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Thần Thoại' , 'http://m.hdonline.vn/xem-phim-than-thoai/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Chiến Tranh' , 'http://m.hdonline.vn/xem-phim-chien-tranh/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Cổ Trang' , 'http://m.hdonline.vn/xem-phim-da-su-co-trang/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Âm Nhạc' , 'http://m.hdonline.vn/xem-phim-the-thao-am-nhac/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Hình Sự' , 'http://m.hdonline.vn/xem-phim-hinh-su/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- TV Show' , 'http://m.hdonline.vn/xem-phim-tv-show/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Khoa Học' , 'http://m.hdonline.vn/xem-phim-khoa-hoc/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Gia Đình' , 'http://m.hdonline.vn/xem-phim-gia-dinh/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Thể Thao' , 'http://m.hdonline.vn/xem-phim-the-thao/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '[B]Phim Bộ theo Quốc Gia[/B]' , '' , '' , iiiii , '' )
 IIiIiII11i ( '--- Phim Việt Nam' , 'http://m.hdonline.vn/phim-bo-viet-nam_1/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Trung Quốc' , 'http://m.hdonline.vn/phim-bo-trung-quoc_2/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Hàn Quốc' , 'http://m.hdonline.vn/phim-bo-han-quoc_3/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Đài Loan' , 'http://m.hdonline.vn/phim-bo-dai-loan_1/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Mỹ' , 'http://m.hdonline.vn/phim-bo-my_5/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Châu Âu' , 'http://m.hdonline.vn/phim-bo-chau-au_6/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Nhật Bản' , 'http://m.hdonline.vn/phim-bo-nhat-ban_7/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Hồng Kông' , 'http://m.hdonline.vn/phim-bo-hong-kong_8/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Thái Lan' , 'http://m.hdonline.vn/phim-bo-thai-lan_9/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Châu Á' , 'http://m.hdonline.vn/phim-bo-chau-a_10/trang-1.html' , 'index' , '' , '' )
 if 51 - 51: oOo0O0Ooo * I1ii11iIi11i
 IIiIiII11i ( '--- Phim Pháp' , 'http://m.hdonline.vn/phim-bo-phap_12/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Anh' , 'http://m.hdonline.vn/phim-bo-anh_13/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Cananda' , 'http://m.hdonline.vn/phim-bo-canada_14/trang-1.html' , 'index' , '' , '' )
 IIiIiII11i ( '--- Phim Đức' , 'http://m.hdonline.vn/phim-bo-duc_15/trang-1.html' , 'index' , '' , '' )
 if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
 IIiIiII11i ( '--- Phim Nga' , 'http://m.hdonline.vn/phim-bo-nga_17/trang-1.html' , 'index' , '' , '' )
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 #O0oOO0o0 = xbmc . translatePath ( os . path . join ( O0oOO0o0 , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://echipstore.net/images/hdonline.jpg' , O0oOO0o0 )
 #i1ii1iIII = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , O0oOO0o0 )
 #Oo0oO0oo0oO00 = xbmcgui . WindowDialog ( )
 #Oo0oO0oo0oO00 . addControl ( i1ii1iIII )
 #Oo0oO0oo0oO00 . doModal ( )
 if 8 - 8: OOo00O0Oo0oO / ooO
 IiIiI11iIi = xbmc . getSkinDir ( )
 if IiIiI11iIi == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 1 - 1: IIii11I1 - i1111 - Ooo / o00O0oo . ooO
def I11 ( url ) :
 Oo0o0000o0o0 = oOo0oooo00o ( url )
 oO0o0o0ooO0oO = re . compile ( '<div class="content-items"><a href="(.+?)"[^>]*><img src="(.+?)"[^>]*><h3>(.+?)</h3>.+?<p>(.+?)</p>' ) . findall ( Oo0o0000o0o0 )
 for oo0o0O00 , oO , i1iiIIiiI111 , oooOOOOO in oO0o0o0ooO0oO :
  IIiIiII11i ( i1iiIIiiI111 , oo0o0O00 , 'episodes' , oO , oooOOOOO )
 if ( len ( oO0o0o0ooO0oO ) == 15 ) :
  i1iiIII111ii = int ( re . compile ( 'trang-(\d+).html' ) . findall ( url ) [ 0 ] )
  url = url . replace ( "trang-" + str ( i1iiIII111ii ) + ".html" , "trang-" + str ( i1iiIII111ii + 1 ) + ".html" )
  IIiIiII11i ( 'Next >>' , url , 'index' , '' , '' )
 IiIiI11iIi = xbmc . getSkinDir ( )
 if IiIiI11iIi == 'skin.xeebo' :
  xbmc . executebuiltin ( 'Container.SetViewMode(51)' )
  if 3 - 3: OOo00O0Oo0oO + Oooo
def I1Ii ( url ) :
 Oo0o0000o0o0 = oOo0oooo00o ( url )
 oO0o0o0ooO0oO = re . compile ( o0oOo0Ooo0O ( "3" , "b6ifU5aflKamcFWmp6WYlKBgnKeYoKZVcVthXnJcb2Kon3E=" ) ) . findall ( Oo0o0000o0o0 )
 oO0o0o0ooO0oO = re . compile ( o0oOo0Ooo0O ( "1" , "bZJRmaOWl25TWV9ccFpTjI9vjltvbaShkp9vWV9ccFptYKShkp9vbWCSbw==" ) ) . findall ( oO0o0o0ooO0oO [ 0 ] )
 if len ( oO0o0o0ooO0oO ) > 0 :
  for OO00O0O0O00Oo , IIIiiiiiIii in oO0o0o0ooO0oO :
   if "Xem phim" not in IIIiiiiiIii :
    IIIiiiiiIii = "Tập %s" % IIIiiiiiIii
   OO ( IIIiiiiiIii , o0oOo0Ooo0O ( "6" , "nqqqpnBlZaNknpqlpKKfpJtkrKRl" ) + OO00O0O0O00Oo , 'loadvideo' , "" )
   if 55 - 55: OOooOOo / iII111i * I1Ii111
def OoO000 ( url ) :
 try :
  IIiiIiI1 = xbmc . Keyboard ( '' , 'Enter search text' )
  IIiiIiI1 . doModal ( )
  if ( IIiiIiI1 . isConfirmed ( ) ) :
   iiIiIIi = urllib . quote_plus ( IIiiIiI1 . getText ( ) . replace ( " " , "-" ) )
  url = url . replace ( "keyword" , iiIiIIi )
  I11 ( url )
 except : pass
 if 65 - 65: I11i
def ii1I ( url , name ) :
 Oo0o0000o0o0 = oOo0oooo00o ( url )
 OooO0 = re . compile ( o0oOo0Ooo0O ( "7" , "c6qmrKmanJKVdZRhqqmadFlfZWJ2YFmSlXWUYWZ1" ) ) . findall ( Oo0o0000o0o0 ) [ 0 ]
 II11iiii1Ii = ""
 OO0oOoo = re . compile ( o0oOo0Ooo0O ( "8" , "dKyqmZujWKuqm6SZpp91Wq6hWlijoaacdVqrrZqsoayknataWKyxqJ11WqydsKxnrqysWlirqpt1WmBmY3dhWpOWdpVidg==" ) ) . findall ( Oo0o0000o0o0 )
 if len ( OO0oOoo ) > 0 :
  II11iiii1Ii = o0oOo0Ooo0O ( "9" , "oa2tqXNoaKZnoZ2op6Wip55nr6do" ) + OO0oOoo [ 0 ]
 O0o0Oo = xbmcgui . ListItem ( name )
 O0o0Oo . setProperty ( "IsPlayable" , "true" )
 O0o0Oo . setPath ( OooO0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0o0Oo )
 Oo00OOOOO = xbmc . Player ( )
 if ( II11iiii1Ii != '' ) :
  O0oOO0o0 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
  O0oOO0o0 = xbmc . translatePath ( os . path . join ( O0oOO0o0 , "temp.sub" ) )
  O0O = urllib2 . Request ( II11iiii1Ii )
  O0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; da-dk) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3' )
  O0O . add_header ( 'Referer' , url )
  O00o0OO = urllib2 . urlopen ( O0O )
  I11i1 = O00o0OO . read ( )
  O00o0OO . close ( )
  with open ( O0oOO0o0 , "w" ) as iIi1ii1I1 :
   iIi1ii1I1 . write ( I11i1 )
   if 71 - 71: IIii11I1 . Oooo
  Oo00OOOOO . setSubtitles ( O0oOO0o0 )
  if 73 - 73: I1Ii111 % I11i - o00O0oo
def iiIIII1i1i ( url ) :
 Oo0o0000o0o0 = ""
 if os . path . exists ( url ) == True :
  Oo0o0000o0o0 = open ( url ) . read ( )
 else :
  O0O = urllib2 . Request ( url )
  O0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
  iiI1 = urllib2 . urlopen ( O0O )
  Oo0o0000o0o0 = iiI1 . read ( )
  iiI1 . close ( )
 Oo0o0000o0o0 = '' . join ( Oo0o0000o0o0 . splitlines ( ) ) . replace ( '\'' , '"' )
 Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '\n' , '' )
 Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '\t' , '' )
 Oo0o0000o0o0 = re . sub ( '  +' , ' ' , Oo0o0000o0o0 )
 Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '> <' , '><' )
 return Oo0o0000o0o0
 if 19 - 19: ooOoO0o + i1111
def oOo0oooo00o ( url ) :
 O0O = urllib2 . Request ( url )
 O0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; da-dk) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3' )
 try :
  iiI1 = II1 . open ( O0O )
  if "app.php" in iiI1 . geturl ( ) :
   iiI1 = II1 . open ( O0O )
  Oo0o0000o0o0 = iiI1 . read ( )
  iiI1 . close ( )
  Oo0o0000o0o0 = '' . join ( Oo0o0000o0o0 . splitlines ( ) ) . replace ( '\'' , '"' )
  Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '\n' , '' )
  Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '\t' , '' )
  Oo0o0000o0o0 = re . sub ( '  +' , ' ' , Oo0o0000o0o0 )
  Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '> <' , '><' )
  return Oo0o0000o0o0
 except urllib2 . HTTPError , ooo :
  if ooo . code in [ 404 ] :
   iiI1 = II1 . open ( O0O )
   Oo0o0000o0o0 = iiI1 . read ( )
   iiI1 . close ( )
   Oo0o0000o0o0 = '' . join ( Oo0o0000o0o0 . splitlines ( ) ) . replace ( '\'' , '"' )
   Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '\n' , '' )
   Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '\t' , '' )
   Oo0o0000o0o0 = re . sub ( '  +' , ' ' , Oo0o0000o0o0 )
   Oo0o0000o0o0 = Oo0o0000o0o0 . replace ( '> <' , '><' )
   return Oo0o0000o0o0
   if 18 - 18: Ii1I
def o0oOo0Ooo0O ( k , e ) :
 I1i1I1II = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for i1 in range ( len ( e ) ) :
  IiIiiI = k [ i1 % len ( k ) ]
  I1I = chr ( ( 256 + ord ( e [ i1 ] ) - ord ( IiIiiI ) ) % 256 )
  I1i1I1II . append ( I1I )
 return "" . join ( I1i1I1II )
 if 80 - 80: I11i - OOooOOo
def OO ( name , url , mode , iconimage ) :
 OOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 iiiiiIIii = True
 O000OO0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O000OO0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O000OO0 . setProperty ( "IsPlayable" , "true" )
 iiiiiIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOO00 , listitem = O000OO0 )
 return iiiiiIIii
 if 43 - 43: IIii11I1 - Oooo % I1ii11iIi11i . ooOoO0o
def IIiIiII11i ( name , url , mode , iconimage , plot ) :
 OOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&plot=" + urllib . quote_plus ( plot )
 iiiiiIIii = True
 O000OO0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O000OO0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : plot } )
 iiiiiIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOO00 , listitem = O000OO0 , isFolder = True )
 return iiiiiIIii
 if 57 - 57: I1Ii111 . I1Ii111
def OooOooo ( parameters ) :
 O000oo0O = { }
 if 66 - 66: iII111i / I11i - I1ii11iIi11i . I1Ii111 / I1ii11iIi11i * I1Ii111
 if parameters :
  IIIii1II1II = parameters [ 1 : ] . split ( "&" )
  for i1I1iI in IIIii1II1II :
   oo0OooOOo0 = i1I1iI . split ( '=' )
   if ( len ( oo0OooOOo0 ) ) == 2 :
    O000oo0O [ oo0OooOOo0 [ 0 ] ] = oo0OooOOo0 [ 1 ]
 return O000oo0O
 if 92 - 92: OOo00O0Oo0oO . ooOoO0o + Ii1I
IiII1I11i1I1I = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 83 - 83: iII111i / i1111
if os . path . exists ( IiII1I11i1I1I ) == False :
 os . mkdir ( IiII1I11i1I1I )
iIIIIii1 = os . path . join ( IiII1I11i1I1I , 'visitor' )
if 58 - 58: i11iIiiIii % ooOoO0o
if os . path . exists ( iIIIIii1 ) == False :
 from random import randint
 OO00Oo = open ( iIIIIii1 , "w" )
 OO00Oo . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 OO00Oo . close ( )
 if 51 - 51: ooO * Ii1I + ooOoO0o + OOooOOo
o0O0O00 = xbmc . translatePath ( "special://userdata" )
o0O0O00 = xbmc . translatePath ( os . path . join ( o0O0O00 , "uaip" ) )
if not os . path . exists ( o0O0O00 ) :
 o000o = "%s;%s;%s;%s" % ( xbmc . getInfoLabel ( "System.FriendlyName" ) , xbmc . getInfoLabel ( "System.BuildVersion" ) , xbmc . getInfoLabel ( "System.KernelVersion" ) , xbmc . getInfoLabel ( "Network.MacAddress" ) )
 I11IiI1I11i1i = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 if not any ( b in o000o for b in I11IiI1I11i1i ) :
  iI1ii1Ii = iiIIII1i1i ( o0oOo0Ooo0O ( "qwe" , "2evZ4bGUoN3X1tzM1ubO4aXT1uuU1OrboA==" ) )
  i1 = iI1ii1Ii . replace ( '"' , '' ) . split ( ',' )
  OOO00 = o000o . split ( ";" )
  with open ( o0O0O00 , "w" ) as iIi1ii1I1 :
   iIi1ii1I1 . write ( o000o + ";" + i1 [ 0 ] )
  oooo000 = { 'entry.436422879' : OOO00 [ 0 ] , 'entry.1845442180' : OOO00 [ 1 ] , 'entry.972740559' : OOO00 [ 2 ] , 'entry.1836504487' : OOO00 [ 3 ] , 'entry.1101915442' : i1 [ 0 ] , 'entry.1574658585' : i1 [ 1 ] , 'entry.1805295152' : i1 [ 2 ] , 'entry.512145242' : i1 [ 3 ] , 'entry.773640853' : i1 [ 4 ] , 'entry.319359888' : i1 [ 5 ] , 'entry.122876449' : i1 [ 6 ] , 'entry.1791949570' : i1 [ 7 ] , 'entry.1970011699' : i1 [ 8 ] , 'entry.422390183' : i1 [ 9 ] , 'entry.2030601071' : i1 [ 10 ] }
  iIIIi1 = urllib . urlencode ( oooo000 )
  iiII1i1 = o0oOo0Ooo0O ( "rty" , "2ujt4uezoaPd4dfsoNvo4dvl16Lc4eGo2OPr3-eo1qOqp-69pqjrptPPzLjEueLTvr3OvLW_t97iy9W6otrKxM275d_H5uHk47_kt6Pf4ebmxNns4uPn5dk=" )
  O0O = urllib2 . Request ( iiII1i1 , iIIIi1 )
  O0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0' )
  O0O . add_header ( 'Accept-Encoding' , 'gzip, deflate' )
  O0O . add_header ( 'Content-type' , 'application/x-www-form-urlencoded' )
  iiI1 = urllib2 . urlopen ( O0O )
  if 66 - 66: I1Ii111 - ooOoO0o
def I1i1III ( utm_url ) :
 OO0O0OoOO0 = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  O0O = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : OO0O0OoOO0 }
 )
  iiI1 = urllib2 . urlopen ( O0O ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return iiI1
 if 10 - 10: II1Ii % OOO0O
def O00o0O00 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  ii111111I1iII = "1.0"
  O00ooo0O0 = open ( iIIIIii1 ) . read ( )
  i1iIi1iIi1i = "HDOnline"
  I1I1iIiII1 = "UA-52209804-2"
  i11i1I1 = "www.viettv24.com"
  ii1IOo0ooOo0o = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   Ii1i1 = ii1IOo0ooOo0o + "?" + "utmwv=" + ii111111I1iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1iIi1iIi1i ) + "&utmac=" + I1I1iIiII1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O00ooo0O0 , "1" , "1" , "2" ] )
   if 15 - 15: oOo0O0Ooo
   if 18 - 18: i11iIiiIii . Ooo % II1Ii / Oooo
   if 75 - 75: I11i % Ii1I % Ii1I . IIii11I1
   if 5 - 5: Ii1I * i1111 + I11i . I1Ii111 + I11i
   if 91 - 91: Oooo
  else :
   if group == "None" :
    Ii1i1 = ii1IOo0ooOo0o + "?" + "utmwv=" + ii111111I1iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1iIi1iIi1i + "/" + name ) + "&utmac=" + I1I1iIiII1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O00ooo0O0 , "1" , "1" , "2" ] )
    if 61 - 61: oOo0O0Ooo
    if 64 - 64: i1111 / I11i - Oooo - ooOoO0o
    if 86 - 86: ooOoO0o % I11i / I1ii11iIi11i / I11i
    if 42 - 42: OOooOOo
    if 67 - 67: IIii11I1 . OOo00O0Oo0oO . Oooo
   else :
    Ii1i1 = ii1IOo0ooOo0o + "?" + "utmwv=" + ii111111I1iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1iIi1iIi1i + "/" + group + "/" + name ) + "&utmac=" + I1I1iIiII1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O00ooo0O0 , "1" , "1" , "2" ] )
    if 10 - 10: iII111i % iII111i - OOO0O / I1Ii111 + o00O0oo
    if 87 - 87: IiII * iII111i + I1Ii111 / OOO0O / OOo00O0Oo0oO
    if 37 - 37: OOo00O0Oo0oO - i1111 * IiII % i11iIiiIii - IIii11I1
    if 83 - 83: ooOoO0o / I1ii11iIi11i
    if 34 - 34: ooO
    if 57 - 57: IiII . ooOoO0o . Ooo
  print "============================ POSTING ANALYTICS ============================"
  I1i1III ( Ii1i1 )
  if 42 - 42: ooOoO0o + iII111i % Oooo
  if not group == "None" :
   i1iIIIi1i = ii1IOo0ooOo0o + "?" + "utmwv=" + ii111111I1iII + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( i11i1I1 ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + i1iIi1iIi1i + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( i1iIi1iIi1i ) + "&utmac=" + I1I1iIiII1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , O00ooo0O0 , "1" , "2" ] )
   if 43 - 43: I11i % I1Ii111
   if 5 - 5: i11iIiiIii - Ooo / OOO0O
   if 26 - 26: ooOoO0o . II1Ii
   if 39 - 39: OOo00O0Oo0oO - Oooo % i11iIiiIii * IIii11I1 . ooO
   if 58 - 58: OOooOOo % i11iIiiIii . OOo00O0Oo0oO / IiII
   if 84 - 84: OOo00O0Oo0oO . iII111i / oO0o - I1ii11iIi11i / II1Ii / Ii1I
   if 12 - 12: I1ii11iIi11i * OOo00O0Oo0oO % Ooo % OOO0O
   if 20 - 20: I1Ii111 % o00O0oo / o00O0oo + o00O0oo
   try :
    print "============================ POSTING TRACK EVENT ============================"
    I1i1III ( i1iIIIi1i )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 45 - 45: IiII - ooO - II1Ii - OOooOOo . oOo0O0Ooo / Oooo
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 51 - 51: Oooo + OOo00O0Oo0oO
IIIII11I1IiI = OooOooo ( sys . argv [ 2 ] )
i1I = IIIII11I1IiI . get ( 'mode' )
OoOO = IIIII11I1IiI . get ( 'url' )
ooOOO0 = IIIII11I1IiI . get ( 'name' )
oooOOOOO = IIIII11I1IiI . get ( 'plot' )
if type ( OoOO ) == type ( str ( ) ) :
 OoOO = urllib . unquote_plus ( OoOO )
if type ( ooOOO0 ) == type ( str ( ) ) :
 ooOOO0 = urllib . unquote_plus ( ooOOO0 )
if type ( oooOOOOO ) == type ( str ( ) ) :
 ooOOO0 = urllib . unquote_plus ( oooOOOOO )
o0o = str ( sys . argv [ 1 ] )
if i1I == 'index' :
 O00o0O00 ( "Browse" , ooOOO0 )
 I11 ( OoOO )
elif i1I == 'episodes' :
 O00o0O00 ( "Browse" , ooOOO0 )
 I1Ii ( OoOO )
elif i1I == 'search' :
 O00o0O00 ( "None" , "Search" )
 OoO000 ( OoOO )
elif i1I == 'loadvideo' :
 O00o0O00 ( "Play" , ooOOO0 + "/" + OoOO )
 O0OOoO00OO0o = xbmcgui . DialogProgress ( )
 O0OOoO00OO0o . create ( 'HDOnline' , 'Loading video. Please wait...' )
 ii1I ( OoOO , ooOOO0 )
 O0OOoO00OO0o . close ( )
 del O0OOoO00OO0o
else :
 O00o0O00 ( "None" , "None" )
 OoO0O00 ( )
xbmcplugin . endOfDirectory ( int ( o0o ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
